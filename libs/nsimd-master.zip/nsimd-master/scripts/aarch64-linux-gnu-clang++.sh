#!/bin/bash

clang++ --target=aarch64-linux-gnu "$@"

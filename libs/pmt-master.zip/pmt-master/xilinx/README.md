# Xilinx-test usage

Before running `Xilinx-test` make sure to export the target path (where the
power usage of the FPGA board is registered):

`export PMT_DEVICE="/sys/devices/pci0000:00/0000:00:03.1/0000:2d:00.0/xmc.m.18874369/xmc_power"`

**NOTE:** The file location may change location based on the system used.

void initDisplay();
void deinitDisplay();
void clearDisplay();
void displayInitialValues();
void displaySensor(const int sensorPairName, const float amp, const float volt,
                   const float watt, const float totalWatt);
void displayMeasurementInProgress();

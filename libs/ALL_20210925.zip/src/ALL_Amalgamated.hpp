/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_MAIN_HEADER_INC
#define ALL_MAIN_HEADER_INC

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_CUSTOM_EXCEPTIONS_INC
#define ALL_CUSTOM_EXCEPTIONS_INC

#include <exception>
#include <sstream>
#include <string>

namespace ALL {

/// Customized exceptions for ALL, modified for each specific exception type
struct CustomException : public std::exception {
protected:
  /// file the exception occured in
  const char *file;
  /// function the exception occured in
  const char *func;
  /// line the exception occured in
  int line;
  /// information on the exception
  const char *info;
  /// name of the exception
  const char *loc_desc;
  /// error message
  std::string error_msg;
  /// error identificators for Fortran error retrieval, remember to
  /// update the Fortran module as well!
  enum struct ErrorID : int {
	Generic = 1,
	PointDimensionMissmatch,
	InvalidCommType,
	InvalidArgument,
	OutOfBounds,
	InternalError,
	FilesystemError
  };
  /// error identificator retrieved by Fortran
  ErrorID error_id;

public:
  /// constructor for an exception used in ALL
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  CustomException(const char *file_ = "", const char *f_ = "", int l_ = -1,
                      const char *i_ = "",
                      const char *loc_desc_ = "ALLCustomException",
		      const ErrorID error_id_ = ErrorID::Generic)
      : file(file_), func(f_), line(l_), info(i_), loc_desc(loc_desc_), error_id(error_id_) {
    std::stringstream ss;
    ss << loc_desc << ": " << info << "\n"
       << "Function: " << func << "\n"
       << "File: " << file << "\n"
       << "Line: " << line << "\n";
    error_msg = ss.str();
  }
  /// method to get the function name from where the exception was thrown
  /// @return the function name
  const char *get_func() const { return func; }

  /// method to get the line from where the exception was thrown
  /// @return the line
  int get_line() const { return line; }

  /// method to get the additional information about the error leading to the
  /// exception
  /// @return the information given about the error
  const char *get_info() { return info; }

  /// overloaded method from the base Exception class to return an error message
  /// @return the error message of the exception
  virtual const char *what() const throw() { return error_msg.c_str(); }

  /// retrieve error id for Fortran interface
  /// @return error id from ErrorID enum
  int get_error_id() { return static_cast<int>(error_id); }
};

/// Exception to be used for missmatches in dimension for ALL::Point class
struct PointDimensionMissmatchException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  PointDimensionMissmatchException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Dimension missmatch in Point objects.",
      const char *loc_desc_ = "ALLPointDimMissmatchException",
      const ErrorID error_id_ = ErrorID::PointDimensionMissmatch)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid Communicators in a load-balancing method
struct InvalidCommTypeException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidCommTypeException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Type of MPI communicator not valid.",
      const char *loc_desc_ = "ALLCommTypeInvalidException",
      const ErrorID error_id_ = ErrorID::InvalidCommType)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid parameters in any type of classes
struct InvalidArgumentException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidArgumentException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Invalid argument given.",
      const char *loc_desc_ = "ALLInvalidArgumentException",
      const ErrorID error_id_ = ErrorID::InvalidArgument)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an array went out of bounds
struct OutOfBoundsException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  OutOfBoundsException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Access to array out of bounds.",
      const char *loc_desc_ = "ALLOutOfBoundsErrorException",
      const ErrorID error_id_ = ErrorID::OutOfBounds)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an internal error has occured
struct InternalErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InternalErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Internal error occured, see description.",
      const char *loc_desc_ = "ALLInternalErrorException",
      const ErrorID error_id_ = ErrorID::InternalError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if a filesystem error has occured
struct FilesystemErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  FilesystemErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Filesystem error occured, see description.",
      const char *loc_desc_ = "ALLFilesystemErrorException",
      const ErrorID error_id_ = ErrorID::FilesystemError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

}//namespace ALL

#endif

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_LB_HEADER_INCLUDED
#define ALL_LB_HEADER_INCLUDED

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_POINT_HEADER_INC
#define ALL_POINT_HEADER_INC

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_CUSTOM_EXCEPTIONS_INC
#define ALL_CUSTOM_EXCEPTIONS_INC

#include <exception>
#include <sstream>
#include <string>

namespace ALL {

/// Customized exceptions for ALL, modified for each specific exception type
struct CustomException : public std::exception {
protected:
  /// file the exception occured in
  const char *file;
  /// function the exception occured in
  const char *func;
  /// line the exception occured in
  int line;
  /// information on the exception
  const char *info;
  /// name of the exception
  const char *loc_desc;
  /// error message
  std::string error_msg;
  /// error identificators for Fortran error retrieval, remember to
  /// update the Fortran module as well!
  enum struct ErrorID : int {
	Generic = 1,
	PointDimensionMissmatch,
	InvalidCommType,
	InvalidArgument,
	OutOfBounds,
	InternalError,
	FilesystemError
  };
  /// error identificator retrieved by Fortran
  ErrorID error_id;

public:
  /// constructor for an exception used in ALL
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  CustomException(const char *file_ = "", const char *f_ = "", int l_ = -1,
                      const char *i_ = "",
                      const char *loc_desc_ = "ALLCustomException",
		      const ErrorID error_id_ = ErrorID::Generic)
      : file(file_), func(f_), line(l_), info(i_), loc_desc(loc_desc_), error_id(error_id_) {
    std::stringstream ss;
    ss << loc_desc << ": " << info << "\n"
       << "Function: " << func << "\n"
       << "File: " << file << "\n"
       << "Line: " << line << "\n";
    error_msg = ss.str();
  }
  /// method to get the function name from where the exception was thrown
  /// @return the function name
  const char *get_func() const { return func; }

  /// method to get the line from where the exception was thrown
  /// @return the line
  int get_line() const { return line; }

  /// method to get the additional information about the error leading to the
  /// exception
  /// @return the information given about the error
  const char *get_info() { return info; }

  /// overloaded method from the base Exception class to return an error message
  /// @return the error message of the exception
  virtual const char *what() const throw() { return error_msg.c_str(); }

  /// retrieve error id for Fortran interface
  /// @return error id from ErrorID enum
  int get_error_id() { return static_cast<int>(error_id); }
};

/// Exception to be used for missmatches in dimension for ALL::Point class
struct PointDimensionMissmatchException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  PointDimensionMissmatchException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Dimension missmatch in Point objects.",
      const char *loc_desc_ = "ALLPointDimMissmatchException",
      const ErrorID error_id_ = ErrorID::PointDimensionMissmatch)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid Communicators in a load-balancing method
struct InvalidCommTypeException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidCommTypeException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Type of MPI communicator not valid.",
      const char *loc_desc_ = "ALLCommTypeInvalidException",
      const ErrorID error_id_ = ErrorID::InvalidCommType)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid parameters in any type of classes
struct InvalidArgumentException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidArgumentException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Invalid argument given.",
      const char *loc_desc_ = "ALLInvalidArgumentException",
      const ErrorID error_id_ = ErrorID::InvalidArgument)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an array went out of bounds
struct OutOfBoundsException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  OutOfBoundsException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Access to array out of bounds.",
      const char *loc_desc_ = "ALLOutOfBoundsErrorException",
      const ErrorID error_id_ = ErrorID::OutOfBounds)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an internal error has occured
struct InternalErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InternalErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Internal error occured, see description.",
      const char *loc_desc_ = "ALLInternalErrorException",
      const ErrorID error_id_ = ErrorID::InternalError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if a filesystem error has occured
struct FilesystemErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  FilesystemErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Filesystem error occured, see description.",
      const char *loc_desc_ = "ALLFilesystemErrorException",
      const ErrorID error_id_ = ErrorID::FilesystemError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

}//namespace ALL

#endif

#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace ALL {

template <class T> class Point;
template <typename T>
std::ostream &operator<<(std::ostream &, const Point<T> &);

/// @tparam T floating point type used, has to be identical to the type used for
/// the vertices and borders
template <class T> class Point {
public:
  /// default constructor
  Point() : dimension(0) {}
  /// constructor
  /// @param d dimension of the point object
  Point(const int d) : dimension(d) {
    coordinates.resize(d);
    weight = (T)1;
  }
  /// constructor with initialization
  /// @param d dimension of the point object
  /// @param data positions
  Point(const int d, const T *data) : Point<T>(d) {
    // copy each element of the array into the vector (insecure, no boundary
    // checks for data!)
    for (auto i = 0; i < d; ++i)
      coordinates.at(i) = data[i];
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  Point(const std::vector<T> &data) {
    // initialize the coordinates vector with the data vector
    coordinates.insert(coordinates.begin(), data.begin(), data.end());
    // update the dimension with the size of the data vector
    dimension = data.size();
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  Point(const int d, const T *data, const T w) : Point<T>(d, data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  /// @param i index of the point
  Point(const int d, const T *data, const T w, const long i)
      : Point<T>(d, data, w) {
    id = i;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  Point(const std::vector<T> &data, const T w) : Point<T>(data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  /// @param i index of the point
  Point(const std::vector<T> &data, const T w, const long i)
      : Point<T>(data, w) {
    id = i;
  }

  /// destructor
  ~Point<T>(){};

  // TODO: return values to check if operation was successful?
  /// method to change the dimension of the point object
  /// @param d new dimension
  void setDimension(const int d) {
    dimension = d;
    coordinates.resize(d);
  }

  /// method to change the weight of the point object
  /// @param w new weight
  void set_weight(const T w) { weight = w; }

  /// method to change the index of the particle
  /// @param i new index
  void set_id(const long i) { id = i; }

  /// access operator to access an element of the point object
  /// @param idx the index of the element to be accessed
  /// @result reference to the indexed element
  T &operator[](const std::size_t idx) { return coordinates.at(idx); }

  /// access operator to access an element of the constant point object
  /// @param idx the index of the element to be accessed
  /// @result const reference to the indexed element
  const T &operator[](const std::size_t idx) const {
    return coordinates.at(idx);
  }

  /// method to get the weight of the point object
  /// @return the weight of the point object
  T getWeight() const { return weight; }

  /// method to get the index of the point object
  /// @return the index of the point object
  long get_id() const { return id; }

  /// method to get the dimension of the point object
  /// @return the dimension of the point object
  int getDimension() const { return dimension; }

  /// method to compute the norm of the vector described by the
  /// point object
  /// @param nd type of the norm (default: 2, i.e. the Euclidean norm)
  /// @return norm of the vector
  T norm(T nd = 2) {
    T res = 0;
    for (int d = 0; d < dimension; ++d)
      res += std::pow(coordinates.at(d), nd);
    return std::pow(res, 1.0 / nd);
  }

  /// method to compute the Euclidean distance (two-norm) between the local and
  /// the provided point object
  /// @param p the point object for which the distence to the local point object
  /// is computed
  /// @return the distance between the two points
  T d(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p).norm();
  }

  /// method to compute the Manhatten / city-block distance (one-norm) between
  /// the local and the provided point object
  /// @param p the point object for which the distance to the local point object
  /// is computed
  /// @return the distance between the two points
  T d_1(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p, 1).norm();
  }

  /// method to compute the distance vector between the local point object and
  /// the provided point object
  /// @param p the point object for which the distance vector to the local point
  /// object is computed
  /// @return the distance vector between the two points
  Point<T> dist(Point<T> &p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    std::vector<T> d_v;
    for (int d = 0; d < dimension; ++d)
      d_v.push_back(p[d] - coordinates.at(d));

    return Point<T>(d_v);
  }

  /// method to compute the distance of the local point object from a plane
  /// spanned by provided points
  /// @param A anchor point for the plane
  /// @param B anchor point for the plane
  /// @param C anchor point for the plane
  /// @return distance between local point object and plane
  T dist_plane(const Point<T> &A, const Point<T> &B,
               const Point<T> &C) {

    if (A.getDimension() != dimension || B.getDimension() != dimension ||
        C.getDimension() != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);

    // vectors spanning the plane from vertex 'a'
    T vb[3];
    T vc[3];

    for (int i = 0; i < 3; ++i) {
      vb[i] = B[i] - A[i];
      vc[i] = C[i] - A[i];
    }

    // normal vector of plane
    T n[3];

    n[0] = vb[1] * vc[2] - vb[2] * vc[1];
    n[1] = vb[2] * vc[0] - vb[0] * vc[2];
    n[2] = vb[0] * vc[1] - vb[1] * vc[0];

    // length of normal vector
    T dn = n.norm();

    // distance from origin
    T d = n * A;

    // compute distance of test vertex to plane
    return std::abs((n[0] * coordinates.at(0) + n[1] * coordinates.at(1) +
                     n[2] * coordinates.at(2) - d) /
                    dn);
  }

  /// operator for the addition of two point objects
  /// @param rhs point to add the local point object to
  /// @return sum of local point object and provided point object
  Point<T> operator+(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) + rhs[d];
    }
    return result;
  }

  /// operator for the addition of two point objects
  /// @param rhs point to subtract from the local point object
  /// @return difference vector between local point object and provided point
  /// object
  Point<T> operator-(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) - rhs[d];
    }
    return result;
  }

  /// operator to compute the dot product between two point objects
  /// @param rhs point object to compute the dot product with
  /// @return dot product between the two point objects
  T operator*(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    T result = (T)0.0;
    for (int d = 0; d < dimension; ++d) {
      result += coordinates.at(d) * rhs[d];
    }
    return result;
  }

  /// operator to scale the local point object by a provided factor
  /// @param rhs scaling factor
  /// @return scaled point object
  Point<T> operator*(const T &rhs) const {
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) * rhs;
    }
    return result;
  }

  /// operator to compute the cross product between two point objects
  /// @param rhs point object to compute the cross product with
  /// @return cross product between the two point objects
  /// @attention only works for 3D points / vectors
  Point<T> cross(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension && dimension != 3) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at((d + 1) % 3) * rhs[(d + 2) % 3] -
                  coordinates.at((d + 2) % 3) * rhs[(d + 1) % 3];
    }
    return result;
  }

  /// method to determine if the local point object has the same orientation to
  /// a plane spanned by point objects A,B,C as the provided point P
  /// @param A anchor point A
  /// @param B anchor point B
  /// @param C anchor point C
  /// @param P reference point P
  /// @return the local point object has the same orientation to the plane as
  /// @attention if the reference point is located within the plane, it will not
  /// have the same orientation as the local point! the reference point
  bool same_side_plane(const Point<T> &A, const Point<T> &B,
                       const Point<T> &C, const Point<T> &P) {
    // compute difference vectors:
    Point<T> BA = B - A;
    Point<T> CA = C - A;
    Point<T> PA = P - A;
    Point<T> tA = *(this) - A;

    // compute normal vector of plane
    Point<T> n = CA.cross(BA);

    // compute scalar product of distance
    // vectors with normal vector
    T PAn = PA * n;
    T tAn = tA * n;

    return ((PAn * tAn) > 0);
  }

  /// method to check if the local point object is inside a tetrahedron
  /// described by the vertices A,B,C and D
  /// @param A vertex A
  /// @param B vertex B
  /// @param C vertex C
  /// @param D vertex D
  /// @return the point is within the tetrahedron
  /// @attention a point that is on the surface of the tetrahedron is not inside
  /// it
  bool inTetrahedron(const Point<T> &A, const Point<T> &B,
                     const Point<T> &C, const Point<T> &D) {
    /// for all surfaces of the tetrahedron check if the local point has the
    /// same orientation as the remaining vertex of the tetrahedron, to be
    /// inside the tetrahedron that must be fulfilled
    return (same_side_plane(A, B, C, D) && same_side_plane(B, C, D, A) &&
            same_side_plane(C, D, A, B) && same_side_plane(A, D, B, C));
  };

private:
  /// dimension of the point object
  int dimension;
  /// index for the point
  long id;
  // array containg the coordinates
  std::vector<T> coordinates;
  /// weight of the point to be used if points are not to be equally considered
  /// in computations, e.g. if number of interactions are considered
  T weight;
};

/// output operator for a point object
/// @param os output stream the point object should be printed to
/// @param p the point object to be printed
/// @return the modified output stream
template <class T>
std::ostream &operator<<(std::ostream &os, const Point<T> &p) {
  for (int i = 0; i < p.getDimension(); ++i)
    os << p[i] << " ";
  os << p.getWeight();
  return os;
}

/// operator to scale a point by a factor (reversed way of notation T *
/// Point<T>)
/// @param lhs scaling factor
/// @param rhs the point object to be scaled
/// @param scaled point object
template <class T>
Point<T> operator*(const T &lhs, const Point<T> &rhs) {
  return rhs * lhs;
}

// template <class T>
// Point<T> operator/(const T &lhs, const Point<T> &rhs) {
//   return rhs * ((T)1 / lhs);
// }

}//namespace ALL

#endif

#include <mpi.h>
#include <vector>

namespace ALL {

/// @tparam T data for vertices and related data
/// @tparam W data for work and related data
template <class T, class W> class LB {
public:
  /// constructor for the basic load-balancing class, sets up parameters
  /// required by all balancing methods
  /// @param[in] dim dimension of the vertices used
  /// @param[in] g correction factor for the computation of shifts
  LB(const int dim, const T g) : gamma(g), dimension(dim) {
    // set allowed minimum size to zero
    minSize = std::vector<T>(dim, 0.0);
    periodicity.resize(dim);
    local_coords.resize(dim);
    global_dims.resize(dim);
    neighborVertices.resize(0);
  }

  /// destructor
  virtual ~LB() = default;

  /// abstract definition of the setup method
  virtual void setup() = 0;

  /// abstract definition of the balancing method
  virtual void balance(const int step) = 0;

  /// abstract definition of the method to get the neighbors of the local domain
  /// @result std::vector<int> to store the MPI ranks of the neighbors
  /// to
  virtual std::vector<int> &getNeighbors() = 0;

  /// method to update the vertices used for the balancing step, overwrites old
  /// set of vertices
  /// @param[in] vertices_in vector containg the new vertices to be used
  virtual void setVertices(const std::vector<Point<T>> &vertices_in) {
    // as a basic assumption the number of resulting vertices
    // is equal to the number of input vertices:
    // exceptions:
    //      VORONOI
    vertices = vertices_in;
    prevVertices = vertices_in;
  }

  /// method to set the dimension of the vertices
  /// @param[in] d the dimension to be used
  /// @attention most methods currently support 3D vertices only
  virtual void setDimension(const int d) { dimension = d; }

  /// method to get the dimension of the vertices
  /// @return the dimension of the vertices
  virtual int getDimension() { return dimension; }

  /// method to set the correction value gamma
  /// @param[in] g the correction value to use
  virtual void setGamma(const T g) { gamma = g; }

  /// method to get the correction value currently used
  /// @return the current correction value
  virtual const T getGamma() { return gamma; }

  /// method to set a multi-dimensional work for the local domain
  /// @param[in] w vector containing all the dimensions of the work to be used
  /// for the local domain
  virtual void setWork(const std::vector<W> &w) { work = w; }

  /// method to set a scalar work for the local domain
  /// @param[in] w value containing the work to be used for the local domain
  virtual void setWork(const W w) {
    work.resize(1);
    work.at(0) = w;
  }

  /// method to set the minimum domain size in each dimension
  /// @param[in] minSize the minimum size of a domain in all dimensions
  virtual void setMinDomainSize(const std::vector<T> &minSize) {
    this->minSize = minSize;
  }

  /// method to get the minimum domain size the balancing methods have to obey
  /// @return the minimum domain size allowed
  virtual const std::vector<T> &getMinDomainSize() { return minSize; }

  /// method to set the (orthogonal) size of the system
  /// @param[in] sysSize system size in all dimensions
  virtual void setSysSize(const std::vector<T> &newSysSize) {
    sysSize = newSysSize;
  }

  /// method to get the currently stored system size
  /// @return the currently stored system size
  virtual const std::vector<T> &getSysSize() { return sysSize; }

  /// method to get the currently stored work for the local process
  /// @return the currently stored work
  /// @attention always returns a std::vector, for scalar work, it has length 1
  virtual std::vector<W> &getWork() { return work; }

  /// method to get result vertices
  /// @return the resulting vertices after a balancing step
  virtual std::vector<Point<T>> &getVertices() { return vertices; }

  /// method to get the original vertices before the last balancing step
  /// @return the original unmodified vertices before the last balancing step
  /// @attention since the original and resulting vertices are set up in the
  /// balancing method, the result is undefined before calling the balancing
  /// method at least once
  virtual std::vector<Point<T>> &getPrevVertices() { return prevVertices; };

  /// method to set the MPI communicator to be used by the balancing method
  /// @param[in] comm the MPI communicator to be used
  virtual void setCommunicator(const MPI_Comm comm) {
    // store communicator
    globalComm = comm;
    // get local rank within communicator
    MPI_Comm_rank(comm, &localRank);
  }

  /// method the get the number of vertices stored for the local domain
  /// @return number of local vertices
  int getNVertices() { return vertices.size(); }

  /// method to set undefined method specific data, which is not shared between
  /// different methods but needs to be set by a unified interface
  /// @param[in] data the data be passed to the balancing method
  virtual void setAdditionalData(const void *data) = 0;

  /// method to provide a list of vertices describing the neighboring domains
  /// currently only implemented for VORONOI, as a means to get the anchor points
  /// of the surrounding domains
  std::vector<T> &getNeighborVertices() {
    return neighborVertices; }

protected:
  /// correction factor
  T gamma;
  /// dimension of the used vertices
  int dimension;
  /// used MPI communicator
  MPI_Comm globalComm;
  /// local rank in the used MPI communicator
  int localRank;
  /// minimum domain size
  /// @attention not all balancing method support this
  std::vector<T> minSize;
  /// (orthogonal) system size
  std::vector<T> sysSize;
  /// local work
  std::vector<W> work;
  /// local vertices after previous balancing step
  std::vector<Point<T>> vertices;
  /// original vertices before previous balancing step
  std::vector<Point<T>> prevVertices;
  /// dimensions of the global process grid
  std::vector<int> global_dims;
  /// cartesian coordinates of the local domain in the process grid
  std::vector<int> local_coords;
  /// periodicity of the MPI communicator / system
  std::vector<int> periodicity;
  /// vertices describing neighboring domains
  std::vector<T> neighborVertices;
  /// method the resize the vertex list
  /// @param [in] new_size the new size of the vertex list
  void resizeVertices(const int newSize) { vertices.resize(newSize); }

};

}//namespace ALL

#endif // ALL_LB_HEADER_INCLUDED

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_POINT_HEADER_INC
#define ALL_POINT_HEADER_INC

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_CUSTOM_EXCEPTIONS_INC
#define ALL_CUSTOM_EXCEPTIONS_INC

#include <exception>
#include <sstream>
#include <string>

namespace ALL {

/// Customized exceptions for ALL, modified for each specific exception type
struct CustomException : public std::exception {
protected:
  /// file the exception occured in
  const char *file;
  /// function the exception occured in
  const char *func;
  /// line the exception occured in
  int line;
  /// information on the exception
  const char *info;
  /// name of the exception
  const char *loc_desc;
  /// error message
  std::string error_msg;
  /// error identificators for Fortran error retrieval, remember to
  /// update the Fortran module as well!
  enum struct ErrorID : int {
	Generic = 1,
	PointDimensionMissmatch,
	InvalidCommType,
	InvalidArgument,
	OutOfBounds,
	InternalError,
	FilesystemError
  };
  /// error identificator retrieved by Fortran
  ErrorID error_id;

public:
  /// constructor for an exception used in ALL
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  CustomException(const char *file_ = "", const char *f_ = "", int l_ = -1,
                      const char *i_ = "",
                      const char *loc_desc_ = "ALLCustomException",
		      const ErrorID error_id_ = ErrorID::Generic)
      : file(file_), func(f_), line(l_), info(i_), loc_desc(loc_desc_), error_id(error_id_) {
    std::stringstream ss;
    ss << loc_desc << ": " << info << "\n"
       << "Function: " << func << "\n"
       << "File: " << file << "\n"
       << "Line: " << line << "\n";
    error_msg = ss.str();
  }
  /// method to get the function name from where the exception was thrown
  /// @return the function name
  const char *get_func() const { return func; }

  /// method to get the line from where the exception was thrown
  /// @return the line
  int get_line() const { return line; }

  /// method to get the additional information about the error leading to the
  /// exception
  /// @return the information given about the error
  const char *get_info() { return info; }

  /// overloaded method from the base Exception class to return an error message
  /// @return the error message of the exception
  virtual const char *what() const throw() { return error_msg.c_str(); }

  /// retrieve error id for Fortran interface
  /// @return error id from ErrorID enum
  int get_error_id() { return static_cast<int>(error_id); }
};

/// Exception to be used for missmatches in dimension for ALL::Point class
struct PointDimensionMissmatchException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  PointDimensionMissmatchException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Dimension missmatch in Point objects.",
      const char *loc_desc_ = "ALLPointDimMissmatchException",
      const ErrorID error_id_ = ErrorID::PointDimensionMissmatch)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid Communicators in a load-balancing method
struct InvalidCommTypeException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidCommTypeException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Type of MPI communicator not valid.",
      const char *loc_desc_ = "ALLCommTypeInvalidException",
      const ErrorID error_id_ = ErrorID::InvalidCommType)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid parameters in any type of classes
struct InvalidArgumentException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidArgumentException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Invalid argument given.",
      const char *loc_desc_ = "ALLInvalidArgumentException",
      const ErrorID error_id_ = ErrorID::InvalidArgument)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an array went out of bounds
struct OutOfBoundsException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  OutOfBoundsException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Access to array out of bounds.",
      const char *loc_desc_ = "ALLOutOfBoundsErrorException",
      const ErrorID error_id_ = ErrorID::OutOfBounds)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an internal error has occured
struct InternalErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InternalErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Internal error occured, see description.",
      const char *loc_desc_ = "ALLInternalErrorException",
      const ErrorID error_id_ = ErrorID::InternalError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if a filesystem error has occured
struct FilesystemErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  FilesystemErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Filesystem error occured, see description.",
      const char *loc_desc_ = "ALLFilesystemErrorException",
      const ErrorID error_id_ = ErrorID::FilesystemError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

}//namespace ALL

#endif

#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace ALL {

template <class T> class Point;
template <typename T>
std::ostream &operator<<(std::ostream &, const Point<T> &);

/// @tparam T floating point type used, has to be identical to the type used for
/// the vertices and borders
template <class T> class Point {
public:
  /// default constructor
  Point() : dimension(0) {}
  /// constructor
  /// @param d dimension of the point object
  Point(const int d) : dimension(d) {
    coordinates.resize(d);
    weight = (T)1;
  }
  /// constructor with initialization
  /// @param d dimension of the point object
  /// @param data positions
  Point(const int d, const T *data) : Point<T>(d) {
    // copy each element of the array into the vector (insecure, no boundary
    // checks for data!)
    for (auto i = 0; i < d; ++i)
      coordinates.at(i) = data[i];
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  Point(const std::vector<T> &data) {
    // initialize the coordinates vector with the data vector
    coordinates.insert(coordinates.begin(), data.begin(), data.end());
    // update the dimension with the size of the data vector
    dimension = data.size();
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  Point(const int d, const T *data, const T w) : Point<T>(d, data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  /// @param i index of the point
  Point(const int d, const T *data, const T w, const long i)
      : Point<T>(d, data, w) {
    id = i;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  Point(const std::vector<T> &data, const T w) : Point<T>(data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  /// @param i index of the point
  Point(const std::vector<T> &data, const T w, const long i)
      : Point<T>(data, w) {
    id = i;
  }

  /// destructor
  ~Point<T>(){};

  // TODO: return values to check if operation was successful?
  /// method to change the dimension of the point object
  /// @param d new dimension
  void setDimension(const int d) {
    dimension = d;
    coordinates.resize(d);
  }

  /// method to change the weight of the point object
  /// @param w new weight
  void set_weight(const T w) { weight = w; }

  /// method to change the index of the particle
  /// @param i new index
  void set_id(const long i) { id = i; }

  /// access operator to access an element of the point object
  /// @param idx the index of the element to be accessed
  /// @result reference to the indexed element
  T &operator[](const std::size_t idx) { return coordinates.at(idx); }

  /// access operator to access an element of the constant point object
  /// @param idx the index of the element to be accessed
  /// @result const reference to the indexed element
  const T &operator[](const std::size_t idx) const {
    return coordinates.at(idx);
  }

  /// method to get the weight of the point object
  /// @return the weight of the point object
  T getWeight() const { return weight; }

  /// method to get the index of the point object
  /// @return the index of the point object
  long get_id() const { return id; }

  /// method to get the dimension of the point object
  /// @return the dimension of the point object
  int getDimension() const { return dimension; }

  /// method to compute the norm of the vector described by the
  /// point object
  /// @param nd type of the norm (default: 2, i.e. the Euclidean norm)
  /// @return norm of the vector
  T norm(T nd = 2) {
    T res = 0;
    for (int d = 0; d < dimension; ++d)
      res += std::pow(coordinates.at(d), nd);
    return std::pow(res, 1.0 / nd);
  }

  /// method to compute the Euclidean distance (two-norm) between the local and
  /// the provided point object
  /// @param p the point object for which the distence to the local point object
  /// is computed
  /// @return the distance between the two points
  T d(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p).norm();
  }

  /// method to compute the Manhatten / city-block distance (one-norm) between
  /// the local and the provided point object
  /// @param p the point object for which the distance to the local point object
  /// is computed
  /// @return the distance between the two points
  T d_1(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p, 1).norm();
  }

  /// method to compute the distance vector between the local point object and
  /// the provided point object
  /// @param p the point object for which the distance vector to the local point
  /// object is computed
  /// @return the distance vector between the two points
  Point<T> dist(Point<T> &p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    std::vector<T> d_v;
    for (int d = 0; d < dimension; ++d)
      d_v.push_back(p[d] - coordinates.at(d));

    return Point<T>(d_v);
  }

  /// method to compute the distance of the local point object from a plane
  /// spanned by provided points
  /// @param A anchor point for the plane
  /// @param B anchor point for the plane
  /// @param C anchor point for the plane
  /// @return distance between local point object and plane
  T dist_plane(const Point<T> &A, const Point<T> &B,
               const Point<T> &C) {

    if (A.getDimension() != dimension || B.getDimension() != dimension ||
        C.getDimension() != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);

    // vectors spanning the plane from vertex 'a'
    T vb[3];
    T vc[3];

    for (int i = 0; i < 3; ++i) {
      vb[i] = B[i] - A[i];
      vc[i] = C[i] - A[i];
    }

    // normal vector of plane
    T n[3];

    n[0] = vb[1] * vc[2] - vb[2] * vc[1];
    n[1] = vb[2] * vc[0] - vb[0] * vc[2];
    n[2] = vb[0] * vc[1] - vb[1] * vc[0];

    // length of normal vector
    T dn = n.norm();

    // distance from origin
    T d = n * A;

    // compute distance of test vertex to plane
    return std::abs((n[0] * coordinates.at(0) + n[1] * coordinates.at(1) +
                     n[2] * coordinates.at(2) - d) /
                    dn);
  }

  /// operator for the addition of two point objects
  /// @param rhs point to add the local point object to
  /// @return sum of local point object and provided point object
  Point<T> operator+(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) + rhs[d];
    }
    return result;
  }

  /// operator for the addition of two point objects
  /// @param rhs point to subtract from the local point object
  /// @return difference vector between local point object and provided point
  /// object
  Point<T> operator-(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) - rhs[d];
    }
    return result;
  }

  /// operator to compute the dot product between two point objects
  /// @param rhs point object to compute the dot product with
  /// @return dot product between the two point objects
  T operator*(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    T result = (T)0.0;
    for (int d = 0; d < dimension; ++d) {
      result += coordinates.at(d) * rhs[d];
    }
    return result;
  }

  /// operator to scale the local point object by a provided factor
  /// @param rhs scaling factor
  /// @return scaled point object
  Point<T> operator*(const T &rhs) const {
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) * rhs;
    }
    return result;
  }

  /// operator to compute the cross product between two point objects
  /// @param rhs point object to compute the cross product with
  /// @return cross product between the two point objects
  /// @attention only works for 3D points / vectors
  Point<T> cross(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension && dimension != 3) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at((d + 1) % 3) * rhs[(d + 2) % 3] -
                  coordinates.at((d + 2) % 3) * rhs[(d + 1) % 3];
    }
    return result;
  }

  /// method to determine if the local point object has the same orientation to
  /// a plane spanned by point objects A,B,C as the provided point P
  /// @param A anchor point A
  /// @param B anchor point B
  /// @param C anchor point C
  /// @param P reference point P
  /// @return the local point object has the same orientation to the plane as
  /// @attention if the reference point is located within the plane, it will not
  /// have the same orientation as the local point! the reference point
  bool same_side_plane(const Point<T> &A, const Point<T> &B,
                       const Point<T> &C, const Point<T> &P) {
    // compute difference vectors:
    Point<T> BA = B - A;
    Point<T> CA = C - A;
    Point<T> PA = P - A;
    Point<T> tA = *(this) - A;

    // compute normal vector of plane
    Point<T> n = CA.cross(BA);

    // compute scalar product of distance
    // vectors with normal vector
    T PAn = PA * n;
    T tAn = tA * n;

    return ((PAn * tAn) > 0);
  }

  /// method to check if the local point object is inside a tetrahedron
  /// described by the vertices A,B,C and D
  /// @param A vertex A
  /// @param B vertex B
  /// @param C vertex C
  /// @param D vertex D
  /// @return the point is within the tetrahedron
  /// @attention a point that is on the surface of the tetrahedron is not inside
  /// it
  bool inTetrahedron(const Point<T> &A, const Point<T> &B,
                     const Point<T> &C, const Point<T> &D) {
    /// for all surfaces of the tetrahedron check if the local point has the
    /// same orientation as the remaining vertex of the tetrahedron, to be
    /// inside the tetrahedron that must be fulfilled
    return (same_side_plane(A, B, C, D) && same_side_plane(B, C, D, A) &&
            same_side_plane(C, D, A, B) && same_side_plane(A, D, B, C));
  };

private:
  /// dimension of the point object
  int dimension;
  /// index for the point
  long id;
  // array containg the coordinates
  std::vector<T> coordinates;
  /// weight of the point to be used if points are not to be equally considered
  /// in computations, e.g. if number of interactions are considered
  T weight;
};

/// output operator for a point object
/// @param os output stream the point object should be printed to
/// @param p the point object to be printed
/// @return the modified output stream
template <class T>
std::ostream &operator<<(std::ostream &os, const Point<T> &p) {
  for (int i = 0; i < p.getDimension(); ++i)
    os << p[i] << " ";
  os << p.getWeight();
  return os;
}

/// operator to scale a point by a factor (reversed way of notation T *
/// Point<T>)
/// @param lhs scaling factor
/// @param rhs the point object to be scaled
/// @param scaled point object
template <class T>
Point<T> operator*(const T &lhs, const Point<T> &rhs) {
  return rhs * lhs;
}

// template <class T>
// Point<T> operator/(const T &lhs, const Point<T> &rhs) {
//   return rhs * ((T)1 / lhs);
// }

}//namespace ALL

#endif

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_TENSOR_HEADER_INCLUDED
#define ALL_TENSOR_HEADER_INCLUDED

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_CUSTOM_EXCEPTIONS_INC
#define ALL_CUSTOM_EXCEPTIONS_INC

#include <exception>
#include <sstream>
#include <string>

namespace ALL {

/// Customized exceptions for ALL, modified for each specific exception type
struct CustomException : public std::exception {
protected:
  /// file the exception occured in
  const char *file;
  /// function the exception occured in
  const char *func;
  /// line the exception occured in
  int line;
  /// information on the exception
  const char *info;
  /// name of the exception
  const char *loc_desc;
  /// error message
  std::string error_msg;
  /// error identificators for Fortran error retrieval, remember to
  /// update the Fortran module as well!
  enum struct ErrorID : int {
	Generic = 1,
	PointDimensionMissmatch,
	InvalidCommType,
	InvalidArgument,
	OutOfBounds,
	InternalError,
	FilesystemError
  };
  /// error identificator retrieved by Fortran
  ErrorID error_id;

public:
  /// constructor for an exception used in ALL
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  CustomException(const char *file_ = "", const char *f_ = "", int l_ = -1,
                      const char *i_ = "",
                      const char *loc_desc_ = "ALLCustomException",
		      const ErrorID error_id_ = ErrorID::Generic)
      : file(file_), func(f_), line(l_), info(i_), loc_desc(loc_desc_), error_id(error_id_) {
    std::stringstream ss;
    ss << loc_desc << ": " << info << "\n"
       << "Function: " << func << "\n"
       << "File: " << file << "\n"
       << "Line: " << line << "\n";
    error_msg = ss.str();
  }
  /// method to get the function name from where the exception was thrown
  /// @return the function name
  const char *get_func() const { return func; }

  /// method to get the line from where the exception was thrown
  /// @return the line
  int get_line() const { return line; }

  /// method to get the additional information about the error leading to the
  /// exception
  /// @return the information given about the error
  const char *get_info() { return info; }

  /// overloaded method from the base Exception class to return an error message
  /// @return the error message of the exception
  virtual const char *what() const throw() { return error_msg.c_str(); }

  /// retrieve error id for Fortran interface
  /// @return error id from ErrorID enum
  int get_error_id() { return static_cast<int>(error_id); }
};

/// Exception to be used for missmatches in dimension for ALL::Point class
struct PointDimensionMissmatchException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  PointDimensionMissmatchException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Dimension missmatch in Point objects.",
      const char *loc_desc_ = "ALLPointDimMissmatchException",
      const ErrorID error_id_ = ErrorID::PointDimensionMissmatch)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid Communicators in a load-balancing method
struct InvalidCommTypeException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidCommTypeException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Type of MPI communicator not valid.",
      const char *loc_desc_ = "ALLCommTypeInvalidException",
      const ErrorID error_id_ = ErrorID::InvalidCommType)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid parameters in any type of classes
struct InvalidArgumentException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidArgumentException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Invalid argument given.",
      const char *loc_desc_ = "ALLInvalidArgumentException",
      const ErrorID error_id_ = ErrorID::InvalidArgument)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an array went out of bounds
struct OutOfBoundsException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  OutOfBoundsException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Access to array out of bounds.",
      const char *loc_desc_ = "ALLOutOfBoundsErrorException",
      const ErrorID error_id_ = ErrorID::OutOfBounds)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an internal error has occured
struct InternalErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InternalErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Internal error occured, see description.",
      const char *loc_desc_ = "ALLInternalErrorException",
      const ErrorID error_id_ = ErrorID::InternalError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if a filesystem error has occured
struct FilesystemErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  FilesystemErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Filesystem error occured, see description.",
      const char *loc_desc_ = "ALLFilesystemErrorException",
      const ErrorID error_id_ = ErrorID::FilesystemError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

}//namespace ALL

#endif

#ifndef ALL_GENERAL_FUNCTION_HEADER_INCLUDED
#define ALL_GENERAL_FUNCTION_HEADER_INCLUDED

#include <mpi.h>
#include <cmath>
#include <vector>

namespace ALL{
namespace Functions {

/// function to compute the one-dimensional shift of the border between the
/// local process and the process indicated by neighbor_rank
/// @tparam T data type for vertices and related data
/// @tparam W data type for work and related data
/// @param[in] remote_rank the MPI rank of the neighbors the border is
/// shared with
/// @param[in] local_coord the cartesian coordinate of the local domain in the
/// process grid in the direction of the border shift
/// @param[in] global_dim the dimension of the process grid in the direction of
/// the border shift
/// @param[in] local_work the work on the local process
/// @param[in] remote_work the work on the neighboring process
/// @param[in] local_size the size of the local domain in the dimension of the
/// border shift
/// @param[in] remote_size the size of the neighbor domain in the dimension of
/// the border shift
/// @param[in] gamma the correction value for the shift, needed to regulate the
/// width of the shift, e.g. to avoid borders shifts where next-neighbor borders
/// are crossed by one another
/// @param[in] minSize optional minimum size of the domain in the dimension of
/// the border shift
/// @result the shift of the border in relation to the local domain
template <typename T, typename W>
T borderShift1d(const int remote_rank, const int local_coord,
                const int global_dim, const W local_work, const W remote_work,
                const T local_size, const T remote_size, const T gamma,
                const T minSize) {
  // calculate shift of borders:
  // s = 0.5 * gamma * (W_r - W_l) / (W_r + W_l) * (d_r + d_l)
  // *_r = * of neighbor (remote)
  // *_l = * of local domain

  T shift;
  // check if a sensible shift can be made
  if (remote_rank != MPI_PROC_NULL && local_coord != global_dim - 1 &&
      !(remote_work == (T)0 && local_work == (T)0)) {
    shift = 1.0 / gamma * 0.5 * (remote_work - local_work) /
            (remote_work + local_work) * (local_size + remote_size);

    // determine a maximum move in order to avoid overlapping borders and to
    // guarantee a stable shift of the domain borders (avoid the loss of a
    // domain due to too large shifts of its borders [no crossing of borders])
    T maxmove;
    if (shift > 0.0)
      maxmove = 0.49 * (remote_size - minSize);
    else
      maxmove = 0.49 * (local_size - minSize);

    if (std::abs(shift) > maxmove) {
      shift = (shift < 0.0) ? -maxmove : maxmove;
    }
  } else {
    shift = (T)0;
  }

  return shift;
}

}}// namespace ALL::Functions
#endif

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_LB_HEADER_INCLUDED
#define ALL_LB_HEADER_INCLUDED

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_POINT_HEADER_INC
#define ALL_POINT_HEADER_INC

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_CUSTOM_EXCEPTIONS_INC
#define ALL_CUSTOM_EXCEPTIONS_INC

#include <exception>
#include <sstream>
#include <string>

namespace ALL {

/// Customized exceptions for ALL, modified for each specific exception type
struct CustomException : public std::exception {
protected:
  /// file the exception occured in
  const char *file;
  /// function the exception occured in
  const char *func;
  /// line the exception occured in
  int line;
  /// information on the exception
  const char *info;
  /// name of the exception
  const char *loc_desc;
  /// error message
  std::string error_msg;
  /// error identificators for Fortran error retrieval, remember to
  /// update the Fortran module as well!
  enum struct ErrorID : int {
	Generic = 1,
	PointDimensionMissmatch,
	InvalidCommType,
	InvalidArgument,
	OutOfBounds,
	InternalError,
	FilesystemError
  };
  /// error identificator retrieved by Fortran
  ErrorID error_id;

public:
  /// constructor for an exception used in ALL
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  CustomException(const char *file_ = "", const char *f_ = "", int l_ = -1,
                      const char *i_ = "",
                      const char *loc_desc_ = "ALLCustomException",
		      const ErrorID error_id_ = ErrorID::Generic)
      : file(file_), func(f_), line(l_), info(i_), loc_desc(loc_desc_), error_id(error_id_) {
    std::stringstream ss;
    ss << loc_desc << ": " << info << "\n"
       << "Function: " << func << "\n"
       << "File: " << file << "\n"
       << "Line: " << line << "\n";
    error_msg = ss.str();
  }
  /// method to get the function name from where the exception was thrown
  /// @return the function name
  const char *get_func() const { return func; }

  /// method to get the line from where the exception was thrown
  /// @return the line
  int get_line() const { return line; }

  /// method to get the additional information about the error leading to the
  /// exception
  /// @return the information given about the error
  const char *get_info() { return info; }

  /// overloaded method from the base Exception class to return an error message
  /// @return the error message of the exception
  virtual const char *what() const throw() { return error_msg.c_str(); }

  /// retrieve error id for Fortran interface
  /// @return error id from ErrorID enum
  int get_error_id() { return static_cast<int>(error_id); }
};

/// Exception to be used for missmatches in dimension for ALL::Point class
struct PointDimensionMissmatchException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  PointDimensionMissmatchException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Dimension missmatch in Point objects.",
      const char *loc_desc_ = "ALLPointDimMissmatchException",
      const ErrorID error_id_ = ErrorID::PointDimensionMissmatch)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid Communicators in a load-balancing method
struct InvalidCommTypeException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidCommTypeException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Type of MPI communicator not valid.",
      const char *loc_desc_ = "ALLCommTypeInvalidException",
      const ErrorID error_id_ = ErrorID::InvalidCommType)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid parameters in any type of classes
struct InvalidArgumentException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidArgumentException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Invalid argument given.",
      const char *loc_desc_ = "ALLInvalidArgumentException",
      const ErrorID error_id_ = ErrorID::InvalidArgument)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an array went out of bounds
struct OutOfBoundsException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  OutOfBoundsException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Access to array out of bounds.",
      const char *loc_desc_ = "ALLOutOfBoundsErrorException",
      const ErrorID error_id_ = ErrorID::OutOfBounds)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an internal error has occured
struct InternalErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InternalErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Internal error occured, see description.",
      const char *loc_desc_ = "ALLInternalErrorException",
      const ErrorID error_id_ = ErrorID::InternalError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if a filesystem error has occured
struct FilesystemErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  FilesystemErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Filesystem error occured, see description.",
      const char *loc_desc_ = "ALLFilesystemErrorException",
      const ErrorID error_id_ = ErrorID::FilesystemError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

}//namespace ALL

#endif

#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace ALL {

template <class T> class Point;
template <typename T>
std::ostream &operator<<(std::ostream &, const Point<T> &);

/// @tparam T floating point type used, has to be identical to the type used for
/// the vertices and borders
template <class T> class Point {
public:
  /// default constructor
  Point() : dimension(0) {}
  /// constructor
  /// @param d dimension of the point object
  Point(const int d) : dimension(d) {
    coordinates.resize(d);
    weight = (T)1;
  }
  /// constructor with initialization
  /// @param d dimension of the point object
  /// @param data positions
  Point(const int d, const T *data) : Point<T>(d) {
    // copy each element of the array into the vector (insecure, no boundary
    // checks for data!)
    for (auto i = 0; i < d; ++i)
      coordinates.at(i) = data[i];
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  Point(const std::vector<T> &data) {
    // initialize the coordinates vector with the data vector
    coordinates.insert(coordinates.begin(), data.begin(), data.end());
    // update the dimension with the size of the data vector
    dimension = data.size();
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  Point(const int d, const T *data, const T w) : Point<T>(d, data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  /// @param i index of the point
  Point(const int d, const T *data, const T w, const long i)
      : Point<T>(d, data, w) {
    id = i;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  Point(const std::vector<T> &data, const T w) : Point<T>(data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  /// @param i index of the point
  Point(const std::vector<T> &data, const T w, const long i)
      : Point<T>(data, w) {
    id = i;
  }

  /// destructor
  ~Point<T>(){};

  // TODO: return values to check if operation was successful?
  /// method to change the dimension of the point object
  /// @param d new dimension
  void setDimension(const int d) {
    dimension = d;
    coordinates.resize(d);
  }

  /// method to change the weight of the point object
  /// @param w new weight
  void set_weight(const T w) { weight = w; }

  /// method to change the index of the particle
  /// @param i new index
  void set_id(const long i) { id = i; }

  /// access operator to access an element of the point object
  /// @param idx the index of the element to be accessed
  /// @result reference to the indexed element
  T &operator[](const std::size_t idx) { return coordinates.at(idx); }

  /// access operator to access an element of the constant point object
  /// @param idx the index of the element to be accessed
  /// @result const reference to the indexed element
  const T &operator[](const std::size_t idx) const {
    return coordinates.at(idx);
  }

  /// method to get the weight of the point object
  /// @return the weight of the point object
  T getWeight() const { return weight; }

  /// method to get the index of the point object
  /// @return the index of the point object
  long get_id() const { return id; }

  /// method to get the dimension of the point object
  /// @return the dimension of the point object
  int getDimension() const { return dimension; }

  /// method to compute the norm of the vector described by the
  /// point object
  /// @param nd type of the norm (default: 2, i.e. the Euclidean norm)
  /// @return norm of the vector
  T norm(T nd = 2) {
    T res = 0;
    for (int d = 0; d < dimension; ++d)
      res += std::pow(coordinates.at(d), nd);
    return std::pow(res, 1.0 / nd);
  }

  /// method to compute the Euclidean distance (two-norm) between the local and
  /// the provided point object
  /// @param p the point object for which the distence to the local point object
  /// is computed
  /// @return the distance between the two points
  T d(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p).norm();
  }

  /// method to compute the Manhatten / city-block distance (one-norm) between
  /// the local and the provided point object
  /// @param p the point object for which the distance to the local point object
  /// is computed
  /// @return the distance between the two points
  T d_1(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p, 1).norm();
  }

  /// method to compute the distance vector between the local point object and
  /// the provided point object
  /// @param p the point object for which the distance vector to the local point
  /// object is computed
  /// @return the distance vector between the two points
  Point<T> dist(Point<T> &p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    std::vector<T> d_v;
    for (int d = 0; d < dimension; ++d)
      d_v.push_back(p[d] - coordinates.at(d));

    return Point<T>(d_v);
  }

  /// method to compute the distance of the local point object from a plane
  /// spanned by provided points
  /// @param A anchor point for the plane
  /// @param B anchor point for the plane
  /// @param C anchor point for the plane
  /// @return distance between local point object and plane
  T dist_plane(const Point<T> &A, const Point<T> &B,
               const Point<T> &C) {

    if (A.getDimension() != dimension || B.getDimension() != dimension ||
        C.getDimension() != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);

    // vectors spanning the plane from vertex 'a'
    T vb[3];
    T vc[3];

    for (int i = 0; i < 3; ++i) {
      vb[i] = B[i] - A[i];
      vc[i] = C[i] - A[i];
    }

    // normal vector of plane
    T n[3];

    n[0] = vb[1] * vc[2] - vb[2] * vc[1];
    n[1] = vb[2] * vc[0] - vb[0] * vc[2];
    n[2] = vb[0] * vc[1] - vb[1] * vc[0];

    // length of normal vector
    T dn = n.norm();

    // distance from origin
    T d = n * A;

    // compute distance of test vertex to plane
    return std::abs((n[0] * coordinates.at(0) + n[1] * coordinates.at(1) +
                     n[2] * coordinates.at(2) - d) /
                    dn);
  }

  /// operator for the addition of two point objects
  /// @param rhs point to add the local point object to
  /// @return sum of local point object and provided point object
  Point<T> operator+(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) + rhs[d];
    }
    return result;
  }

  /// operator for the addition of two point objects
  /// @param rhs point to subtract from the local point object
  /// @return difference vector between local point object and provided point
  /// object
  Point<T> operator-(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) - rhs[d];
    }
    return result;
  }

  /// operator to compute the dot product between two point objects
  /// @param rhs point object to compute the dot product with
  /// @return dot product between the two point objects
  T operator*(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    T result = (T)0.0;
    for (int d = 0; d < dimension; ++d) {
      result += coordinates.at(d) * rhs[d];
    }
    return result;
  }

  /// operator to scale the local point object by a provided factor
  /// @param rhs scaling factor
  /// @return scaled point object
  Point<T> operator*(const T &rhs) const {
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) * rhs;
    }
    return result;
  }

  /// operator to compute the cross product between two point objects
  /// @param rhs point object to compute the cross product with
  /// @return cross product between the two point objects
  /// @attention only works for 3D points / vectors
  Point<T> cross(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension && dimension != 3) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at((d + 1) % 3) * rhs[(d + 2) % 3] -
                  coordinates.at((d + 2) % 3) * rhs[(d + 1) % 3];
    }
    return result;
  }

  /// method to determine if the local point object has the same orientation to
  /// a plane spanned by point objects A,B,C as the provided point P
  /// @param A anchor point A
  /// @param B anchor point B
  /// @param C anchor point C
  /// @param P reference point P
  /// @return the local point object has the same orientation to the plane as
  /// @attention if the reference point is located within the plane, it will not
  /// have the same orientation as the local point! the reference point
  bool same_side_plane(const Point<T> &A, const Point<T> &B,
                       const Point<T> &C, const Point<T> &P) {
    // compute difference vectors:
    Point<T> BA = B - A;
    Point<T> CA = C - A;
    Point<T> PA = P - A;
    Point<T> tA = *(this) - A;

    // compute normal vector of plane
    Point<T> n = CA.cross(BA);

    // compute scalar product of distance
    // vectors with normal vector
    T PAn = PA * n;
    T tAn = tA * n;

    return ((PAn * tAn) > 0);
  }

  /// method to check if the local point object is inside a tetrahedron
  /// described by the vertices A,B,C and D
  /// @param A vertex A
  /// @param B vertex B
  /// @param C vertex C
  /// @param D vertex D
  /// @return the point is within the tetrahedron
  /// @attention a point that is on the surface of the tetrahedron is not inside
  /// it
  bool inTetrahedron(const Point<T> &A, const Point<T> &B,
                     const Point<T> &C, const Point<T> &D) {
    /// for all surfaces of the tetrahedron check if the local point has the
    /// same orientation as the remaining vertex of the tetrahedron, to be
    /// inside the tetrahedron that must be fulfilled
    return (same_side_plane(A, B, C, D) && same_side_plane(B, C, D, A) &&
            same_side_plane(C, D, A, B) && same_side_plane(A, D, B, C));
  };

private:
  /// dimension of the point object
  int dimension;
  /// index for the point
  long id;
  // array containg the coordinates
  std::vector<T> coordinates;
  /// weight of the point to be used if points are not to be equally considered
  /// in computations, e.g. if number of interactions are considered
  T weight;
};

/// output operator for a point object
/// @param os output stream the point object should be printed to
/// @param p the point object to be printed
/// @return the modified output stream
template <class T>
std::ostream &operator<<(std::ostream &os, const Point<T> &p) {
  for (int i = 0; i < p.getDimension(); ++i)
    os << p[i] << " ";
  os << p.getWeight();
  return os;
}

/// operator to scale a point by a factor (reversed way of notation T *
/// Point<T>)
/// @param lhs scaling factor
/// @param rhs the point object to be scaled
/// @param scaled point object
template <class T>
Point<T> operator*(const T &lhs, const Point<T> &rhs) {
  return rhs * lhs;
}

// template <class T>
// Point<T> operator/(const T &lhs, const Point<T> &rhs) {
//   return rhs * ((T)1 / lhs);
// }

}//namespace ALL

#endif

#include <mpi.h>
#include <vector>

namespace ALL {

/// @tparam T data for vertices and related data
/// @tparam W data for work and related data
template <class T, class W> class LB {
public:
  /// constructor for the basic load-balancing class, sets up parameters
  /// required by all balancing methods
  /// @param[in] dim dimension of the vertices used
  /// @param[in] g correction factor for the computation of shifts
  LB(const int dim, const T g) : gamma(g), dimension(dim) {
    // set allowed minimum size to zero
    minSize = std::vector<T>(dim, 0.0);
    periodicity.resize(dim);
    local_coords.resize(dim);
    global_dims.resize(dim);
    neighborVertices.resize(0);
  }

  /// destructor
  virtual ~LB() = default;

  /// abstract definition of the setup method
  virtual void setup() = 0;

  /// abstract definition of the balancing method
  virtual void balance(const int step) = 0;

  /// abstract definition of the method to get the neighbors of the local domain
  /// @result std::vector<int> to store the MPI ranks of the neighbors
  /// to
  virtual std::vector<int> &getNeighbors() = 0;

  /// method to update the vertices used for the balancing step, overwrites old
  /// set of vertices
  /// @param[in] vertices_in vector containg the new vertices to be used
  virtual void setVertices(const std::vector<Point<T>> &vertices_in) {
    // as a basic assumption the number of resulting vertices
    // is equal to the number of input vertices:
    // exceptions:
    //      VORONOI
    vertices = vertices_in;
    prevVertices = vertices_in;
  }

  /// method to set the dimension of the vertices
  /// @param[in] d the dimension to be used
  /// @attention most methods currently support 3D vertices only
  virtual void setDimension(const int d) { dimension = d; }

  /// method to get the dimension of the vertices
  /// @return the dimension of the vertices
  virtual int getDimension() { return dimension; }

  /// method to set the correction value gamma
  /// @param[in] g the correction value to use
  virtual void setGamma(const T g) { gamma = g; }

  /// method to get the correction value currently used
  /// @return the current correction value
  virtual const T getGamma() { return gamma; }

  /// method to set a multi-dimensional work for the local domain
  /// @param[in] w vector containing all the dimensions of the work to be used
  /// for the local domain
  virtual void setWork(const std::vector<W> &w) { work = w; }

  /// method to set a scalar work for the local domain
  /// @param[in] w value containing the work to be used for the local domain
  virtual void setWork(const W w) {
    work.resize(1);
    work.at(0) = w;
  }

  /// method to set the minimum domain size in each dimension
  /// @param[in] minSize the minimum size of a domain in all dimensions
  virtual void setMinDomainSize(const std::vector<T> &minSize) {
    this->minSize = minSize;
  }

  /// method to get the minimum domain size the balancing methods have to obey
  /// @return the minimum domain size allowed
  virtual const std::vector<T> &getMinDomainSize() { return minSize; }

  /// method to set the (orthogonal) size of the system
  /// @param[in] sysSize system size in all dimensions
  virtual void setSysSize(const std::vector<T> &newSysSize) {
    sysSize = newSysSize;
  }

  /// method to get the currently stored system size
  /// @return the currently stored system size
  virtual const std::vector<T> &getSysSize() { return sysSize; }

  /// method to get the currently stored work for the local process
  /// @return the currently stored work
  /// @attention always returns a std::vector, for scalar work, it has length 1
  virtual std::vector<W> &getWork() { return work; }

  /// method to get result vertices
  /// @return the resulting vertices after a balancing step
  virtual std::vector<Point<T>> &getVertices() { return vertices; }

  /// method to get the original vertices before the last balancing step
  /// @return the original unmodified vertices before the last balancing step
  /// @attention since the original and resulting vertices are set up in the
  /// balancing method, the result is undefined before calling the balancing
  /// method at least once
  virtual std::vector<Point<T>> &getPrevVertices() { return prevVertices; };

  /// method to set the MPI communicator to be used by the balancing method
  /// @param[in] comm the MPI communicator to be used
  virtual void setCommunicator(const MPI_Comm comm) {
    // store communicator
    globalComm = comm;
    // get local rank within communicator
    MPI_Comm_rank(comm, &localRank);
  }

  /// method the get the number of vertices stored for the local domain
  /// @return number of local vertices
  int getNVertices() { return vertices.size(); }

  /// method to set undefined method specific data, which is not shared between
  /// different methods but needs to be set by a unified interface
  /// @param[in] data the data be passed to the balancing method
  virtual void setAdditionalData(const void *data) = 0;

  /// method to provide a list of vertices describing the neighboring domains
  /// currently only implemented for VORONOI, as a means to get the anchor points
  /// of the surrounding domains
  std::vector<T> &getNeighborVertices() {
    return neighborVertices; }

protected:
  /// correction factor
  T gamma;
  /// dimension of the used vertices
  int dimension;
  /// used MPI communicator
  MPI_Comm globalComm;
  /// local rank in the used MPI communicator
  int localRank;
  /// minimum domain size
  /// @attention not all balancing method support this
  std::vector<T> minSize;
  /// (orthogonal) system size
  std::vector<T> sysSize;
  /// local work
  std::vector<W> work;
  /// local vertices after previous balancing step
  std::vector<Point<T>> vertices;
  /// original vertices before previous balancing step
  std::vector<Point<T>> prevVertices;
  /// dimensions of the global process grid
  std::vector<int> global_dims;
  /// cartesian coordinates of the local domain in the process grid
  std::vector<int> local_coords;
  /// periodicity of the MPI communicator / system
  std::vector<int> periodicity;
  /// vertices describing neighboring domains
  std::vector<T> neighborVertices;
  /// method the resize the vertex list
  /// @param [in] new_size the new size of the vertex list
  void resizeVertices(const int newSize) { vertices.resize(newSize); }

};

}//namespace ALL

#endif // ALL_LB_HEADER_INCLUDED

/*
Copyright 2020-2020 Stephan Schulz, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_DEFINES_HEADER_INCLUDED
#define ALL_DEFINES_HEADER_INCLUDED

#if defined(__clang__)
#define known_unused __attribute__((unused))

#elif defined(__INTEL_COMPILER)
#warning "The Intel compiler is not properly supported."
#define known_unused

#elif defined(__GNUC__) || defined(__GNUG__)
#define known_unused __attribute__((unused))

#elif defined(_MSC_VER)
#warning "The Microsoft compilers are not supported."
#define known_unused

#else
#warning "Unknown compilers are not supported."
#define known_unused

#endif

#endif//ALL_DEFINES_HEADER_INCLUDED

#include <exception>
#include <mpi.h>

namespace ALL {

/// Load-balancing scheme based on a independent local scheme, where the
/// workloads of domains are reduced over their cartesian position, on reduction
/// for each of the dimensions. These reduced values are then compared against
/// the values gathered for the neighbor domains. Then the boundaries between
/// the process groups are adjusted according to the ratio of cummulated work
/// loads on each of them. The border is shifted in the direction of the domain
/// with more cummulated work. This is independently done for each of the
/// dimensions.
/// @tparam T data for vertices and related data
/// @tparam W data for work and related data
template <class T, class W> class Tensor_LB : public LB<T, W> {
public:
  /// default constuctor
  Tensor_LB() {}
  /// constructor to initialize values
  /// @param[in] d dimension of the vertices used
  /// @param[in] w the local (scalar) work load
  /// @param[in] g the correction factor
  Tensor_LB(int d, W w, T g) : LB<T, W>(d, g) {
    this->setWork(w);
    // need the lower and upper bounds
    // of the domain for the tensor-based
    // load-balancing scheme

    // array of MPI communicators for each direction (to collect work
    // on each plane)
    communicators.resize(d);
    nNeighbors.resize(2 * d);
  }

  /// default destructor
  ~Tensor_LB() = default;

  /// setup internal data structures and parameters
  void setup() override;

  /// method to execute a load-balancing step
  /// @param[in] step number of the load-balancing step
  virtual void balance(int step) override;

  // getter for variables (passed by reference to avoid
  // direct access to private members of the object)

  /// method to provide a list of the neighbors of the local domain
  /// @param[out] list reference to a std::vector of integers where the list of
  /// neighbors will be assigned to
  virtual std::vector<int> &getNeighbors() override;

  /// method to set specific data structures (unused for tensor grid method)
  /// @param[in] data pointer to the data structure
  virtual void setAdditionalData(known_unused const void *data) override {}

private:
  // type for MPI communication
  MPI_Datatype MPIDataTypeT;
  MPI_Datatype MPIDataTypeW;

  // array of MPI communicators for each direction (to collect work
  // on each plane)
  std::vector<MPI_Comm> communicators;

  // list of neighbors
  std::vector<int> neighbors;
  std::vector<int> nNeighbors;
};

// setup routine for the tensor-based load-balancing scheme
// requires:
//              this->globalComm (int): cartesian MPI communicator, from
//                                 which separate sub communicators
//                                 are derived in order to represent
//                                 each plane of domains in the system
template <class T, class W> void Tensor_LB<T, W>::setup() {
  int status;

  // check if Communicator is cartesian
  MPI_Topo_test(this->globalComm, &status);
  if (status != MPI_CART) {
    throw InvalidCommTypeException(
        __FILE__, __func__, __LINE__,
        "Cartesian MPI communicator required, passed communicator not "
        "cartesian");
  }

  int dim = this->getDimension();

  // get the local coordinates, periodicity and global size from the MPI
  // communicator
  MPI_Cart_get(this->globalComm, dim, this->global_dims.data(),
               this->periodicity.data(), this->local_coords.data());

  // get the local rank from the MPI communicator
  MPI_Cart_rank(this->globalComm, this->local_coords.data(), &this->localRank);

  // create sub-communicators
  for (int i = 0; i < dim; ++i) {
    MPI_Comm_split(this->globalComm, this->local_coords.at(i), 0,
                   &communicators[i]);
  }

  // determine correct MPI data type for template T
  if (std::is_same<T, double>::value)
    MPIDataTypeT = MPI_DOUBLE;
  else if (std::is_same<T, float>::value)
    MPIDataTypeT = MPI_FLOAT;
  else if (std::is_same<T, int>::value)
    MPIDataTypeT = MPI_INT;
  else if (std::is_same<T, long>::value)
    MPIDataTypeT = MPI_LONG;

  // determine correct MPI data type for template W
  if (std::is_same<W, double>::value)
    MPIDataTypeW = MPI_DOUBLE;
  else if (std::is_same<W, float>::value)
    MPIDataTypeW = MPI_FLOAT;
  else if (std::is_same<W, int>::value)
    MPIDataTypeW = MPI_INT;
  else if (std::is_same<W, long>::value)
    MPIDataTypeW = MPI_LONG;

  // calculate neighbors
  int rank_left, rank_right;

  neighbors.clear();
  for (int i = 0; i < dim; ++i) {
    MPI_Cart_shift(this->globalComm, i, 1, &rank_left, &rank_right);
    neighbors.push_back(rank_left);
    neighbors.push_back(rank_right);
    nNeighbors[2 * i] = 1;
    nNeighbors[2 * i + 1] = 1;
  }
}

template <class T, class W> void Tensor_LB<T, W>::balance(int) {
  int dim = this->getDimension();
  this->prevVertices = this->vertices;

  // loop over all available dimensions
  for (int i = 0; i < dim; ++i) {
    W work_local_plane;
    // collect work from all processes in the same plane
    MPI_Allreduce(this->getWork().data(), &work_local_plane, 1, MPIDataTypeW,
                  MPI_SUM, communicators.at(i));

    // correct right border:

    W remote_work;
    T local_size;
    T remote_size;
    // determine neighbors
    int rank_left, rank_right;

    MPI_Cart_shift(this->globalComm, i, 1, &rank_left, &rank_right);

    // collect work from right neighbor plane
    MPI_Request sreq, rreq;
    MPI_Status sstat, rstat;

    MPI_Irecv(&remote_work, 1, MPIDataTypeW, rank_right, 0, this->globalComm,
              &rreq);
    MPI_Isend(&work_local_plane, 1, MPIDataTypeW, rank_left, 0,
              this->globalComm, &sreq);
    MPI_Wait(&sreq, &sstat);
    MPI_Wait(&rreq, &rstat);

    // collect size in dimension from right neighbor plane

    local_size = this->prevVertices.at(1)[i] - this->prevVertices.at(0)[i];

    MPI_Irecv(&remote_size, 1, MPIDataTypeT, rank_right, 0, this->globalComm,
              &rreq);
    MPI_Isend(&local_size, 1, MPIDataTypeT, rank_left, 0, this->globalComm,
              &sreq);
    MPI_Wait(&sreq, &sstat);
    MPI_Wait(&rreq, &rstat);

    // automatic selection of gamma to guarantee stability of method (choice of
    // user gamma ignored)
    this->gamma =
        std::max(4.1, 2.0 * (1.0 + std::max(local_size, remote_size) /
                                       std::min(local_size, remote_size)));

    T shift = Functions::borderShift1d(
        rank_right, this->local_coords.at(i), this->global_dims.at(i),
        work_local_plane, remote_work, local_size, remote_size, this->gamma,
        this->minSize[i]);

    // send shift to right neighbors
    T remote_shift = (T)0;

    MPI_Irecv(&remote_shift, 1, MPIDataTypeT, rank_left, 0, this->globalComm,
              &rreq);
    MPI_Isend(&shift, 1, MPIDataTypeT, rank_right, 0, this->globalComm, &sreq);
    MPI_Wait(&sreq, &sstat);
    MPI_Wait(&rreq, &rstat);

    // if a left neighbor exists: shift left border
    if (rank_left != MPI_PROC_NULL && this->local_coords[i] != 0)
      this->vertices.at(0)[i] = this->prevVertices.at(0)[i] + remote_shift;
    else
      this->vertices.at(0)[i] = this->prevVertices.at(0)[i];

    // if a right neighbor exists: shift right border
    if (rank_right != MPI_PROC_NULL &&
        this->local_coords[i] != this->global_dims[i] - 1)
      this->vertices.at(1)[i] = this->prevVertices.at(1)[i] + shift;
    else
      this->vertices.at(1)[i] = this->prevVertices.at(1)[i];
  }
}

// provide list of neighbors
template <class T, class W>
std::vector<int> &Tensor_LB<T, W>::getNeighbors() {
  return neighbors;
}

}//namespace ALL

#endif

#ifdef ALL_VORONOI_ACTIVE
/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_VORONOI_HEADER_INCLUDED
#define ALL_VORONOI_HEADER_INCLUDED

// number of maximum neighboring Voronoi cells
#define ALL_VORONOI_MAX_NEIGHBORS 32
// number of subblock division for Voronoi cell creation
#define ALL_VORONOI_SUBBLOCKS 20

// depth used to find neighbor cells
#define ALL_VORONOI_NEIGHBOR_SEARCH_DEPTH 2

#ifdef ALL_VORONOI_ACTIVE
/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_CUSTOM_EXCEPTIONS_INC
#define ALL_CUSTOM_EXCEPTIONS_INC

#include <exception>
#include <sstream>
#include <string>

namespace ALL {

/// Customized exceptions for ALL, modified for each specific exception type
struct CustomException : public std::exception {
protected:
  /// file the exception occured in
  const char *file;
  /// function the exception occured in
  const char *func;
  /// line the exception occured in
  int line;
  /// information on the exception
  const char *info;
  /// name of the exception
  const char *loc_desc;
  /// error message
  std::string error_msg;
  /// error identificators for Fortran error retrieval, remember to
  /// update the Fortran module as well!
  enum struct ErrorID : int {
	Generic = 1,
	PointDimensionMissmatch,
	InvalidCommType,
	InvalidArgument,
	OutOfBounds,
	InternalError,
	FilesystemError
  };
  /// error identificator retrieved by Fortran
  ErrorID error_id;

public:
  /// constructor for an exception used in ALL
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  CustomException(const char *file_ = "", const char *f_ = "", int l_ = -1,
                      const char *i_ = "",
                      const char *loc_desc_ = "ALLCustomException",
		      const ErrorID error_id_ = ErrorID::Generic)
      : file(file_), func(f_), line(l_), info(i_), loc_desc(loc_desc_), error_id(error_id_) {
    std::stringstream ss;
    ss << loc_desc << ": " << info << "\n"
       << "Function: " << func << "\n"
       << "File: " << file << "\n"
       << "Line: " << line << "\n";
    error_msg = ss.str();
  }
  /// method to get the function name from where the exception was thrown
  /// @return the function name
  const char *get_func() const { return func; }

  /// method to get the line from where the exception was thrown
  /// @return the line
  int get_line() const { return line; }

  /// method to get the additional information about the error leading to the
  /// exception
  /// @return the information given about the error
  const char *get_info() { return info; }

  /// overloaded method from the base Exception class to return an error message
  /// @return the error message of the exception
  virtual const char *what() const throw() { return error_msg.c_str(); }

  /// retrieve error id for Fortran interface
  /// @return error id from ErrorID enum
  int get_error_id() { return static_cast<int>(error_id); }
};

/// Exception to be used for missmatches in dimension for ALL::Point class
struct PointDimensionMissmatchException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  PointDimensionMissmatchException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Dimension missmatch in Point objects.",
      const char *loc_desc_ = "ALLPointDimMissmatchException",
      const ErrorID error_id_ = ErrorID::PointDimensionMissmatch)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid Communicators in a load-balancing method
struct InvalidCommTypeException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidCommTypeException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Type of MPI communicator not valid.",
      const char *loc_desc_ = "ALLCommTypeInvalidException",
      const ErrorID error_id_ = ErrorID::InvalidCommType)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid parameters in any type of classes
struct InvalidArgumentException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidArgumentException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Invalid argument given.",
      const char *loc_desc_ = "ALLInvalidArgumentException",
      const ErrorID error_id_ = ErrorID::InvalidArgument)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an array went out of bounds
struct OutOfBoundsException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  OutOfBoundsException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Access to array out of bounds.",
      const char *loc_desc_ = "ALLOutOfBoundsErrorException",
      const ErrorID error_id_ = ErrorID::OutOfBounds)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an internal error has occured
struct InternalErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InternalErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Internal error occured, see description.",
      const char *loc_desc_ = "ALLInternalErrorException",
      const ErrorID error_id_ = ErrorID::InternalError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if a filesystem error has occured
struct FilesystemErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  FilesystemErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Filesystem error occured, see description.",
      const char *loc_desc_ = "ALLFilesystemErrorException",
      const ErrorID error_id_ = ErrorID::FilesystemError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

}//namespace ALL

#endif

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_LB_HEADER_INCLUDED
#define ALL_LB_HEADER_INCLUDED

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_POINT_HEADER_INC
#define ALL_POINT_HEADER_INC

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_CUSTOM_EXCEPTIONS_INC
#define ALL_CUSTOM_EXCEPTIONS_INC

#include <exception>
#include <sstream>
#include <string>

namespace ALL {

/// Customized exceptions for ALL, modified for each specific exception type
struct CustomException : public std::exception {
protected:
  /// file the exception occured in
  const char *file;
  /// function the exception occured in
  const char *func;
  /// line the exception occured in
  int line;
  /// information on the exception
  const char *info;
  /// name of the exception
  const char *loc_desc;
  /// error message
  std::string error_msg;
  /// error identificators for Fortran error retrieval, remember to
  /// update the Fortran module as well!
  enum struct ErrorID : int {
	Generic = 1,
	PointDimensionMissmatch,
	InvalidCommType,
	InvalidArgument,
	OutOfBounds,
	InternalError,
	FilesystemError
  };
  /// error identificator retrieved by Fortran
  ErrorID error_id;

public:
  /// constructor for an exception used in ALL
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  CustomException(const char *file_ = "", const char *f_ = "", int l_ = -1,
                      const char *i_ = "",
                      const char *loc_desc_ = "ALLCustomException",
		      const ErrorID error_id_ = ErrorID::Generic)
      : file(file_), func(f_), line(l_), info(i_), loc_desc(loc_desc_), error_id(error_id_) {
    std::stringstream ss;
    ss << loc_desc << ": " << info << "\n"
       << "Function: " << func << "\n"
       << "File: " << file << "\n"
       << "Line: " << line << "\n";
    error_msg = ss.str();
  }
  /// method to get the function name from where the exception was thrown
  /// @return the function name
  const char *get_func() const { return func; }

  /// method to get the line from where the exception was thrown
  /// @return the line
  int get_line() const { return line; }

  /// method to get the additional information about the error leading to the
  /// exception
  /// @return the information given about the error
  const char *get_info() { return info; }

  /// overloaded method from the base Exception class to return an error message
  /// @return the error message of the exception
  virtual const char *what() const throw() { return error_msg.c_str(); }

  /// retrieve error id for Fortran interface
  /// @return error id from ErrorID enum
  int get_error_id() { return static_cast<int>(error_id); }
};

/// Exception to be used for missmatches in dimension for ALL::Point class
struct PointDimensionMissmatchException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  PointDimensionMissmatchException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Dimension missmatch in Point objects.",
      const char *loc_desc_ = "ALLPointDimMissmatchException",
      const ErrorID error_id_ = ErrorID::PointDimensionMissmatch)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid Communicators in a load-balancing method
struct InvalidCommTypeException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidCommTypeException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Type of MPI communicator not valid.",
      const char *loc_desc_ = "ALLCommTypeInvalidException",
      const ErrorID error_id_ = ErrorID::InvalidCommType)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid parameters in any type of classes
struct InvalidArgumentException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidArgumentException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Invalid argument given.",
      const char *loc_desc_ = "ALLInvalidArgumentException",
      const ErrorID error_id_ = ErrorID::InvalidArgument)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an array went out of bounds
struct OutOfBoundsException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  OutOfBoundsException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Access to array out of bounds.",
      const char *loc_desc_ = "ALLOutOfBoundsErrorException",
      const ErrorID error_id_ = ErrorID::OutOfBounds)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an internal error has occured
struct InternalErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InternalErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Internal error occured, see description.",
      const char *loc_desc_ = "ALLInternalErrorException",
      const ErrorID error_id_ = ErrorID::InternalError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if a filesystem error has occured
struct FilesystemErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  FilesystemErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Filesystem error occured, see description.",
      const char *loc_desc_ = "ALLFilesystemErrorException",
      const ErrorID error_id_ = ErrorID::FilesystemError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

}//namespace ALL

#endif

#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace ALL {

template <class T> class Point;
template <typename T>
std::ostream &operator<<(std::ostream &, const Point<T> &);

/// @tparam T floating point type used, has to be identical to the type used for
/// the vertices and borders
template <class T> class Point {
public:
  /// default constructor
  Point() : dimension(0) {}
  /// constructor
  /// @param d dimension of the point object
  Point(const int d) : dimension(d) {
    coordinates.resize(d);
    weight = (T)1;
  }
  /// constructor with initialization
  /// @param d dimension of the point object
  /// @param data positions
  Point(const int d, const T *data) : Point<T>(d) {
    // copy each element of the array into the vector (insecure, no boundary
    // checks for data!)
    for (auto i = 0; i < d; ++i)
      coordinates.at(i) = data[i];
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  Point(const std::vector<T> &data) {
    // initialize the coordinates vector with the data vector
    coordinates.insert(coordinates.begin(), data.begin(), data.end());
    // update the dimension with the size of the data vector
    dimension = data.size();
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  Point(const int d, const T *data, const T w) : Point<T>(d, data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  /// @param i index of the point
  Point(const int d, const T *data, const T w, const long i)
      : Point<T>(d, data, w) {
    id = i;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  Point(const std::vector<T> &data, const T w) : Point<T>(data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  /// @param i index of the point
  Point(const std::vector<T> &data, const T w, const long i)
      : Point<T>(data, w) {
    id = i;
  }

  /// destructor
  ~Point<T>(){};

  // TODO: return values to check if operation was successful?
  /// method to change the dimension of the point object
  /// @param d new dimension
  void setDimension(const int d) {
    dimension = d;
    coordinates.resize(d);
  }

  /// method to change the weight of the point object
  /// @param w new weight
  void set_weight(const T w) { weight = w; }

  /// method to change the index of the particle
  /// @param i new index
  void set_id(const long i) { id = i; }

  /// access operator to access an element of the point object
  /// @param idx the index of the element to be accessed
  /// @result reference to the indexed element
  T &operator[](const std::size_t idx) { return coordinates.at(idx); }

  /// access operator to access an element of the constant point object
  /// @param idx the index of the element to be accessed
  /// @result const reference to the indexed element
  const T &operator[](const std::size_t idx) const {
    return coordinates.at(idx);
  }

  /// method to get the weight of the point object
  /// @return the weight of the point object
  T getWeight() const { return weight; }

  /// method to get the index of the point object
  /// @return the index of the point object
  long get_id() const { return id; }

  /// method to get the dimension of the point object
  /// @return the dimension of the point object
  int getDimension() const { return dimension; }

  /// method to compute the norm of the vector described by the
  /// point object
  /// @param nd type of the norm (default: 2, i.e. the Euclidean norm)
  /// @return norm of the vector
  T norm(T nd = 2) {
    T res = 0;
    for (int d = 0; d < dimension; ++d)
      res += std::pow(coordinates.at(d), nd);
    return std::pow(res, 1.0 / nd);
  }

  /// method to compute the Euclidean distance (two-norm) between the local and
  /// the provided point object
  /// @param p the point object for which the distence to the local point object
  /// is computed
  /// @return the distance between the two points
  T d(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p).norm();
  }

  /// method to compute the Manhatten / city-block distance (one-norm) between
  /// the local and the provided point object
  /// @param p the point object for which the distance to the local point object
  /// is computed
  /// @return the distance between the two points
  T d_1(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p, 1).norm();
  }

  /// method to compute the distance vector between the local point object and
  /// the provided point object
  /// @param p the point object for which the distance vector to the local point
  /// object is computed
  /// @return the distance vector between the two points
  Point<T> dist(Point<T> &p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    std::vector<T> d_v;
    for (int d = 0; d < dimension; ++d)
      d_v.push_back(p[d] - coordinates.at(d));

    return Point<T>(d_v);
  }

  /// method to compute the distance of the local point object from a plane
  /// spanned by provided points
  /// @param A anchor point for the plane
  /// @param B anchor point for the plane
  /// @param C anchor point for the plane
  /// @return distance between local point object and plane
  T dist_plane(const Point<T> &A, const Point<T> &B,
               const Point<T> &C) {

    if (A.getDimension() != dimension || B.getDimension() != dimension ||
        C.getDimension() != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);

    // vectors spanning the plane from vertex 'a'
    T vb[3];
    T vc[3];

    for (int i = 0; i < 3; ++i) {
      vb[i] = B[i] - A[i];
      vc[i] = C[i] - A[i];
    }

    // normal vector of plane
    T n[3];

    n[0] = vb[1] * vc[2] - vb[2] * vc[1];
    n[1] = vb[2] * vc[0] - vb[0] * vc[2];
    n[2] = vb[0] * vc[1] - vb[1] * vc[0];

    // length of normal vector
    T dn = n.norm();

    // distance from origin
    T d = n * A;

    // compute distance of test vertex to plane
    return std::abs((n[0] * coordinates.at(0) + n[1] * coordinates.at(1) +
                     n[2] * coordinates.at(2) - d) /
                    dn);
  }

  /// operator for the addition of two point objects
  /// @param rhs point to add the local point object to
  /// @return sum of local point object and provided point object
  Point<T> operator+(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) + rhs[d];
    }
    return result;
  }

  /// operator for the addition of two point objects
  /// @param rhs point to subtract from the local point object
  /// @return difference vector between local point object and provided point
  /// object
  Point<T> operator-(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) - rhs[d];
    }
    return result;
  }

  /// operator to compute the dot product between two point objects
  /// @param rhs point object to compute the dot product with
  /// @return dot product between the two point objects
  T operator*(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    T result = (T)0.0;
    for (int d = 0; d < dimension; ++d) {
      result += coordinates.at(d) * rhs[d];
    }
    return result;
  }

  /// operator to scale the local point object by a provided factor
  /// @param rhs scaling factor
  /// @return scaled point object
  Point<T> operator*(const T &rhs) const {
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) * rhs;
    }
    return result;
  }

  /// operator to compute the cross product between two point objects
  /// @param rhs point object to compute the cross product with
  /// @return cross product between the two point objects
  /// @attention only works for 3D points / vectors
  Point<T> cross(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension && dimension != 3) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at((d + 1) % 3) * rhs[(d + 2) % 3] -
                  coordinates.at((d + 2) % 3) * rhs[(d + 1) % 3];
    }
    return result;
  }

  /// method to determine if the local point object has the same orientation to
  /// a plane spanned by point objects A,B,C as the provided point P
  /// @param A anchor point A
  /// @param B anchor point B
  /// @param C anchor point C
  /// @param P reference point P
  /// @return the local point object has the same orientation to the plane as
  /// @attention if the reference point is located within the plane, it will not
  /// have the same orientation as the local point! the reference point
  bool same_side_plane(const Point<T> &A, const Point<T> &B,
                       const Point<T> &C, const Point<T> &P) {
    // compute difference vectors:
    Point<T> BA = B - A;
    Point<T> CA = C - A;
    Point<T> PA = P - A;
    Point<T> tA = *(this) - A;

    // compute normal vector of plane
    Point<T> n = CA.cross(BA);

    // compute scalar product of distance
    // vectors with normal vector
    T PAn = PA * n;
    T tAn = tA * n;

    return ((PAn * tAn) > 0);
  }

  /// method to check if the local point object is inside a tetrahedron
  /// described by the vertices A,B,C and D
  /// @param A vertex A
  /// @param B vertex B
  /// @param C vertex C
  /// @param D vertex D
  /// @return the point is within the tetrahedron
  /// @attention a point that is on the surface of the tetrahedron is not inside
  /// it
  bool inTetrahedron(const Point<T> &A, const Point<T> &B,
                     const Point<T> &C, const Point<T> &D) {
    /// for all surfaces of the tetrahedron check if the local point has the
    /// same orientation as the remaining vertex of the tetrahedron, to be
    /// inside the tetrahedron that must be fulfilled
    return (same_side_plane(A, B, C, D) && same_side_plane(B, C, D, A) &&
            same_side_plane(C, D, A, B) && same_side_plane(A, D, B, C));
  };

private:
  /// dimension of the point object
  int dimension;
  /// index for the point
  long id;
  // array containg the coordinates
  std::vector<T> coordinates;
  /// weight of the point to be used if points are not to be equally considered
  /// in computations, e.g. if number of interactions are considered
  T weight;
};

/// output operator for a point object
/// @param os output stream the point object should be printed to
/// @param p the point object to be printed
/// @return the modified output stream
template <class T>
std::ostream &operator<<(std::ostream &os, const Point<T> &p) {
  for (int i = 0; i < p.getDimension(); ++i)
    os << p[i] << " ";
  os << p.getWeight();
  return os;
}

/// operator to scale a point by a factor (reversed way of notation T *
/// Point<T>)
/// @param lhs scaling factor
/// @param rhs the point object to be scaled
/// @param scaled point object
template <class T>
Point<T> operator*(const T &lhs, const Point<T> &rhs) {
  return rhs * lhs;
}

// template <class T>
// Point<T> operator/(const T &lhs, const Point<T> &rhs) {
//   return rhs * ((T)1 / lhs);
// }

}//namespace ALL

#endif

#include <mpi.h>
#include <vector>

namespace ALL {

/// @tparam T data for vertices and related data
/// @tparam W data for work and related data
template <class T, class W> class LB {
public:
  /// constructor for the basic load-balancing class, sets up parameters
  /// required by all balancing methods
  /// @param[in] dim dimension of the vertices used
  /// @param[in] g correction factor for the computation of shifts
  LB(const int dim, const T g) : gamma(g), dimension(dim) {
    // set allowed minimum size to zero
    minSize = std::vector<T>(dim, 0.0);
    periodicity.resize(dim);
    local_coords.resize(dim);
    global_dims.resize(dim);
    neighborVertices.resize(0);
  }

  /// destructor
  virtual ~LB() = default;

  /// abstract definition of the setup method
  virtual void setup() = 0;

  /// abstract definition of the balancing method
  virtual void balance(const int step) = 0;

  /// abstract definition of the method to get the neighbors of the local domain
  /// @result std::vector<int> to store the MPI ranks of the neighbors
  /// to
  virtual std::vector<int> &getNeighbors() = 0;

  /// method to update the vertices used for the balancing step, overwrites old
  /// set of vertices
  /// @param[in] vertices_in vector containg the new vertices to be used
  virtual void setVertices(const std::vector<Point<T>> &vertices_in) {
    // as a basic assumption the number of resulting vertices
    // is equal to the number of input vertices:
    // exceptions:
    //      VORONOI
    vertices = vertices_in;
    prevVertices = vertices_in;
  }

  /// method to set the dimension of the vertices
  /// @param[in] d the dimension to be used
  /// @attention most methods currently support 3D vertices only
  virtual void setDimension(const int d) { dimension = d; }

  /// method to get the dimension of the vertices
  /// @return the dimension of the vertices
  virtual int getDimension() { return dimension; }

  /// method to set the correction value gamma
  /// @param[in] g the correction value to use
  virtual void setGamma(const T g) { gamma = g; }

  /// method to get the correction value currently used
  /// @return the current correction value
  virtual const T getGamma() { return gamma; }

  /// method to set a multi-dimensional work for the local domain
  /// @param[in] w vector containing all the dimensions of the work to be used
  /// for the local domain
  virtual void setWork(const std::vector<W> &w) { work = w; }

  /// method to set a scalar work for the local domain
  /// @param[in] w value containing the work to be used for the local domain
  virtual void setWork(const W w) {
    work.resize(1);
    work.at(0) = w;
  }

  /// method to set the minimum domain size in each dimension
  /// @param[in] minSize the minimum size of a domain in all dimensions
  virtual void setMinDomainSize(const std::vector<T> &minSize) {
    this->minSize = minSize;
  }

  /// method to get the minimum domain size the balancing methods have to obey
  /// @return the minimum domain size allowed
  virtual const std::vector<T> &getMinDomainSize() { return minSize; }

  /// method to set the (orthogonal) size of the system
  /// @param[in] sysSize system size in all dimensions
  virtual void setSysSize(const std::vector<T> &newSysSize) {
    sysSize = newSysSize;
  }

  /// method to get the currently stored system size
  /// @return the currently stored system size
  virtual const std::vector<T> &getSysSize() { return sysSize; }

  /// method to get the currently stored work for the local process
  /// @return the currently stored work
  /// @attention always returns a std::vector, for scalar work, it has length 1
  virtual std::vector<W> &getWork() { return work; }

  /// method to get result vertices
  /// @return the resulting vertices after a balancing step
  virtual std::vector<Point<T>> &getVertices() { return vertices; }

  /// method to get the original vertices before the last balancing step
  /// @return the original unmodified vertices before the last balancing step
  /// @attention since the original and resulting vertices are set up in the
  /// balancing method, the result is undefined before calling the balancing
  /// method at least once
  virtual std::vector<Point<T>> &getPrevVertices() { return prevVertices; };

  /// method to set the MPI communicator to be used by the balancing method
  /// @param[in] comm the MPI communicator to be used
  virtual void setCommunicator(const MPI_Comm comm) {
    // store communicator
    globalComm = comm;
    // get local rank within communicator
    MPI_Comm_rank(comm, &localRank);
  }

  /// method the get the number of vertices stored for the local domain
  /// @return number of local vertices
  int getNVertices() { return vertices.size(); }

  /// method to set undefined method specific data, which is not shared between
  /// different methods but needs to be set by a unified interface
  /// @param[in] data the data be passed to the balancing method
  virtual void setAdditionalData(const void *data) = 0;

  /// method to provide a list of vertices describing the neighboring domains
  /// currently only implemented for VORONOI, as a means to get the anchor points
  /// of the surrounding domains
  std::vector<T> &getNeighborVertices() {
    return neighborVertices; }

protected:
  /// correction factor
  T gamma;
  /// dimension of the used vertices
  int dimension;
  /// used MPI communicator
  MPI_Comm globalComm;
  /// local rank in the used MPI communicator
  int localRank;
  /// minimum domain size
  /// @attention not all balancing method support this
  std::vector<T> minSize;
  /// (orthogonal) system size
  std::vector<T> sysSize;
  /// local work
  std::vector<W> work;
  /// local vertices after previous balancing step
  std::vector<Point<T>> vertices;
  /// original vertices before previous balancing step
  std::vector<Point<T>> prevVertices;
  /// dimensions of the global process grid
  std::vector<int> global_dims;
  /// cartesian coordinates of the local domain in the process grid
  std::vector<int> local_coords;
  /// periodicity of the MPI communicator / system
  std::vector<int> periodicity;
  /// vertices describing neighboring domains
  std::vector<T> neighborVertices;
  /// method the resize the vertex list
  /// @param [in] new_size the new size of the vertex list
  void resizeVertices(const int newSize) { vertices.resize(newSize); }

};

}//namespace ALL

#endif // ALL_LB_HEADER_INCLUDED

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_POINT_HEADER_INC
#define ALL_POINT_HEADER_INC

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_CUSTOM_EXCEPTIONS_INC
#define ALL_CUSTOM_EXCEPTIONS_INC

#include <exception>
#include <sstream>
#include <string>

namespace ALL {

/// Customized exceptions for ALL, modified for each specific exception type
struct CustomException : public std::exception {
protected:
  /// file the exception occured in
  const char *file;
  /// function the exception occured in
  const char *func;
  /// line the exception occured in
  int line;
  /// information on the exception
  const char *info;
  /// name of the exception
  const char *loc_desc;
  /// error message
  std::string error_msg;
  /// error identificators for Fortran error retrieval, remember to
  /// update the Fortran module as well!
  enum struct ErrorID : int {
	Generic = 1,
	PointDimensionMissmatch,
	InvalidCommType,
	InvalidArgument,
	OutOfBounds,
	InternalError,
	FilesystemError
  };
  /// error identificator retrieved by Fortran
  ErrorID error_id;

public:
  /// constructor for an exception used in ALL
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  CustomException(const char *file_ = "", const char *f_ = "", int l_ = -1,
                      const char *i_ = "",
                      const char *loc_desc_ = "ALLCustomException",
		      const ErrorID error_id_ = ErrorID::Generic)
      : file(file_), func(f_), line(l_), info(i_), loc_desc(loc_desc_), error_id(error_id_) {
    std::stringstream ss;
    ss << loc_desc << ": " << info << "\n"
       << "Function: " << func << "\n"
       << "File: " << file << "\n"
       << "Line: " << line << "\n";
    error_msg = ss.str();
  }
  /// method to get the function name from where the exception was thrown
  /// @return the function name
  const char *get_func() const { return func; }

  /// method to get the line from where the exception was thrown
  /// @return the line
  int get_line() const { return line; }

  /// method to get the additional information about the error leading to the
  /// exception
  /// @return the information given about the error
  const char *get_info() { return info; }

  /// overloaded method from the base Exception class to return an error message
  /// @return the error message of the exception
  virtual const char *what() const throw() { return error_msg.c_str(); }

  /// retrieve error id for Fortran interface
  /// @return error id from ErrorID enum
  int get_error_id() { return static_cast<int>(error_id); }
};

/// Exception to be used for missmatches in dimension for ALL::Point class
struct PointDimensionMissmatchException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  PointDimensionMissmatchException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Dimension missmatch in Point objects.",
      const char *loc_desc_ = "ALLPointDimMissmatchException",
      const ErrorID error_id_ = ErrorID::PointDimensionMissmatch)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid Communicators in a load-balancing method
struct InvalidCommTypeException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidCommTypeException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Type of MPI communicator not valid.",
      const char *loc_desc_ = "ALLCommTypeInvalidException",
      const ErrorID error_id_ = ErrorID::InvalidCommType)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid parameters in any type of classes
struct InvalidArgumentException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidArgumentException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Invalid argument given.",
      const char *loc_desc_ = "ALLInvalidArgumentException",
      const ErrorID error_id_ = ErrorID::InvalidArgument)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an array went out of bounds
struct OutOfBoundsException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  OutOfBoundsException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Access to array out of bounds.",
      const char *loc_desc_ = "ALLOutOfBoundsErrorException",
      const ErrorID error_id_ = ErrorID::OutOfBounds)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an internal error has occured
struct InternalErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InternalErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Internal error occured, see description.",
      const char *loc_desc_ = "ALLInternalErrorException",
      const ErrorID error_id_ = ErrorID::InternalError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if a filesystem error has occured
struct FilesystemErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  FilesystemErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Filesystem error occured, see description.",
      const char *loc_desc_ = "ALLFilesystemErrorException",
      const ErrorID error_id_ = ErrorID::FilesystemError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

}//namespace ALL

#endif

#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace ALL {

template <class T> class Point;
template <typename T>
std::ostream &operator<<(std::ostream &, const Point<T> &);

/// @tparam T floating point type used, has to be identical to the type used for
/// the vertices and borders
template <class T> class Point {
public:
  /// default constructor
  Point() : dimension(0) {}
  /// constructor
  /// @param d dimension of the point object
  Point(const int d) : dimension(d) {
    coordinates.resize(d);
    weight = (T)1;
  }
  /// constructor with initialization
  /// @param d dimension of the point object
  /// @param data positions
  Point(const int d, const T *data) : Point<T>(d) {
    // copy each element of the array into the vector (insecure, no boundary
    // checks for data!)
    for (auto i = 0; i < d; ++i)
      coordinates.at(i) = data[i];
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  Point(const std::vector<T> &data) {
    // initialize the coordinates vector with the data vector
    coordinates.insert(coordinates.begin(), data.begin(), data.end());
    // update the dimension with the size of the data vector
    dimension = data.size();
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  Point(const int d, const T *data, const T w) : Point<T>(d, data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  /// @param i index of the point
  Point(const int d, const T *data, const T w, const long i)
      : Point<T>(d, data, w) {
    id = i;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  Point(const std::vector<T> &data, const T w) : Point<T>(data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  /// @param i index of the point
  Point(const std::vector<T> &data, const T w, const long i)
      : Point<T>(data, w) {
    id = i;
  }

  /// destructor
  ~Point<T>(){};

  // TODO: return values to check if operation was successful?
  /// method to change the dimension of the point object
  /// @param d new dimension
  void setDimension(const int d) {
    dimension = d;
    coordinates.resize(d);
  }

  /// method to change the weight of the point object
  /// @param w new weight
  void set_weight(const T w) { weight = w; }

  /// method to change the index of the particle
  /// @param i new index
  void set_id(const long i) { id = i; }

  /// access operator to access an element of the point object
  /// @param idx the index of the element to be accessed
  /// @result reference to the indexed element
  T &operator[](const std::size_t idx) { return coordinates.at(idx); }

  /// access operator to access an element of the constant point object
  /// @param idx the index of the element to be accessed
  /// @result const reference to the indexed element
  const T &operator[](const std::size_t idx) const {
    return coordinates.at(idx);
  }

  /// method to get the weight of the point object
  /// @return the weight of the point object
  T getWeight() const { return weight; }

  /// method to get the index of the point object
  /// @return the index of the point object
  long get_id() const { return id; }

  /// method to get the dimension of the point object
  /// @return the dimension of the point object
  int getDimension() const { return dimension; }

  /// method to compute the norm of the vector described by the
  /// point object
  /// @param nd type of the norm (default: 2, i.e. the Euclidean norm)
  /// @return norm of the vector
  T norm(T nd = 2) {
    T res = 0;
    for (int d = 0; d < dimension; ++d)
      res += std::pow(coordinates.at(d), nd);
    return std::pow(res, 1.0 / nd);
  }

  /// method to compute the Euclidean distance (two-norm) between the local and
  /// the provided point object
  /// @param p the point object for which the distence to the local point object
  /// is computed
  /// @return the distance between the two points
  T d(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p).norm();
  }

  /// method to compute the Manhatten / city-block distance (one-norm) between
  /// the local and the provided point object
  /// @param p the point object for which the distance to the local point object
  /// is computed
  /// @return the distance between the two points
  T d_1(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p, 1).norm();
  }

  /// method to compute the distance vector between the local point object and
  /// the provided point object
  /// @param p the point object for which the distance vector to the local point
  /// object is computed
  /// @return the distance vector between the two points
  Point<T> dist(Point<T> &p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    std::vector<T> d_v;
    for (int d = 0; d < dimension; ++d)
      d_v.push_back(p[d] - coordinates.at(d));

    return Point<T>(d_v);
  }

  /// method to compute the distance of the local point object from a plane
  /// spanned by provided points
  /// @param A anchor point for the plane
  /// @param B anchor point for the plane
  /// @param C anchor point for the plane
  /// @return distance between local point object and plane
  T dist_plane(const Point<T> &A, const Point<T> &B,
               const Point<T> &C) {

    if (A.getDimension() != dimension || B.getDimension() != dimension ||
        C.getDimension() != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);

    // vectors spanning the plane from vertex 'a'
    T vb[3];
    T vc[3];

    for (int i = 0; i < 3; ++i) {
      vb[i] = B[i] - A[i];
      vc[i] = C[i] - A[i];
    }

    // normal vector of plane
    T n[3];

    n[0] = vb[1] * vc[2] - vb[2] * vc[1];
    n[1] = vb[2] * vc[0] - vb[0] * vc[2];
    n[2] = vb[0] * vc[1] - vb[1] * vc[0];

    // length of normal vector
    T dn = n.norm();

    // distance from origin
    T d = n * A;

    // compute distance of test vertex to plane
    return std::abs((n[0] * coordinates.at(0) + n[1] * coordinates.at(1) +
                     n[2] * coordinates.at(2) - d) /
                    dn);
  }

  /// operator for the addition of two point objects
  /// @param rhs point to add the local point object to
  /// @return sum of local point object and provided point object
  Point<T> operator+(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) + rhs[d];
    }
    return result;
  }

  /// operator for the addition of two point objects
  /// @param rhs point to subtract from the local point object
  /// @return difference vector between local point object and provided point
  /// object
  Point<T> operator-(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) - rhs[d];
    }
    return result;
  }

  /// operator to compute the dot product between two point objects
  /// @param rhs point object to compute the dot product with
  /// @return dot product between the two point objects
  T operator*(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    T result = (T)0.0;
    for (int d = 0; d < dimension; ++d) {
      result += coordinates.at(d) * rhs[d];
    }
    return result;
  }

  /// operator to scale the local point object by a provided factor
  /// @param rhs scaling factor
  /// @return scaled point object
  Point<T> operator*(const T &rhs) const {
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) * rhs;
    }
    return result;
  }

  /// operator to compute the cross product between two point objects
  /// @param rhs point object to compute the cross product with
  /// @return cross product between the two point objects
  /// @attention only works for 3D points / vectors
  Point<T> cross(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension && dimension != 3) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at((d + 1) % 3) * rhs[(d + 2) % 3] -
                  coordinates.at((d + 2) % 3) * rhs[(d + 1) % 3];
    }
    return result;
  }

  /// method to determine if the local point object has the same orientation to
  /// a plane spanned by point objects A,B,C as the provided point P
  /// @param A anchor point A
  /// @param B anchor point B
  /// @param C anchor point C
  /// @param P reference point P
  /// @return the local point object has the same orientation to the plane as
  /// @attention if the reference point is located within the plane, it will not
  /// have the same orientation as the local point! the reference point
  bool same_side_plane(const Point<T> &A, const Point<T> &B,
                       const Point<T> &C, const Point<T> &P) {
    // compute difference vectors:
    Point<T> BA = B - A;
    Point<T> CA = C - A;
    Point<T> PA = P - A;
    Point<T> tA = *(this) - A;

    // compute normal vector of plane
    Point<T> n = CA.cross(BA);

    // compute scalar product of distance
    // vectors with normal vector
    T PAn = PA * n;
    T tAn = tA * n;

    return ((PAn * tAn) > 0);
  }

  /// method to check if the local point object is inside a tetrahedron
  /// described by the vertices A,B,C and D
  /// @param A vertex A
  /// @param B vertex B
  /// @param C vertex C
  /// @param D vertex D
  /// @return the point is within the tetrahedron
  /// @attention a point that is on the surface of the tetrahedron is not inside
  /// it
  bool inTetrahedron(const Point<T> &A, const Point<T> &B,
                     const Point<T> &C, const Point<T> &D) {
    /// for all surfaces of the tetrahedron check if the local point has the
    /// same orientation as the remaining vertex of the tetrahedron, to be
    /// inside the tetrahedron that must be fulfilled
    return (same_side_plane(A, B, C, D) && same_side_plane(B, C, D, A) &&
            same_side_plane(C, D, A, B) && same_side_plane(A, D, B, C));
  };

private:
  /// dimension of the point object
  int dimension;
  /// index for the point
  long id;
  // array containg the coordinates
  std::vector<T> coordinates;
  /// weight of the point to be used if points are not to be equally considered
  /// in computations, e.g. if number of interactions are considered
  T weight;
};

/// output operator for a point object
/// @param os output stream the point object should be printed to
/// @param p the point object to be printed
/// @return the modified output stream
template <class T>
std::ostream &operator<<(std::ostream &os, const Point<T> &p) {
  for (int i = 0; i < p.getDimension(); ++i)
    os << p[i] << " ";
  os << p.getWeight();
  return os;
}

/// operator to scale a point by a factor (reversed way of notation T *
/// Point<T>)
/// @param lhs scaling factor
/// @param rhs the point object to be scaled
/// @param scaled point object
template <class T>
Point<T> operator*(const T &lhs, const Point<T> &rhs) {
  return rhs * lhs;
}

// template <class T>
// Point<T> operator/(const T &lhs, const Point<T> &rhs) {
//   return rhs * ((T)1 / lhs);
// }

}//namespace ALL

#endif

#include <algorithm>
#include <exception>
#include <iomanip>
#include <map>
#include <mpi.h>
#include <sstream>

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"
#include <voro++.hh>
#pragma GCC diagnostic pop

namespace ALL {

/// Load-balancing scheme based on Voronoi cells and the shift of their anchor
/// points due to the ratio of work assigned to the local and neighboring
/// domains. For each domain a center of work, i.e. the average of the particle
/// locations, weighted by their indivual work share is computed (vertex 2).
/// This and the work load of the local and the neighboring domains are used to
/// compute a shift of the anchor point in the direction of the largest work
/// load.
/// @tparam T data for vertices and related data
/// @tparam W data for work and related data
template <class T, class W> class Voronoi_LB : public LB<T, W> {
public:
  /// default constructor
  Voronoi_LB() {}
  /// constructor initializing basic parameters
  /// @param[in] d the dimension of the used vertices
  /// @param[in] w the scalar work assigned to the local domain
  /// @param[in] g the correction factor gamma
  Voronoi_LB(int d, W w, T g) : LB<T, W>(d, g) { this->setWork(w); }

  /// default destructor
  ~Voronoi_LB() override;

  voro::voronoicell vc;

  /// setup internal data structures and parameters
  void setup() override;

  /// method to execute a load-balancing step
  /// @param[in] step number of the load-balancing step
  virtual void balance(int step) override;

  // getter for variables (passed by reference to avoid
  // direct access to private members of the object)

  /// method to provide a list of the neighbors of the local domain
  /// @param[out] list reference to a std::vector of integers where the list of
  /// neighbors will be assigned to
  virtual std::vector<int> &getNeighbors() override;

  /// method to set specific data structures (unused for tensor grid method)
  /// @param[in] data pointer to the data structure
  virtual void setAdditionalData(known_unused const void *data) override {}

  /// method to get a list of the vertices of the neighboring domains
  /// @param[out] ret list of vertices of neighboring domains
  std::vector<T> &getNeighborVertices();

private:
  // MPI values

  // type for MPI communication
  MPI_Datatype MPIDataTypeT;
  MPI_Datatype MPIDataTypeW;

  // list of neighbors
  std::vector<int> neighbors;
  int nNeighbors[1];

  // collection of generator points
  std::vector<T> generator_points;

  // number of ranks in global communicator
  int nDomains;
};

template <class T, class W> Voronoi_LB<T, W>::~Voronoi_LB() {}

// setup routine for the tensor-based load-balancing scheme
// requires:
//              this->globalComm (int): cartesian MPI communicator, from
//                                 which separate sub communicators
//                                 are derived in order to represent
//                                 each plane of domains in the system
template <class T, class W> void Voronoi_LB<T, W>::setup() {
  // store global communicator
  int dimension = this->getDimension();

  // no special communicator required

  // create array to store information about generator points
  // TODO: hierarchical scheme or better preselection which
  //       generator points are required for correct creation
  //       of the local cell -> large-scale Voronoi grid creation
  //                            is too expensive to be done
  //                            every step
  MPI_Comm_size(this->globalComm, &nDomains);
  MPI_Comm_rank(this->globalComm, &this->localRank);
  generator_points.resize(nDomains * (2 * dimension + 1));

  // determine correct MPI data type for template T
  if (std::is_same<T, double>::value)
    MPIDataTypeT = MPI_DOUBLE;
  else if (std::is_same<T, float>::value)
    MPIDataTypeT = MPI_FLOAT;
  else if (std::is_same<T, int>::value)
    MPIDataTypeT = MPI_INT;
  else if (std::is_same<T, long>::value)
    MPIDataTypeT = MPI_LONG;

  // determine correct MPI data type for template W
  if (std::is_same<W, double>::value)
    MPIDataTypeW = MPI_DOUBLE;
  else if (std::is_same<W, float>::value)
    MPIDataTypeW = MPI_FLOAT;
  else if (std::is_same<W, int>::value)
    MPIDataTypeW = MPI_INT;
  else if (std::is_same<W, long>::value)
    MPIDataTypeW = MPI_LONG;
}

template <class T, class W>
void Voronoi_LB<T, W>::balance(int known_unused loadbalancing_step) {
  int dimension = this->getDimension();
  // collect local information in array
  int info_length = 2 * dimension + 1;
  std::vector<T> local_info(info_length);
  // Todo(s.schulz): prevVertices is unused, might be a bug?
  std::vector<Point<T>> &prevVertices = this->getVertices();
  std::vector<Point<T>> &vertices = this->getVertices();
  std::vector<W> &work = this->getWork();

  for (auto i = 0; i < 2; ++i)
    for (auto d = 0; d < dimension; ++d) {
      local_info.at(d) = vertices.at(i)[d];
    }
  local_info.at(2 * dimension) = (T)work.at(0);

  MPI_Allgather(local_info.data(), info_length, MPIDataTypeT,
                generator_points.data(), info_length, MPIDataTypeT,
                this->globalComm);

  // create Voronoi-cells
  // TODO: check if system is periodic or not -> true / false!
  voro::container con_old(
      this->sysSize.at(0), this->sysSize.at(1), this->sysSize.at(2),
      this->sysSize.at(3), this->sysSize.at(4), this->sysSize.at(5),
      ALL_VORONOI_SUBBLOCKS, ALL_VORONOI_SUBBLOCKS, ALL_VORONOI_SUBBLOCKS,
      false, false, false, nDomains + 10);

  // add generator points to container
  for (auto d = 0; d < nDomains; ++d) {
    con_old.put(d, generator_points.at(info_length * d),
                generator_points.at(info_length * d + 1),
                generator_points.at(info_length * d + 2));
  }

#ifdef ALL_DEBUG_ENABLED
  // print old voronoi cell structure
  std::ostringstream ss_local_gp_pov;
  ss_local_gp_pov << "voronoi/generator_points_" << std::setw(7)
                  << std::setfill('0') << loadbalancing_step << ".pov";
  std::ostringstream ss_local_gp_gnu;
  ss_local_gp_gnu << "voronoi/generator_points_" << std::setw(7)
                  << std::setfill('0') << loadbalancing_step << ".gnu";
  std::ostringstream ss_local_vc_pov;
  ss_local_vc_pov << "voronoi/voronoi_cells_" << std::setw(7)
                  << std::setfill('0') << loadbalancing_step << ".pov";
  std::ostringstream ss_local_vc_gnu;
  ss_local_vc_gnu << "voronoi/voronoi_cells_" << std::setw(7)
                  << std::setfill('0') << loadbalancing_step << ".gnu";

  loadbalancing_step++;

  if (this->localRank == 0) {
    con_old.draw_particles(ss_local_gp_gnu.str().c_str());
    con_old.draw_cells_gnuplot(ss_local_vc_gnu.str().c_str());
    con_old.draw_particles_pov(ss_local_gp_pov.str().c_str());
    con_old.draw_cells_pov(ss_local_vc_pov.str().c_str());
  }
#endif

  // vector to store neighbor information
  std::vector<double> cell_vertices;
  voro::voronoicell_neighbor c;

  // generate loop over all old generator points
  voro::c_loop_all cl_old(con_old);

  int pid;
  double x, y, z, r;
  // reset list of neighbors
  neighbors.clear();

  std::map<int, double> neig_area;

  for (auto i = 0; i < 1; ++i) {
    // find next neighbors
    std::vector<std::vector<int>> next_neighbors(
        std::max((int)neighbors.size(), 1));
    std::vector<std::vector<double>> neighbors_area(
        std::max((int)neighbors.size(), 1));
    int idx = 0;
    if (cl_old.start()) {
      do {
        // compute only local cell
        cl_old.pos(pid, x, y, z, r);
        if (i == 0) {
          if (pid == this->localRank) {
            con_old.compute_cell(c, cl_old);
            c.neighbors(next_neighbors.at(idx));
            c.face_areas(neighbors_area.at(idx));
            for (int j = 0; j < (int)next_neighbors.at(idx).size(); ++j)
              neig_area.insert(std::pair<int, double>(
                  next_neighbors.at(idx).at(j), neighbors_area.at(idx).at(j)));
            idx++;
            if (idx == (int)neighbors.size())
              break;
          }
        } else {
          if (std::count(neighbors.begin(), neighbors.end(), pid) == 1) {
            con_old.compute_cell(c, cl_old);
            c.neighbors(next_neighbors.at(idx));
            idx++;
            if (idx == (int)neighbors.size())
              break;
          }
        }
      } while (cl_old.inc());
    }
    for (auto it = next_neighbors.begin(); it != next_neighbors.end(); ++it) {
      neighbors.insert(neighbors.begin(), it->begin(), it->end());
    }

    std::sort(neighbors.begin(), neighbors.end());
    auto uniq_it = std::unique(neighbors.begin(), neighbors.end());
    neighbors.resize(std::distance(neighbors.begin(), uniq_it));
    neighbors.erase(
        std::remove(neighbors.begin(), neighbors.end(), this->localRank),
        neighbors.end());
    neighbors.erase(std::remove_if(neighbors.begin(), neighbors.end(),
                                   [](int x) { return x < 0; }),
                    neighbors.end());
  }

  std::vector<double> volumes(neighbors.size());
  std::vector<double> surfaces(neighbors.size());

  for (int i = 0; i < (int)neighbors.size(); ++i) {
    auto it = neig_area.find(neighbors.at(i));
    surfaces.at(i) = it->second;
  }

  // Todo(s.schulz): is local_volume needed for future work or can we remove it?
  double local_volume;
  // get volumes of each neighbor cell
  if (cl_old.start()) {
    do {
      cl_old.pos(pid, x, y, z, r);
      auto it = std::find(neighbors.begin(), neighbors.end(), pid);

      if (it != neighbors.end()) {
        int idx = std::distance(neighbors.begin(), it);
        con_old.compute_cell(c, cl_old);
        volumes.at(idx) = c.volume();
      }
      if (pid == this->localRank) {
        con_old.compute_cell(c, cl_old);
        local_volume = c.volume();
      }
    } while (cl_old.inc());
  }
#ifdef ALL_DEBUG_ENABLED
  MPI_Barrier(this->globalComm);
  if (this->localRank == 0)
    std::cout << "ALL::Voronoi_LB<T,W>::balance begin checking..." << std::endl;
#endif

  // compute shift
  std::vector<T> shift(dimension, 0.0);
  T norm;

  T work_load = (T)local_info.at(info_length - 1);
  for (auto it = neighbors.begin(); it != neighbors.end(); ++it) {
    int neighbor = *it;
    work_load += generator_points.at(info_length * neighbor + info_length - 1);
  }

#ifdef ALL_DEBUG_ENABLED
  MPI_Barrier(this->globalComm);
  if (this->localRank == 0)
    std::cout << "ALL::Voronoi_LB<T,W>::balance find neighbors..." << std::endl;
#endif

  T max_diff = 20.0;

  for (auto it = neighbors.begin(); it != neighbors.end(); ++it) {
    int neighbor = *it;
    std::vector<T> diff(dimension);
    bool correct = true;
    for (int d = 0; d < dimension && correct; ++d) {
      diff.at(d) = generator_points.at(info_length * neighbor + dimension + d) -
                   local_info.at(d);

      if (diff.at(d) >
          0.5 * (this->sysSize[2 * d + 1] - this->sysSize[2 * d])) {
        diff.at(d) -= (this->sysSize[2 * d + 1] - this->sysSize[2 * d]);
        correct = false;
      } else if (diff.at(d) <
                 -0.5 * (this->sysSize[2 * d + 1] - this->sysSize[2 * d])) {
        diff.at(d) += (this->sysSize[2 * d + 1] - this->sysSize[2 * d]);
        correct = false;
      }
    }
    max_diff = std::min(max_diff,
                        sqrt(diff.at(0) * diff.at(0) + diff.at(1) * diff.at(1) +
                             diff.at(2) * diff.at(2)));
    if (correct) {
      // compute difference in work load
      T work_diff = (T)0.0;
      work_diff =
          (generator_points.at(info_length * neighbor + info_length - 1) -
           local_info.at(info_length - 1));
      T work_density =
          (generator_points.at(info_length * neighbor + info_length - 1) +
           local_info.at(info_length - 1));

      if (work_density < 1e-6)
        work_diff = (T)0;
      else
        work_diff /= work_density;
      for (int d = 0; d < dimension; ++d) {
        shift.at(d) += 0.5 * work_diff * diff.at(d) / this->gamma;
      }
    }
  }

#ifdef ALL_DEBUG_ENABLED
  MPI_Barrier(this->globalComm);
  if (this->localRank == 0)
    std::cout << "ALL::Voronoi_LB<T,W>::balance after neighbors found..."
              << std::endl;
#endif

  norm = sqrt(shift.at(0) * shift.at(0) + shift.at(1) * shift.at(1) +
              shift.at(2) * shift.at(2));

  T scale = 1.0;

  if (norm > 0.45 * max_diff)
    scale = 0.45 * max_diff / norm;

#ifdef ALL_DEBUG_ENABLED
  MPI_Barrier(this->globalComm);
  if (this->localRank == 0)
    std::cout << "ALL::Voronoi_LB<T,W>::balance find new neighbors..." << std::endl;
#endif

  // to find new neighbors
  for (int d = 0; d < dimension; ++d) {
    local_info.at(d) += scale * shift.at(d);

    // periodic correction of points
    local_info.at(d) = (local_info.at(d) < this->sysSize.at(2 * d))
                           ? this->sysSize.at(2 * d) + 1.0
                           : ((local_info.at(d) >= this->sysSize.at(2 * d + 1))
                                  ? this->sysSize.at(2 * d + 1) - 1.0
                                  : local_info.at(d));
  }

  MPI_Allgather(local_info.data(), info_length, MPIDataTypeT,
                generator_points.data(), info_length, MPIDataTypeT,
                this->globalComm);

#ifdef ALL_DEBUG_ENABLED
  MPI_Barrier(this->globalComm);
  if (this->localRank == 0)
    std::cout << "ALL::Voronoi_LB<T,W>::balance create new containers..."
              << std::endl;
#endif

  // create Voronoi-cells
  // TODO: check if system is periodic or not -> true / false!
  voro::container con_new(
      this->sysSize.at(0), this->sysSize.at(1), this->sysSize.at(2),
      this->sysSize.at(3), this->sysSize.at(4), this->sysSize.at(5),
      ALL_VORONOI_SUBBLOCKS, ALL_VORONOI_SUBBLOCKS, ALL_VORONOI_SUBBLOCKS,
      false, false, false, nDomains + 10);

  // add generator points to container
  for (int d = 0; d < nDomains; ++d) {
    con_new.put(d, generator_points.at(info_length * d),
                generator_points.at(info_length * d + 1),
                generator_points.at(info_length * d + 2));
  }

#ifdef ALL_DEBUG_ENABLED
  std::ostringstream ss_local_gp_pov2;
  ss_local_gp_pov2 << "voronoi/generator_points_" << std::setw(7)
                   << std::setfill('0') << loadbalancing_step << ".pov";
  std::ostringstream ss_local_gp_gnu2;
  ss_local_gp_gnu2 << "voronoi/generator_points_" << std::setw(7)
                   << std::setfill('0') << loadbalancing_step << ".gnu";
  std::ostringstream ss_local_vc_pov2;
  ss_local_vc_pov2 << "voronoi/voronoi_cells_" << std::setw(7)
                   << std::setfill('0') << loadbalancing_step << ".pov";
  std::ostringstream ss_local_vc_gnu2;
  ss_local_vc_gnu2 << "voronoi/voronoi_cells_" << std::setw(7)
                   << std::setfill('0') << loadbalancing_step << ".gnu";

  loadbalancing_step++;

  if (this->localRank == 0) {
    con_new.draw_particles(ss_local_gp_gnu2.str().c_str());
    con_new.draw_cells_gnuplot(ss_local_vc_gnu2.str().c_str());
    con_new.draw_particles_pov(ss_local_gp_pov2.str().c_str());
    con_new.draw_cells_pov(ss_local_vc_pov2.str().c_str());
  }
#endif

#ifdef ALL_DEBUG_ENABLED
  MPI_Barrier(this->globalComm);
  if (this->localRank == 0)
    std::cout << "ALL::Voronoi_LB<T,W>::balance storing shifted vertices..."
              << " " << vertices.size() << " " << dimension << std::endl;
#endif

  Point<T> tmp_pnt(dimension, local_info.data());

  // compute new neighboring cells and generator points

  // generate loop over all new generator points
  voro::c_loop_all cl_new(con_new);

  // reset list of neighbors
  neighbors.clear();

#ifdef ALL_DEBUG_ENABLED
  MPI_Barrier(this->globalComm);
  if (this->localRank == 0)
    std::cout << "ALL::Voronoi_LB<T,W>::balance searching neighboring vertices..."
              << std::endl;
#endif

  for (auto i = 0; i < ALL_VORONOI_NEIGHBOR_SEARCH_DEPTH; ++i) {
    // find next neighbors
    std::vector<std::vector<int>> next_neighbors(
        std::max((int)neighbors.size(), 1));
    int idx = 0;
    if (cl_new.start()) {
      do {
        // compute next voronoi cell
        cl_new.pos(pid, x, y, z, r);
        if (i == 0) {
          if (pid == this->localRank) {
            con_new.compute_cell(c, cl_new);
            c.neighbors(next_neighbors.at(idx));
            idx++;
            if (idx == (int)neighbors.size())
              break;
          }
        } else {
          if (std::count(neighbors.begin(), neighbors.end(), pid) == 1) {
            con_new.compute_cell(c, cl_new);
            c.neighbors(next_neighbors.at(idx));
            idx++;
            if (idx == (int)neighbors.size())
              break;
          }
        }
      } while (cl_new.inc());
    }
    for (auto it = next_neighbors.begin(); it != next_neighbors.end(); ++it) {
      neighbors.insert(neighbors.begin(), it->begin(), it->end());
    }

    std::sort(neighbors.begin(), neighbors.end());
    auto uniq_it = std::unique(neighbors.begin(), neighbors.end());
    neighbors.resize(std::distance(neighbors.begin(), uniq_it));
    neighbors.erase(
        std::remove(neighbors.begin(), neighbors.end(), this->localRank),
        neighbors.end());
    neighbors.erase(std::remove_if(neighbors.begin(), neighbors.end(),
                                   [](int x) { return x < 0; }),
                    neighbors.end());
  }

  // determine number of neighbors
  nNeighbors[0] = neighbors.size();

  // clear old neighbor vertices
  this->neighborVertices.clear();

  // find vertices of neighbors

  for (auto n : neighbors) {
    for (int i = 0; i < dimension; ++i)
      this->neighborVertices.push_back(generator_points.at(info_length * n + i));
  }
}

// provide list of neighbors
template <class T, class W>
std::vector<int> &Voronoi_LB<T, W>::getNeighbors() {
  return neighbors;
}


}//namespace ALL

#endif
#endif

#endif
/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_HISTOGRAM_HEADER_INCLUDED
#define ALL_HISTOGRAM_HEADER_INCLUDED

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_CUSTOM_EXCEPTIONS_INC
#define ALL_CUSTOM_EXCEPTIONS_INC

#include <exception>
#include <sstream>
#include <string>

namespace ALL {

/// Customized exceptions for ALL, modified for each specific exception type
struct CustomException : public std::exception {
protected:
  /// file the exception occured in
  const char *file;
  /// function the exception occured in
  const char *func;
  /// line the exception occured in
  int line;
  /// information on the exception
  const char *info;
  /// name of the exception
  const char *loc_desc;
  /// error message
  std::string error_msg;
  /// error identificators for Fortran error retrieval, remember to
  /// update the Fortran module as well!
  enum struct ErrorID : int {
	Generic = 1,
	PointDimensionMissmatch,
	InvalidCommType,
	InvalidArgument,
	OutOfBounds,
	InternalError,
	FilesystemError
  };
  /// error identificator retrieved by Fortran
  ErrorID error_id;

public:
  /// constructor for an exception used in ALL
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  CustomException(const char *file_ = "", const char *f_ = "", int l_ = -1,
                      const char *i_ = "",
                      const char *loc_desc_ = "ALLCustomException",
		      const ErrorID error_id_ = ErrorID::Generic)
      : file(file_), func(f_), line(l_), info(i_), loc_desc(loc_desc_), error_id(error_id_) {
    std::stringstream ss;
    ss << loc_desc << ": " << info << "\n"
       << "Function: " << func << "\n"
       << "File: " << file << "\n"
       << "Line: " << line << "\n";
    error_msg = ss.str();
  }
  /// method to get the function name from where the exception was thrown
  /// @return the function name
  const char *get_func() const { return func; }

  /// method to get the line from where the exception was thrown
  /// @return the line
  int get_line() const { return line; }

  /// method to get the additional information about the error leading to the
  /// exception
  /// @return the information given about the error
  const char *get_info() { return info; }

  /// overloaded method from the base Exception class to return an error message
  /// @return the error message of the exception
  virtual const char *what() const throw() { return error_msg.c_str(); }

  /// retrieve error id for Fortran interface
  /// @return error id from ErrorID enum
  int get_error_id() { return static_cast<int>(error_id); }
};

/// Exception to be used for missmatches in dimension for ALL::Point class
struct PointDimensionMissmatchException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  PointDimensionMissmatchException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Dimension missmatch in Point objects.",
      const char *loc_desc_ = "ALLPointDimMissmatchException",
      const ErrorID error_id_ = ErrorID::PointDimensionMissmatch)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid Communicators in a load-balancing method
struct InvalidCommTypeException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidCommTypeException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Type of MPI communicator not valid.",
      const char *loc_desc_ = "ALLCommTypeInvalidException",
      const ErrorID error_id_ = ErrorID::InvalidCommType)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid parameters in any type of classes
struct InvalidArgumentException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidArgumentException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Invalid argument given.",
      const char *loc_desc_ = "ALLInvalidArgumentException",
      const ErrorID error_id_ = ErrorID::InvalidArgument)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an array went out of bounds
struct OutOfBoundsException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  OutOfBoundsException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Access to array out of bounds.",
      const char *loc_desc_ = "ALLOutOfBoundsErrorException",
      const ErrorID error_id_ = ErrorID::OutOfBounds)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an internal error has occured
struct InternalErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InternalErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Internal error occured, see description.",
      const char *loc_desc_ = "ALLInternalErrorException",
      const ErrorID error_id_ = ErrorID::InternalError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if a filesystem error has occured
struct FilesystemErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  FilesystemErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Filesystem error occured, see description.",
      const char *loc_desc_ = "ALLFilesystemErrorException",
      const ErrorID error_id_ = ErrorID::FilesystemError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

}//namespace ALL

#endif

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_LB_HEADER_INCLUDED
#define ALL_LB_HEADER_INCLUDED

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_POINT_HEADER_INC
#define ALL_POINT_HEADER_INC

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_CUSTOM_EXCEPTIONS_INC
#define ALL_CUSTOM_EXCEPTIONS_INC

#include <exception>
#include <sstream>
#include <string>

namespace ALL {

/// Customized exceptions for ALL, modified for each specific exception type
struct CustomException : public std::exception {
protected:
  /// file the exception occured in
  const char *file;
  /// function the exception occured in
  const char *func;
  /// line the exception occured in
  int line;
  /// information on the exception
  const char *info;
  /// name of the exception
  const char *loc_desc;
  /// error message
  std::string error_msg;
  /// error identificators for Fortran error retrieval, remember to
  /// update the Fortran module as well!
  enum struct ErrorID : int {
	Generic = 1,
	PointDimensionMissmatch,
	InvalidCommType,
	InvalidArgument,
	OutOfBounds,
	InternalError,
	FilesystemError
  };
  /// error identificator retrieved by Fortran
  ErrorID error_id;

public:
  /// constructor for an exception used in ALL
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  CustomException(const char *file_ = "", const char *f_ = "", int l_ = -1,
                      const char *i_ = "",
                      const char *loc_desc_ = "ALLCustomException",
		      const ErrorID error_id_ = ErrorID::Generic)
      : file(file_), func(f_), line(l_), info(i_), loc_desc(loc_desc_), error_id(error_id_) {
    std::stringstream ss;
    ss << loc_desc << ": " << info << "\n"
       << "Function: " << func << "\n"
       << "File: " << file << "\n"
       << "Line: " << line << "\n";
    error_msg = ss.str();
  }
  /// method to get the function name from where the exception was thrown
  /// @return the function name
  const char *get_func() const { return func; }

  /// method to get the line from where the exception was thrown
  /// @return the line
  int get_line() const { return line; }

  /// method to get the additional information about the error leading to the
  /// exception
  /// @return the information given about the error
  const char *get_info() { return info; }

  /// overloaded method from the base Exception class to return an error message
  /// @return the error message of the exception
  virtual const char *what() const throw() { return error_msg.c_str(); }

  /// retrieve error id for Fortran interface
  /// @return error id from ErrorID enum
  int get_error_id() { return static_cast<int>(error_id); }
};

/// Exception to be used for missmatches in dimension for ALL::Point class
struct PointDimensionMissmatchException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  PointDimensionMissmatchException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Dimension missmatch in Point objects.",
      const char *loc_desc_ = "ALLPointDimMissmatchException",
      const ErrorID error_id_ = ErrorID::PointDimensionMissmatch)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid Communicators in a load-balancing method
struct InvalidCommTypeException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidCommTypeException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Type of MPI communicator not valid.",
      const char *loc_desc_ = "ALLCommTypeInvalidException",
      const ErrorID error_id_ = ErrorID::InvalidCommType)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid parameters in any type of classes
struct InvalidArgumentException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidArgumentException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Invalid argument given.",
      const char *loc_desc_ = "ALLInvalidArgumentException",
      const ErrorID error_id_ = ErrorID::InvalidArgument)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an array went out of bounds
struct OutOfBoundsException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  OutOfBoundsException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Access to array out of bounds.",
      const char *loc_desc_ = "ALLOutOfBoundsErrorException",
      const ErrorID error_id_ = ErrorID::OutOfBounds)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an internal error has occured
struct InternalErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InternalErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Internal error occured, see description.",
      const char *loc_desc_ = "ALLInternalErrorException",
      const ErrorID error_id_ = ErrorID::InternalError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if a filesystem error has occured
struct FilesystemErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  FilesystemErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Filesystem error occured, see description.",
      const char *loc_desc_ = "ALLFilesystemErrorException",
      const ErrorID error_id_ = ErrorID::FilesystemError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

}//namespace ALL

#endif

#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace ALL {

template <class T> class Point;
template <typename T>
std::ostream &operator<<(std::ostream &, const Point<T> &);

/// @tparam T floating point type used, has to be identical to the type used for
/// the vertices and borders
template <class T> class Point {
public:
  /// default constructor
  Point() : dimension(0) {}
  /// constructor
  /// @param d dimension of the point object
  Point(const int d) : dimension(d) {
    coordinates.resize(d);
    weight = (T)1;
  }
  /// constructor with initialization
  /// @param d dimension of the point object
  /// @param data positions
  Point(const int d, const T *data) : Point<T>(d) {
    // copy each element of the array into the vector (insecure, no boundary
    // checks for data!)
    for (auto i = 0; i < d; ++i)
      coordinates.at(i) = data[i];
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  Point(const std::vector<T> &data) {
    // initialize the coordinates vector with the data vector
    coordinates.insert(coordinates.begin(), data.begin(), data.end());
    // update the dimension with the size of the data vector
    dimension = data.size();
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  Point(const int d, const T *data, const T w) : Point<T>(d, data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  /// @param i index of the point
  Point(const int d, const T *data, const T w, const long i)
      : Point<T>(d, data, w) {
    id = i;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  Point(const std::vector<T> &data, const T w) : Point<T>(data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  /// @param i index of the point
  Point(const std::vector<T> &data, const T w, const long i)
      : Point<T>(data, w) {
    id = i;
  }

  /// destructor
  ~Point<T>(){};

  // TODO: return values to check if operation was successful?
  /// method to change the dimension of the point object
  /// @param d new dimension
  void setDimension(const int d) {
    dimension = d;
    coordinates.resize(d);
  }

  /// method to change the weight of the point object
  /// @param w new weight
  void set_weight(const T w) { weight = w; }

  /// method to change the index of the particle
  /// @param i new index
  void set_id(const long i) { id = i; }

  /// access operator to access an element of the point object
  /// @param idx the index of the element to be accessed
  /// @result reference to the indexed element
  T &operator[](const std::size_t idx) { return coordinates.at(idx); }

  /// access operator to access an element of the constant point object
  /// @param idx the index of the element to be accessed
  /// @result const reference to the indexed element
  const T &operator[](const std::size_t idx) const {
    return coordinates.at(idx);
  }

  /// method to get the weight of the point object
  /// @return the weight of the point object
  T getWeight() const { return weight; }

  /// method to get the index of the point object
  /// @return the index of the point object
  long get_id() const { return id; }

  /// method to get the dimension of the point object
  /// @return the dimension of the point object
  int getDimension() const { return dimension; }

  /// method to compute the norm of the vector described by the
  /// point object
  /// @param nd type of the norm (default: 2, i.e. the Euclidean norm)
  /// @return norm of the vector
  T norm(T nd = 2) {
    T res = 0;
    for (int d = 0; d < dimension; ++d)
      res += std::pow(coordinates.at(d), nd);
    return std::pow(res, 1.0 / nd);
  }

  /// method to compute the Euclidean distance (two-norm) between the local and
  /// the provided point object
  /// @param p the point object for which the distence to the local point object
  /// is computed
  /// @return the distance between the two points
  T d(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p).norm();
  }

  /// method to compute the Manhatten / city-block distance (one-norm) between
  /// the local and the provided point object
  /// @param p the point object for which the distance to the local point object
  /// is computed
  /// @return the distance between the two points
  T d_1(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p, 1).norm();
  }

  /// method to compute the distance vector between the local point object and
  /// the provided point object
  /// @param p the point object for which the distance vector to the local point
  /// object is computed
  /// @return the distance vector between the two points
  Point<T> dist(Point<T> &p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    std::vector<T> d_v;
    for (int d = 0; d < dimension; ++d)
      d_v.push_back(p[d] - coordinates.at(d));

    return Point<T>(d_v);
  }

  /// method to compute the distance of the local point object from a plane
  /// spanned by provided points
  /// @param A anchor point for the plane
  /// @param B anchor point for the plane
  /// @param C anchor point for the plane
  /// @return distance between local point object and plane
  T dist_plane(const Point<T> &A, const Point<T> &B,
               const Point<T> &C) {

    if (A.getDimension() != dimension || B.getDimension() != dimension ||
        C.getDimension() != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);

    // vectors spanning the plane from vertex 'a'
    T vb[3];
    T vc[3];

    for (int i = 0; i < 3; ++i) {
      vb[i] = B[i] - A[i];
      vc[i] = C[i] - A[i];
    }

    // normal vector of plane
    T n[3];

    n[0] = vb[1] * vc[2] - vb[2] * vc[1];
    n[1] = vb[2] * vc[0] - vb[0] * vc[2];
    n[2] = vb[0] * vc[1] - vb[1] * vc[0];

    // length of normal vector
    T dn = n.norm();

    // distance from origin
    T d = n * A;

    // compute distance of test vertex to plane
    return std::abs((n[0] * coordinates.at(0) + n[1] * coordinates.at(1) +
                     n[2] * coordinates.at(2) - d) /
                    dn);
  }

  /// operator for the addition of two point objects
  /// @param rhs point to add the local point object to
  /// @return sum of local point object and provided point object
  Point<T> operator+(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) + rhs[d];
    }
    return result;
  }

  /// operator for the addition of two point objects
  /// @param rhs point to subtract from the local point object
  /// @return difference vector between local point object and provided point
  /// object
  Point<T> operator-(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) - rhs[d];
    }
    return result;
  }

  /// operator to compute the dot product between two point objects
  /// @param rhs point object to compute the dot product with
  /// @return dot product between the two point objects
  T operator*(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    T result = (T)0.0;
    for (int d = 0; d < dimension; ++d) {
      result += coordinates.at(d) * rhs[d];
    }
    return result;
  }

  /// operator to scale the local point object by a provided factor
  /// @param rhs scaling factor
  /// @return scaled point object
  Point<T> operator*(const T &rhs) const {
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) * rhs;
    }
    return result;
  }

  /// operator to compute the cross product between two point objects
  /// @param rhs point object to compute the cross product with
  /// @return cross product between the two point objects
  /// @attention only works for 3D points / vectors
  Point<T> cross(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension && dimension != 3) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at((d + 1) % 3) * rhs[(d + 2) % 3] -
                  coordinates.at((d + 2) % 3) * rhs[(d + 1) % 3];
    }
    return result;
  }

  /// method to determine if the local point object has the same orientation to
  /// a plane spanned by point objects A,B,C as the provided point P
  /// @param A anchor point A
  /// @param B anchor point B
  /// @param C anchor point C
  /// @param P reference point P
  /// @return the local point object has the same orientation to the plane as
  /// @attention if the reference point is located within the plane, it will not
  /// have the same orientation as the local point! the reference point
  bool same_side_plane(const Point<T> &A, const Point<T> &B,
                       const Point<T> &C, const Point<T> &P) {
    // compute difference vectors:
    Point<T> BA = B - A;
    Point<T> CA = C - A;
    Point<T> PA = P - A;
    Point<T> tA = *(this) - A;

    // compute normal vector of plane
    Point<T> n = CA.cross(BA);

    // compute scalar product of distance
    // vectors with normal vector
    T PAn = PA * n;
    T tAn = tA * n;

    return ((PAn * tAn) > 0);
  }

  /// method to check if the local point object is inside a tetrahedron
  /// described by the vertices A,B,C and D
  /// @param A vertex A
  /// @param B vertex B
  /// @param C vertex C
  /// @param D vertex D
  /// @return the point is within the tetrahedron
  /// @attention a point that is on the surface of the tetrahedron is not inside
  /// it
  bool inTetrahedron(const Point<T> &A, const Point<T> &B,
                     const Point<T> &C, const Point<T> &D) {
    /// for all surfaces of the tetrahedron check if the local point has the
    /// same orientation as the remaining vertex of the tetrahedron, to be
    /// inside the tetrahedron that must be fulfilled
    return (same_side_plane(A, B, C, D) && same_side_plane(B, C, D, A) &&
            same_side_plane(C, D, A, B) && same_side_plane(A, D, B, C));
  };

private:
  /// dimension of the point object
  int dimension;
  /// index for the point
  long id;
  // array containg the coordinates
  std::vector<T> coordinates;
  /// weight of the point to be used if points are not to be equally considered
  /// in computations, e.g. if number of interactions are considered
  T weight;
};

/// output operator for a point object
/// @param os output stream the point object should be printed to
/// @param p the point object to be printed
/// @return the modified output stream
template <class T>
std::ostream &operator<<(std::ostream &os, const Point<T> &p) {
  for (int i = 0; i < p.getDimension(); ++i)
    os << p[i] << " ";
  os << p.getWeight();
  return os;
}

/// operator to scale a point by a factor (reversed way of notation T *
/// Point<T>)
/// @param lhs scaling factor
/// @param rhs the point object to be scaled
/// @param scaled point object
template <class T>
Point<T> operator*(const T &lhs, const Point<T> &rhs) {
  return rhs * lhs;
}

// template <class T>
// Point<T> operator/(const T &lhs, const Point<T> &rhs) {
//   return rhs * ((T)1 / lhs);
// }

}//namespace ALL

#endif

#include <mpi.h>
#include <vector>

namespace ALL {

/// @tparam T data for vertices and related data
/// @tparam W data for work and related data
template <class T, class W> class LB {
public:
  /// constructor for the basic load-balancing class, sets up parameters
  /// required by all balancing methods
  /// @param[in] dim dimension of the vertices used
  /// @param[in] g correction factor for the computation of shifts
  LB(const int dim, const T g) : gamma(g), dimension(dim) {
    // set allowed minimum size to zero
    minSize = std::vector<T>(dim, 0.0);
    periodicity.resize(dim);
    local_coords.resize(dim);
    global_dims.resize(dim);
    neighborVertices.resize(0);
  }

  /// destructor
  virtual ~LB() = default;

  /// abstract definition of the setup method
  virtual void setup() = 0;

  /// abstract definition of the balancing method
  virtual void balance(const int step) = 0;

  /// abstract definition of the method to get the neighbors of the local domain
  /// @result std::vector<int> to store the MPI ranks of the neighbors
  /// to
  virtual std::vector<int> &getNeighbors() = 0;

  /// method to update the vertices used for the balancing step, overwrites old
  /// set of vertices
  /// @param[in] vertices_in vector containg the new vertices to be used
  virtual void setVertices(const std::vector<Point<T>> &vertices_in) {
    // as a basic assumption the number of resulting vertices
    // is equal to the number of input vertices:
    // exceptions:
    //      VORONOI
    vertices = vertices_in;
    prevVertices = vertices_in;
  }

  /// method to set the dimension of the vertices
  /// @param[in] d the dimension to be used
  /// @attention most methods currently support 3D vertices only
  virtual void setDimension(const int d) { dimension = d; }

  /// method to get the dimension of the vertices
  /// @return the dimension of the vertices
  virtual int getDimension() { return dimension; }

  /// method to set the correction value gamma
  /// @param[in] g the correction value to use
  virtual void setGamma(const T g) { gamma = g; }

  /// method to get the correction value currently used
  /// @return the current correction value
  virtual const T getGamma() { return gamma; }

  /// method to set a multi-dimensional work for the local domain
  /// @param[in] w vector containing all the dimensions of the work to be used
  /// for the local domain
  virtual void setWork(const std::vector<W> &w) { work = w; }

  /// method to set a scalar work for the local domain
  /// @param[in] w value containing the work to be used for the local domain
  virtual void setWork(const W w) {
    work.resize(1);
    work.at(0) = w;
  }

  /// method to set the minimum domain size in each dimension
  /// @param[in] minSize the minimum size of a domain in all dimensions
  virtual void setMinDomainSize(const std::vector<T> &minSize) {
    this->minSize = minSize;
  }

  /// method to get the minimum domain size the balancing methods have to obey
  /// @return the minimum domain size allowed
  virtual const std::vector<T> &getMinDomainSize() { return minSize; }

  /// method to set the (orthogonal) size of the system
  /// @param[in] sysSize system size in all dimensions
  virtual void setSysSize(const std::vector<T> &newSysSize) {
    sysSize = newSysSize;
  }

  /// method to get the currently stored system size
  /// @return the currently stored system size
  virtual const std::vector<T> &getSysSize() { return sysSize; }

  /// method to get the currently stored work for the local process
  /// @return the currently stored work
  /// @attention always returns a std::vector, for scalar work, it has length 1
  virtual std::vector<W> &getWork() { return work; }

  /// method to get result vertices
  /// @return the resulting vertices after a balancing step
  virtual std::vector<Point<T>> &getVertices() { return vertices; }

  /// method to get the original vertices before the last balancing step
  /// @return the original unmodified vertices before the last balancing step
  /// @attention since the original and resulting vertices are set up in the
  /// balancing method, the result is undefined before calling the balancing
  /// method at least once
  virtual std::vector<Point<T>> &getPrevVertices() { return prevVertices; };

  /// method to set the MPI communicator to be used by the balancing method
  /// @param[in] comm the MPI communicator to be used
  virtual void setCommunicator(const MPI_Comm comm) {
    // store communicator
    globalComm = comm;
    // get local rank within communicator
    MPI_Comm_rank(comm, &localRank);
  }

  /// method the get the number of vertices stored for the local domain
  /// @return number of local vertices
  int getNVertices() { return vertices.size(); }

  /// method to set undefined method specific data, which is not shared between
  /// different methods but needs to be set by a unified interface
  /// @param[in] data the data be passed to the balancing method
  virtual void setAdditionalData(const void *data) = 0;

  /// method to provide a list of vertices describing the neighboring domains
  /// currently only implemented for VORONOI, as a means to get the anchor points
  /// of the surrounding domains
  std::vector<T> &getNeighborVertices() {
    return neighborVertices; }

protected:
  /// correction factor
  T gamma;
  /// dimension of the used vertices
  int dimension;
  /// used MPI communicator
  MPI_Comm globalComm;
  /// local rank in the used MPI communicator
  int localRank;
  /// minimum domain size
  /// @attention not all balancing method support this
  std::vector<T> minSize;
  /// (orthogonal) system size
  std::vector<T> sysSize;
  /// local work
  std::vector<W> work;
  /// local vertices after previous balancing step
  std::vector<Point<T>> vertices;
  /// original vertices before previous balancing step
  std::vector<Point<T>> prevVertices;
  /// dimensions of the global process grid
  std::vector<int> global_dims;
  /// cartesian coordinates of the local domain in the process grid
  std::vector<int> local_coords;
  /// periodicity of the MPI communicator / system
  std::vector<int> periodicity;
  /// vertices describing neighboring domains
  std::vector<T> neighborVertices;
  /// method the resize the vertex list
  /// @param [in] new_size the new size of the vertex list
  void resizeVertices(const int newSize) { vertices.resize(newSize); }

};

}//namespace ALL

#endif // ALL_LB_HEADER_INCLUDED

#include <exception>
#include <mpi.h>
#include <vector>

namespace ALL {

/// Load-balancing scheme based on the usage of global histograms in order to
/// provide a most optimal decomposition of data. The decomposition is created
/// by calling the balancing method three times. For each of the different
/// dimensions the data is sorted into histograms (the correction factor gamma
/// determines the width of each data bin) and using this as a cumulative
/// distribution function a decomposition is computed where each chunk contains
/// roughly the same amount of data. For the next dimensions this operation is
/// repeated within the chunks provided by the previous call, therefore
/// resulting after three call in a full three-dimensional decomposition.
/// Between each call to the balancing method the data needs to be transferred
/// according to the newly created domain boundaries.
/// @tparam T data for vertices and related data
/// @tparam W data for work and related data
template <class T, class W> class Histogram_LB : public LB<T, W> {
public:
  /// default constructor
  Histogram_LB() {}
  /// constructor to initialize the main parameters
  /// @param d the dimension of the used vertices
  /// @param w the multi-dimensional work of the local domain, the number of
  /// entries has to be equal to the number of bins overlapping the local domain
  /// in the current direction (bin width = correction factor gamma)
  /// @param g the correction factor, i.e. the width of a single bin
  Histogram_LB(int d, std::vector<W> w, T g) : LB<T, W>(d, g) {
    this->setWork(w);
    // need the lower and upper bounds
    // of the domain for the tensor-based
    // load-balancing scheme

    // array of MPI communicators for each direction (to collect work
    // on each plane)
    communicators.resize(2 * this->dimension);
    nNeighbors.resize(2 * this->dimension);
    nBins.resize(this->dimension);
  }

  /// default destructor
  ~Histogram_LB() = default;

  /// method to setup the loac-balancing method
  void setup() override;

  /// method to perform a single load-balancing step
  /// @param step the number the actual load-balancing step should get (e.g. if
  /// counting the number of loadbalancing steps)
  void balance(int step) override;

  // getter for variables (passed by reference to avoid
  // direct access to private members of the object)

  // neighbors
  /// method to provide a list of neighbors by MPI rank
  /// @param [out] list the std::vector the list of neighbors is stored to
  std::vector<int> &getNeighbors() override;

  /// method to set method specific data
  /// @param data pointer to an array of integers (int) containing the number of
  /// bins in the system for all three dimensions (int, int, int)
  virtual void setAdditionalData(const void *data) override;

private:
  /// number of bins in each dimension
  std::vector<int> nBins;

  /// MPI data type to transfer data related to vertices
  MPI_Datatype MPIDataTypeT;
  /// MPI data type to transfer data related to work
  MPI_Datatype MPIDataTypeW;

  /// set of communicators used to collect data over the different dimensions,
  /// e.g. to compute the total amount of work in it and to compute the amount
  /// of work each chunk in that dimension should receive
  std::vector<MPI_Comm> communicators;

  /// list of MPI ranks of neighboring domains
  std::vector<int> neighbors;
  /// number of neighbors in each dimension
  std::vector<int> nNeighbors;

  /// method to determine the MPI ranks of the neighbors of the local process
  void find_neighbors();
};

template <class T, class W>
void Histogram_LB<T, W>::setAdditionalData(const void *data) {
  if (nBins.size() < 3)
    nBins.resize(3);

  for (int i = 0; i < 3; ++i)
    nBins.at(i) = *((int *)data + i);
}

// setup routine for the tensor-based load-balancing scheme
// requires:
//              this->globalComm (int): cartesian MPI communicator, from
//                                 which separate sub communicators
//                                 are derived in order to represent
//                                 each plane of domains in the system
template <class T, class W> void Histogram_LB<T, W>::setup() {
  int status;

  // check if Communicator is cartesian
  MPI_Topo_test(this->globalComm, &status);
  if (status != MPI_CART) {
    throw InvalidCommTypeException(
        __FILE__, __func__, __LINE__,
        "Cartesian MPI communicator required, passed communicator is not "
        "cartesian");
  }
  // get the local coordinates, this->periodicity and global size from the MPI
  // communicator
  MPI_Cart_get(this->globalComm, this->dimension, this->global_dims.data(),
               this->periodicity.data(), this->local_coords.data());

  // get the local rank from the MPI communicator
  MPI_Cart_rank(this->globalComm, this->local_coords.data(), &this->localRank);

  // create sub-communicators

  // communicators 0 - 2: reduction of partial histograms
  // communicators 3 - 5: gathering of complete histograms

  // reduction sub-communicators (equal to staggered grid)

  // z-plane
  MPI_Comm_split(this->globalComm, this->local_coords.at(2),
                 this->local_coords.at(0) +
                     this->local_coords.at(1) * this->global_dims.at(0),
                 &communicators.at(2));

  // y-column
  MPI_Comm_split(this->globalComm,
                 this->local_coords.at(2) * this->global_dims.at(1) +
                     this->local_coords.at(1),
                 this->local_coords.at(0), &communicators.at(1));

  // only cell itself
  communicators[0] = MPI_COMM_SELF;

  // gathering sub-communicators

  // x-gathering (same y/z coordinates)
  MPI_Comm_split(this->globalComm,
                 this->local_coords.at(1) +
                     this->local_coords.at(2) * this->global_dims.at(1),
                 this->local_coords.at(0), &communicators.at(3));

  // y-gathering
  MPI_Comm_split(this->globalComm,
                 this->local_coords.at(0) +
                     this->local_coords.at(2) * this->global_dims.at(0),
                 this->local_coords.at(1), &communicators.at(4));

  // z-gathering
  MPI_Comm_split(this->globalComm,
                 this->local_coords.at(0) +
                     this->local_coords.at(1) * this->global_dims.at(0),
                 this->local_coords.at(2), &communicators.at(5));

  // determine correct MPI data type for template T
  if (std::is_same<T, double>::value)
    MPIDataTypeT = MPI_DOUBLE;
  else if (std::is_same<T, float>::value)
    MPIDataTypeT = MPI_FLOAT;
  else if (std::is_same<T, int>::value)
    MPIDataTypeT = MPI_INT;
  else if (std::is_same<T, long>::value)
    MPIDataTypeT = MPI_LONG;
  else {
    throw InvalidCommTypeException(
        __FILE__, __func__, __LINE__,
        "Invalid data type for boundaries given (T)");
  }

  // determine correct MPI data type for template W
  if (std::is_same<W, double>::value)
    MPIDataTypeW = MPI_DOUBLE;
  else if (std::is_same<W, float>::value)
    MPIDataTypeW = MPI_FLOAT;
  else if (std::is_same<W, int>::value)
    MPIDataTypeW = MPI_INT;
  else if (std::is_same<W, long>::value)
    MPIDataTypeW = MPI_LONG;
  else {
    throw InvalidCommTypeException(__FILE__, __func__, __LINE__,
                                       "Invalid data type for work given (W)");
  }

  // calculate neighbors
  int rank_left, rank_right;

  neighbors.clear();
  for (int i = 0; i < this->dimension; ++i) {
    MPI_Cart_shift(this->globalComm, i, 1, &rank_left, &rank_right);
    neighbors.push_back(rank_left);
    neighbors.push_back(rank_right);
  }
}

template <class T, class W> void Histogram_LB<T, W>::balance(int step) {

  int i = 2 - step % 3;

  // required work values for the scheme
  W workSumLocal = (W)0;
  W workSumDimension;
  W workTotalDimension;
  W workAvgDimension;
  W workMinDimension;
  W workMaxDimension;

  // vector to store all values of the histogram for the current dimension
  std::vector<W> work_dimension(nBins.at(i));

  // compute total number of bins in dimension
  int nBinsDimension;
  MPI_Allreduce(&(nBins.at(i)), &nBinsDimension, 1, MPI_INT, MPI_SUM,
                communicators.at(i + 3));

  std::vector<W> work_collection(nBinsDimension);
  std::vector<int> histogramSlices(this->global_dims.at(i));
  std::vector<W> work_new_dimension(this->global_dims.at(i), 0.0);

  // collect how many bins from each process will be received
  MPI_Allgather(&(nBins.at(i)), 1, MPI_INT, histogramSlices.data(), 1, MPI_INT,
                communicators.at(i + 3));

  // add up work to get total work on domain
  for (int n = 0; n < nBins.at(i); ++n) {
    //        std::cout << "DEBUG: " << this->work.size() << " " << n << " " <<
    //        i << " on " << this->localRank << std::endl;
    workSumLocal += this->work.at(n);
  }

  // compute total work in current dimension
  MPI_Allreduce(&workSumLocal, &workSumDimension, 1, MPIDataTypeW, MPI_SUM,
                communicators.at(i));

  // compute total work for current dimension
  MPI_Allreduce(&workSumDimension, &workTotalDimension, 1, MPIDataTypeW,
                MPI_SUM, communicators.at(i + 3));

  int avg_num = this->global_dims.at(i);
  workAvgDimension = workTotalDimension / (W)avg_num;

  // compute local slice of the histogram
  MPI_Allreduce(this->work.data(), work_dimension.data(), nBins.at(i),
                MPIDataTypeW, MPI_SUM, communicators.at(i));
  // displacement array
  std::vector<int> displs(this->global_dims.at(i), 0);
  int tmp = 0;

  for (int n = 0; n < this->global_dims.at(i); ++n) {
    displs[n] = tmp;
    tmp += histogramSlices.at(n);
  }

  // gather complete histogram in current dimension
  MPI_Allgatherv(work_dimension.data(), nBins.at(i), MPIDataTypeW,
                 work_collection.data(), histogramSlices.data(), displs.data(),
                 MPIDataTypeW, communicators[i + 3]);

  int current_slice = 0;

  double work_sum = 0.0;

  // TODO: compute cumulative function - up to workAvgDimension work in each
  // box
  for (int idx = 0; idx < (int)work_collection.size(); ++idx) {
    // work_new_dimension.at(current_slice) += work_collection.at(idx);
    work_sum += work_collection.at(idx);
    if (idx < (int)work_collection.size() - 1 &&
        // work_new_dimension.at(current_slice) + work_collection.at(idx+1)
        //    > workAvgDimension
        work_sum + work_collection.at(idx + 1) >
            (current_slice + 1) * workAvgDimension) {
      histogramSlices.at(current_slice) = idx;
      if (current_slice == (this->global_dims.at(i) - 1)) {
        histogramSlices.at(current_slice) = work_collection.size();
        W tmp_work = (W)0;
        for (int j = 0; j < this->global_dims.at(i) - 1; ++j)
          tmp_work += work_new_dimension.at(j);
        work_new_dimension.at(current_slice) = workTotalDimension - tmp_work;
        break;
      }
      current_slice++;
    }
  }

  // TODO: compute width of domain
  T up = (this->local_coords.at(i) == this->global_dims.at(i) - 1)
             ? (T)work_collection.size()
             : (T)histogramSlices.at(this->local_coords.at(i));
  T down = (this->local_coords.at(i) == 0)
               ? (T)0
               : histogramSlices.at(this->local_coords.at(i) - 1);

  // size of one slice
  T size = this->sysSize[2 * i + 1] / (T)work_collection.size();

  this->prevVertices = this->vertices;

  this->vertices.at(0)[i] = (T)down * size;
  this->vertices.at(1)[i] = (T)up * size;

  // compute min / max work in current dimension
  MPI_Allreduce(work_new_dimension.data() + this->local_coords.at(i),
                &workMinDimension, 1, MPIDataTypeW, MPI_MIN, this->globalComm);
  MPI_Allreduce(work_new_dimension.data() + this->local_coords.at(i),
                &workMaxDimension, 1, MPIDataTypeW, MPI_MAX, this->globalComm);

  if (this->localRank == 0)
    std::cout << "HISTOGRAM: " << i << " " << workMinDimension << " "
              << workMaxDimension << " "
              << (workMaxDimension - workMinDimension) /
                     (workMaxDimension + workMinDimension)
              << std::endl;

  find_neighbors();

  MPI_Barrier(this->globalComm);
  // free created communicators
  for (int i = 0; i < 6; ++i) {
    if (communicators.at(i) != MPI_COMM_SELF &&
        communicators.at(i) != MPI_COMM_WORLD)
      MPI_Comm_free(&(communicators.at(i)));
  }
}

template <class T, class W> void Histogram_LB<T, W>::find_neighbors() {
  neighbors.clear();
  // collect work from right neighbor plane
  MPI_Request sreq, rreq;
  MPI_Status sstat, rstat;
  // array to store neighbor vertices in Y/Z direction (reused)
  T *vertices_loc = new T[4];
  T *vertices_rem =
      new T[8 * this->global_dims.at(0) * this->global_dims.at(1)];

  int rem_rank;
  int rem_coords[3];

  // determine neighbors
  int rank_left, rank_right;

  // offset to get the correct rank
  int rank_offset;
  int offset_coords[3];

  // X-neighbors are static
  nNeighbors.at(0) = nNeighbors.at(1) = 1;

  // find X-neighbors
  MPI_Cart_shift(this->globalComm, 0, 1, &rank_left, &rank_right);

  // store X-neighbors
  neighbors.push_back(rank_left);
  neighbors.push_back(rank_right);

  // find Y-neighbors to get border information from
  MPI_Cart_shift(this->globalComm, 1, 1, &rank_left, &rank_right);

  // collect border information from local column
  vertices_loc[0] = this->vertices.at(0)[0];
  vertices_loc[1] = this->vertices.at(1)[0];
  MPI_Allgather(vertices_loc, 2, MPIDataTypeT,
                vertices_rem + 2 * this->global_dims.at(0), 2, MPIDataTypeT,
                communicators.at(1));

  // exchange local column information with upper neighbor in Y direction (cart
  // grid)
  MPI_Irecv(vertices_rem, 2 * this->global_dims.at(0), MPIDataTypeT, rank_left,
            0, this->globalComm, &rreq);
  MPI_Isend(vertices_rem + 2 * this->global_dims.at(0),
            2 * this->global_dims.at(0), MPIDataTypeT, rank_right, 0,
            this->globalComm, &sreq);

  // determine the offset in ranks
  offset_coords[0] = 0;
  offset_coords[1] = this->local_coords.at(1) - 1;
  offset_coords[2] = this->local_coords.at(2);

  rem_coords[1] = offset_coords[1];
  rem_coords[2] = offset_coords[2];

  MPI_Cart_rank(this->globalComm, offset_coords, &rank_offset);

  MPI_Barrier(this->globalComm);
  if (this->localRank == 0)
    std::cout << "HISTOGRAM: neighbor_find y-communication" << std::endl;
  // wait for communication
  MPI_Wait(&sreq, &sstat);
  MPI_Wait(&rreq, &rstat);

  // iterate about neighbor borders to determine the neighborship relation
  nNeighbors.at(2) = 0;
  for (int x = 0; x < this->global_dims.at(0); ++x) {
    if ((vertices_rem[2 * x] <= vertices_loc[0] &&
         vertices_loc[0] < vertices_rem[2 * x + 1]) ||
        (vertices_rem[2 * x] < vertices_loc[1] &&
         vertices_loc[1] <= vertices_rem[2 * x + 1]) ||
        (vertices_rem[2 * x] >= vertices_loc[0] &&
         vertices_loc[0] < vertices_rem[2 * x + 1] &&
         vertices_loc[1] >= vertices_rem[2 * x + 1])) {
      nNeighbors.at(2)++;
      rem_coords[0] = x;
      MPI_Cart_rank(this->globalComm, rem_coords, &rem_rank);
      neighbors.push_back(rem_rank);
    }
  }

  // barrier to ensure every process concluded the calculations before
  // overwriting remote borders!
  MPI_Barrier(this->globalComm);

  // exchange local column information with lower neighbor in Y direction (cart
  // grid)
  MPI_Irecv(vertices_rem, 2 * this->global_dims.at(0), MPIDataTypeT, rank_right,
            0, this->globalComm, &rreq);
  MPI_Isend(vertices_rem + 2 * this->global_dims.at(0),
            2 * this->global_dims.at(0), MPIDataTypeT, rank_left, 0,
            this->globalComm, &sreq);

  // determine the offset in ranks
  offset_coords[0] = 0;
  offset_coords[1] = this->local_coords.at(1) + 1;
  offset_coords[2] = this->local_coords.at(2);

  rem_coords[1] = offset_coords[1];
  rem_coords[2] = offset_coords[2];

  MPI_Cart_rank(this->globalComm, offset_coords, &rank_offset);

  MPI_Barrier(this->globalComm);
  if (this->localRank == 0)
    std::cout << "HISTOGRAM: neighbor_find y-communication 2" << std::endl;
  // wait for communication
  MPI_Wait(&sreq, &sstat);
  MPI_Wait(&rreq, &rstat);

  // iterate about neighbor borders to determine the neighborship relation
  nNeighbors.at(3) = 0;
  for (int x = 0; x < this->global_dims.at(0); ++x) {
    if ((vertices_rem[2 * x] <= vertices_loc[0] &&
         vertices_loc[0] < vertices_rem[2 * x + 1]) ||
        (vertices_rem[2 * x] < vertices_loc[1] &&
         vertices_loc[1] <= vertices_rem[2 * x + 1]) ||
        (vertices_rem[2 * x] >= vertices_loc[0] &&
         vertices_loc[0] < vertices_rem[2 * x + 1] &&
         vertices_loc[1] >= vertices_rem[2 * x + 1])) {
      nNeighbors.at(3)++;
      rem_coords[0] = x;
      MPI_Cart_rank(this->globalComm, rem_coords, &rem_rank);
      neighbors.push_back(rem_rank);
    }
  }

  // barrier to ensure every process concluded the calculations before
  // overwriting remote borders!
  MPI_Barrier(this->globalComm);

  // find Z-neighbors to get border information from
  MPI_Cart_shift(this->globalComm, 2, 1, &rank_left, &rank_right);

  // collect border information from local column
  vertices_loc[0] = this->vertices.at(0)[0];
  vertices_loc[1] = this->vertices.at(1)[0];
  vertices_loc[2] = this->vertices.at(0)[1];
  vertices_loc[3] = this->vertices.at(1)[1];

  MPI_Barrier(this->globalComm);

  MPI_Allgather(vertices_loc, 4, MPIDataTypeT,
                vertices_rem +
                    4 * this->global_dims.at(0) * this->global_dims.at(1),
                4, MPIDataTypeT, communicators.at(2));

  // exchange local column information with upper neighbor in Z direction (cart
  // grid)
  MPI_Irecv(vertices_rem, 4 * this->global_dims.at(0) * this->global_dims.at(1),
            MPIDataTypeT, rank_left, 0, this->globalComm, &rreq);
  MPI_Isend(vertices_rem +
                4 * this->global_dims.at(0) * this->global_dims.at(1),
            4 * this->global_dims.at(0) * this->global_dims.at(1), MPIDataTypeT,
            rank_right, 0, this->globalComm, &sreq);

  // determine the offset in ranks
  offset_coords[0] = 0;
  offset_coords[1] = 0;
  offset_coords[2] = this->local_coords.at(2) - 1;

  rem_coords[2] = offset_coords[2];

  MPI_Cart_rank(this->globalComm, offset_coords, &rank_offset);

  MPI_Barrier(this->globalComm);
  if (this->localRank == 0)
    std::cout << "HISTOGRAM: neighbor_find z-communication" << std::endl;
  // wait for communication
  MPI_Wait(&sreq, &sstat);
  MPI_Wait(&rreq, &rstat);

  // iterate about neighbor borders to determine the neighborship relation
  nNeighbors.at(4) = 0;
  for (int y = 0; y < this->global_dims.at(1); ++y) {
    for (int x = 0; x < this->global_dims.at(0); ++x) {
      if (((vertices_rem[4 * (x + y * this->global_dims.at(0)) + 2] <=
                vertices_loc[2] &&
            vertices_loc[2] <
                vertices_rem[4 * (x + y * this->global_dims.at(0)) + 3]) ||
           (vertices_rem[4 * (x + y * this->global_dims.at(0)) + 2] <
                vertices_loc[3] &&
            vertices_loc[3] <=
                vertices_rem[4 * (x + y * this->global_dims.at(0)) + 3]) ||
           (vertices_rem[4 * (x + y * this->global_dims.at(0)) + 2] >=
                vertices_loc[2] &&
            vertices_loc[2] <
                vertices_rem[4 * (x + y * this->global_dims.at(0)) + 3] &&
            vertices_loc[3] >=
                vertices_rem[4 * (x + y * this->global_dims.at(0)) + 3])))
        if (((vertices_rem[4 * (x + y * this->global_dims.at(0))] <=
                  vertices_loc[0] &&
              vertices_loc[0] <
                  vertices_rem[4 * (x + y * this->global_dims.at(0)) + 1]) ||
             (vertices_rem[4 * (x + y * this->global_dims.at(0))] <
                  vertices_loc[1] &&
              vertices_loc[1] <=
                  vertices_rem[4 * (x + y * this->global_dims.at(0)) + 1]) ||
             (vertices_rem[4 * (x + y * this->global_dims.at(0))] >=
                  vertices_loc[0] &&
              vertices_loc[0] <
                  vertices_rem[4 * (x + y * this->global_dims.at(0)) + 1] &&
              vertices_loc[1] >=
                  vertices_rem[4 * (x + y * this->global_dims.at(0)) + 1]))) {
          nNeighbors.at(4)++;
          rem_coords[1] = y;
          rem_coords[0] = x;
          MPI_Cart_rank(this->globalComm, rem_coords, &rem_rank);
          neighbors.push_back(rem_rank);
        }
    }
  }

  // barrier to ensure every process concluded the calculations before
  // overwriting remote borders!
  MPI_Barrier(this->globalComm);

  // exchange local column information with upper neighbor in Y direction (cart
  // grid)
  MPI_Irecv(vertices_rem, 4 * this->global_dims.at(0) * this->global_dims.at(1),
            MPIDataTypeT, rank_right, 0, this->globalComm, &rreq);
  MPI_Isend(vertices_rem +
                4 * this->global_dims.at(0) * this->global_dims.at(1),
            4 * this->global_dims.at(0) * this->global_dims.at(1), MPIDataTypeT,
            rank_left, 0, this->globalComm, &sreq);

  // determine the offset in ranks
  offset_coords[0] = 0;
  offset_coords[1] = 0;
  offset_coords[2] = this->local_coords.at(2) + 1;

  rem_coords[2] = offset_coords[2];

  MPI_Cart_rank(this->globalComm, offset_coords, &rank_offset);

  MPI_Barrier(this->globalComm);
  if (this->localRank == 0)
    std::cout << "HISTOGRAM: neighbor_find z-communication 2" << std::endl;

  // wait for communication
  MPI_Wait(&sreq, &sstat);
  MPI_Wait(&rreq, &rstat);
  if (this->localRank == 0)
    std::cout << "HISTOGRAM: neighbor_find z-communication 2" << std::endl;

  // iterate about neighbor borders to determine the neighborship relation
  nNeighbors.at(5) = 0;
  for (int y = 0; y < this->global_dims.at(1); ++y) {
    for (int x = 0; x < this->global_dims.at(0); ++x) {
      if (((vertices_rem[4 * (x + y * this->global_dims.at(0)) + 2] <=
                vertices_loc[2] &&
            vertices_loc[2] <
                vertices_rem[4 * (x + y * this->global_dims.at(0)) + 3]) ||
           (vertices_rem[4 * (x + y * this->global_dims.at(0)) + 2] <
                vertices_loc[3] &&
            vertices_loc[3] <=
                vertices_rem[4 * (x + y * this->global_dims.at(0)) + 3]) ||
           (vertices_rem[4 * (x + y * this->global_dims.at(0)) + 2] >=
                vertices_loc[2] &&
            vertices_loc[2] <
                vertices_rem[4 * (x + y * this->global_dims.at(0)) + 3] &&
            vertices_loc[3] >=
                vertices_rem[4 * (x + y * this->global_dims.at(0)) + 3])))
        if (((vertices_rem[4 * (x + y * this->global_dims.at(0))] <=
                  vertices_loc[0] &&
              vertices_loc[0] <
                  vertices_rem[4 * (x + y * this->global_dims.at(0)) + 1]) ||
             (vertices_rem[4 * (x + y * this->global_dims.at(0))] <
                  vertices_loc[1] &&
              vertices_loc[1] <=
                  vertices_rem[4 * (x + y * this->global_dims.at(0)) + 1]) ||
             (vertices_rem[4 * (x + y * this->global_dims.at(0))] >=
                  vertices_loc[0] &&
              vertices_loc[0] <
                  vertices_rem[4 * (x + y * this->global_dims.at(0)) + 1] &&
              vertices_loc[1] >=
                  vertices_rem[4 * (x + y * this->global_dims.at(0)) + 1]))) {
          nNeighbors.at(5)++;
          rem_coords[1] = y;
          rem_coords[0] = x;
          MPI_Cart_rank(this->globalComm, rem_coords, &rem_rank);
          neighbors.push_back(rem_rank);
        }
    }
  }

  // barrier to ensure every process concluded the calculations before
  // overwriting remote borders!
  MPI_Barrier(this->globalComm);

  // clear up vertices array
  delete[] vertices_loc;
  delete[] vertices_rem;
}

// provide list of neighbors
template <class T, class W>
std::vector<int> &Histogram_LB<T, W>::getNeighbors() {
  return neighbors;
}

}//namespace ALL

#endif

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_STAGGERED_HEADER_INCLUDED
#define ALL_STAGGERED_HEADER_INCLUDED

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_CUSTOM_EXCEPTIONS_INC
#define ALL_CUSTOM_EXCEPTIONS_INC

#include <exception>
#include <sstream>
#include <string>

namespace ALL {

/// Customized exceptions for ALL, modified for each specific exception type
struct CustomException : public std::exception {
protected:
  /// file the exception occured in
  const char *file;
  /// function the exception occured in
  const char *func;
  /// line the exception occured in
  int line;
  /// information on the exception
  const char *info;
  /// name of the exception
  const char *loc_desc;
  /// error message
  std::string error_msg;
  /// error identificators for Fortran error retrieval, remember to
  /// update the Fortran module as well!
  enum struct ErrorID : int {
	Generic = 1,
	PointDimensionMissmatch,
	InvalidCommType,
	InvalidArgument,
	OutOfBounds,
	InternalError,
	FilesystemError
  };
  /// error identificator retrieved by Fortran
  ErrorID error_id;

public:
  /// constructor for an exception used in ALL
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  CustomException(const char *file_ = "", const char *f_ = "", int l_ = -1,
                      const char *i_ = "",
                      const char *loc_desc_ = "ALLCustomException",
		      const ErrorID error_id_ = ErrorID::Generic)
      : file(file_), func(f_), line(l_), info(i_), loc_desc(loc_desc_), error_id(error_id_) {
    std::stringstream ss;
    ss << loc_desc << ": " << info << "\n"
       << "Function: " << func << "\n"
       << "File: " << file << "\n"
       << "Line: " << line << "\n";
    error_msg = ss.str();
  }
  /// method to get the function name from where the exception was thrown
  /// @return the function name
  const char *get_func() const { return func; }

  /// method to get the line from where the exception was thrown
  /// @return the line
  int get_line() const { return line; }

  /// method to get the additional information about the error leading to the
  /// exception
  /// @return the information given about the error
  const char *get_info() { return info; }

  /// overloaded method from the base Exception class to return an error message
  /// @return the error message of the exception
  virtual const char *what() const throw() { return error_msg.c_str(); }

  /// retrieve error id for Fortran interface
  /// @return error id from ErrorID enum
  int get_error_id() { return static_cast<int>(error_id); }
};

/// Exception to be used for missmatches in dimension for ALL::Point class
struct PointDimensionMissmatchException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  PointDimensionMissmatchException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Dimension missmatch in Point objects.",
      const char *loc_desc_ = "ALLPointDimMissmatchException",
      const ErrorID error_id_ = ErrorID::PointDimensionMissmatch)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid Communicators in a load-balancing method
struct InvalidCommTypeException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidCommTypeException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Type of MPI communicator not valid.",
      const char *loc_desc_ = "ALLCommTypeInvalidException",
      const ErrorID error_id_ = ErrorID::InvalidCommType)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid parameters in any type of classes
struct InvalidArgumentException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidArgumentException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Invalid argument given.",
      const char *loc_desc_ = "ALLInvalidArgumentException",
      const ErrorID error_id_ = ErrorID::InvalidArgument)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an array went out of bounds
struct OutOfBoundsException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  OutOfBoundsException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Access to array out of bounds.",
      const char *loc_desc_ = "ALLOutOfBoundsErrorException",
      const ErrorID error_id_ = ErrorID::OutOfBounds)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an internal error has occured
struct InternalErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InternalErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Internal error occured, see description.",
      const char *loc_desc_ = "ALLInternalErrorException",
      const ErrorID error_id_ = ErrorID::InternalError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if a filesystem error has occured
struct FilesystemErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  FilesystemErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Filesystem error occured, see description.",
      const char *loc_desc_ = "ALLFilesystemErrorException",
      const ErrorID error_id_ = ErrorID::FilesystemError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

}//namespace ALL

#endif

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_LB_HEADER_INCLUDED
#define ALL_LB_HEADER_INCLUDED

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_POINT_HEADER_INC
#define ALL_POINT_HEADER_INC

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_CUSTOM_EXCEPTIONS_INC
#define ALL_CUSTOM_EXCEPTIONS_INC

#include <exception>
#include <sstream>
#include <string>

namespace ALL {

/// Customized exceptions for ALL, modified for each specific exception type
struct CustomException : public std::exception {
protected:
  /// file the exception occured in
  const char *file;
  /// function the exception occured in
  const char *func;
  /// line the exception occured in
  int line;
  /// information on the exception
  const char *info;
  /// name of the exception
  const char *loc_desc;
  /// error message
  std::string error_msg;
  /// error identificators for Fortran error retrieval, remember to
  /// update the Fortran module as well!
  enum struct ErrorID : int {
	Generic = 1,
	PointDimensionMissmatch,
	InvalidCommType,
	InvalidArgument,
	OutOfBounds,
	InternalError,
	FilesystemError
  };
  /// error identificator retrieved by Fortran
  ErrorID error_id;

public:
  /// constructor for an exception used in ALL
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  CustomException(const char *file_ = "", const char *f_ = "", int l_ = -1,
                      const char *i_ = "",
                      const char *loc_desc_ = "ALLCustomException",
		      const ErrorID error_id_ = ErrorID::Generic)
      : file(file_), func(f_), line(l_), info(i_), loc_desc(loc_desc_), error_id(error_id_) {
    std::stringstream ss;
    ss << loc_desc << ": " << info << "\n"
       << "Function: " << func << "\n"
       << "File: " << file << "\n"
       << "Line: " << line << "\n";
    error_msg = ss.str();
  }
  /// method to get the function name from where the exception was thrown
  /// @return the function name
  const char *get_func() const { return func; }

  /// method to get the line from where the exception was thrown
  /// @return the line
  int get_line() const { return line; }

  /// method to get the additional information about the error leading to the
  /// exception
  /// @return the information given about the error
  const char *get_info() { return info; }

  /// overloaded method from the base Exception class to return an error message
  /// @return the error message of the exception
  virtual const char *what() const throw() { return error_msg.c_str(); }

  /// retrieve error id for Fortran interface
  /// @return error id from ErrorID enum
  int get_error_id() { return static_cast<int>(error_id); }
};

/// Exception to be used for missmatches in dimension for ALL::Point class
struct PointDimensionMissmatchException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  PointDimensionMissmatchException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Dimension missmatch in Point objects.",
      const char *loc_desc_ = "ALLPointDimMissmatchException",
      const ErrorID error_id_ = ErrorID::PointDimensionMissmatch)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid Communicators in a load-balancing method
struct InvalidCommTypeException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidCommTypeException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Type of MPI communicator not valid.",
      const char *loc_desc_ = "ALLCommTypeInvalidException",
      const ErrorID error_id_ = ErrorID::InvalidCommType)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid parameters in any type of classes
struct InvalidArgumentException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidArgumentException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Invalid argument given.",
      const char *loc_desc_ = "ALLInvalidArgumentException",
      const ErrorID error_id_ = ErrorID::InvalidArgument)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an array went out of bounds
struct OutOfBoundsException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  OutOfBoundsException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Access to array out of bounds.",
      const char *loc_desc_ = "ALLOutOfBoundsErrorException",
      const ErrorID error_id_ = ErrorID::OutOfBounds)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an internal error has occured
struct InternalErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InternalErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Internal error occured, see description.",
      const char *loc_desc_ = "ALLInternalErrorException",
      const ErrorID error_id_ = ErrorID::InternalError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if a filesystem error has occured
struct FilesystemErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  FilesystemErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Filesystem error occured, see description.",
      const char *loc_desc_ = "ALLFilesystemErrorException",
      const ErrorID error_id_ = ErrorID::FilesystemError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

}//namespace ALL

#endif

#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace ALL {

template <class T> class Point;
template <typename T>
std::ostream &operator<<(std::ostream &, const Point<T> &);

/// @tparam T floating point type used, has to be identical to the type used for
/// the vertices and borders
template <class T> class Point {
public:
  /// default constructor
  Point() : dimension(0) {}
  /// constructor
  /// @param d dimension of the point object
  Point(const int d) : dimension(d) {
    coordinates.resize(d);
    weight = (T)1;
  }
  /// constructor with initialization
  /// @param d dimension of the point object
  /// @param data positions
  Point(const int d, const T *data) : Point<T>(d) {
    // copy each element of the array into the vector (insecure, no boundary
    // checks for data!)
    for (auto i = 0; i < d; ++i)
      coordinates.at(i) = data[i];
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  Point(const std::vector<T> &data) {
    // initialize the coordinates vector with the data vector
    coordinates.insert(coordinates.begin(), data.begin(), data.end());
    // update the dimension with the size of the data vector
    dimension = data.size();
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  Point(const int d, const T *data, const T w) : Point<T>(d, data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  /// @param i index of the point
  Point(const int d, const T *data, const T w, const long i)
      : Point<T>(d, data, w) {
    id = i;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  Point(const std::vector<T> &data, const T w) : Point<T>(data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  /// @param i index of the point
  Point(const std::vector<T> &data, const T w, const long i)
      : Point<T>(data, w) {
    id = i;
  }

  /// destructor
  ~Point<T>(){};

  // TODO: return values to check if operation was successful?
  /// method to change the dimension of the point object
  /// @param d new dimension
  void setDimension(const int d) {
    dimension = d;
    coordinates.resize(d);
  }

  /// method to change the weight of the point object
  /// @param w new weight
  void set_weight(const T w) { weight = w; }

  /// method to change the index of the particle
  /// @param i new index
  void set_id(const long i) { id = i; }

  /// access operator to access an element of the point object
  /// @param idx the index of the element to be accessed
  /// @result reference to the indexed element
  T &operator[](const std::size_t idx) { return coordinates.at(idx); }

  /// access operator to access an element of the constant point object
  /// @param idx the index of the element to be accessed
  /// @result const reference to the indexed element
  const T &operator[](const std::size_t idx) const {
    return coordinates.at(idx);
  }

  /// method to get the weight of the point object
  /// @return the weight of the point object
  T getWeight() const { return weight; }

  /// method to get the index of the point object
  /// @return the index of the point object
  long get_id() const { return id; }

  /// method to get the dimension of the point object
  /// @return the dimension of the point object
  int getDimension() const { return dimension; }

  /// method to compute the norm of the vector described by the
  /// point object
  /// @param nd type of the norm (default: 2, i.e. the Euclidean norm)
  /// @return norm of the vector
  T norm(T nd = 2) {
    T res = 0;
    for (int d = 0; d < dimension; ++d)
      res += std::pow(coordinates.at(d), nd);
    return std::pow(res, 1.0 / nd);
  }

  /// method to compute the Euclidean distance (two-norm) between the local and
  /// the provided point object
  /// @param p the point object for which the distence to the local point object
  /// is computed
  /// @return the distance between the two points
  T d(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p).norm();
  }

  /// method to compute the Manhatten / city-block distance (one-norm) between
  /// the local and the provided point object
  /// @param p the point object for which the distance to the local point object
  /// is computed
  /// @return the distance between the two points
  T d_1(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p, 1).norm();
  }

  /// method to compute the distance vector between the local point object and
  /// the provided point object
  /// @param p the point object for which the distance vector to the local point
  /// object is computed
  /// @return the distance vector between the two points
  Point<T> dist(Point<T> &p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    std::vector<T> d_v;
    for (int d = 0; d < dimension; ++d)
      d_v.push_back(p[d] - coordinates.at(d));

    return Point<T>(d_v);
  }

  /// method to compute the distance of the local point object from a plane
  /// spanned by provided points
  /// @param A anchor point for the plane
  /// @param B anchor point for the plane
  /// @param C anchor point for the plane
  /// @return distance between local point object and plane
  T dist_plane(const Point<T> &A, const Point<T> &B,
               const Point<T> &C) {

    if (A.getDimension() != dimension || B.getDimension() != dimension ||
        C.getDimension() != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);

    // vectors spanning the plane from vertex 'a'
    T vb[3];
    T vc[3];

    for (int i = 0; i < 3; ++i) {
      vb[i] = B[i] - A[i];
      vc[i] = C[i] - A[i];
    }

    // normal vector of plane
    T n[3];

    n[0] = vb[1] * vc[2] - vb[2] * vc[1];
    n[1] = vb[2] * vc[0] - vb[0] * vc[2];
    n[2] = vb[0] * vc[1] - vb[1] * vc[0];

    // length of normal vector
    T dn = n.norm();

    // distance from origin
    T d = n * A;

    // compute distance of test vertex to plane
    return std::abs((n[0] * coordinates.at(0) + n[1] * coordinates.at(1) +
                     n[2] * coordinates.at(2) - d) /
                    dn);
  }

  /// operator for the addition of two point objects
  /// @param rhs point to add the local point object to
  /// @return sum of local point object and provided point object
  Point<T> operator+(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) + rhs[d];
    }
    return result;
  }

  /// operator for the addition of two point objects
  /// @param rhs point to subtract from the local point object
  /// @return difference vector between local point object and provided point
  /// object
  Point<T> operator-(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) - rhs[d];
    }
    return result;
  }

  /// operator to compute the dot product between two point objects
  /// @param rhs point object to compute the dot product with
  /// @return dot product between the two point objects
  T operator*(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    T result = (T)0.0;
    for (int d = 0; d < dimension; ++d) {
      result += coordinates.at(d) * rhs[d];
    }
    return result;
  }

  /// operator to scale the local point object by a provided factor
  /// @param rhs scaling factor
  /// @return scaled point object
  Point<T> operator*(const T &rhs) const {
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) * rhs;
    }
    return result;
  }

  /// operator to compute the cross product between two point objects
  /// @param rhs point object to compute the cross product with
  /// @return cross product between the two point objects
  /// @attention only works for 3D points / vectors
  Point<T> cross(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension && dimension != 3) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at((d + 1) % 3) * rhs[(d + 2) % 3] -
                  coordinates.at((d + 2) % 3) * rhs[(d + 1) % 3];
    }
    return result;
  }

  /// method to determine if the local point object has the same orientation to
  /// a plane spanned by point objects A,B,C as the provided point P
  /// @param A anchor point A
  /// @param B anchor point B
  /// @param C anchor point C
  /// @param P reference point P
  /// @return the local point object has the same orientation to the plane as
  /// @attention if the reference point is located within the plane, it will not
  /// have the same orientation as the local point! the reference point
  bool same_side_plane(const Point<T> &A, const Point<T> &B,
                       const Point<T> &C, const Point<T> &P) {
    // compute difference vectors:
    Point<T> BA = B - A;
    Point<T> CA = C - A;
    Point<T> PA = P - A;
    Point<T> tA = *(this) - A;

    // compute normal vector of plane
    Point<T> n = CA.cross(BA);

    // compute scalar product of distance
    // vectors with normal vector
    T PAn = PA * n;
    T tAn = tA * n;

    return ((PAn * tAn) > 0);
  }

  /// method to check if the local point object is inside a tetrahedron
  /// described by the vertices A,B,C and D
  /// @param A vertex A
  /// @param B vertex B
  /// @param C vertex C
  /// @param D vertex D
  /// @return the point is within the tetrahedron
  /// @attention a point that is on the surface of the tetrahedron is not inside
  /// it
  bool inTetrahedron(const Point<T> &A, const Point<T> &B,
                     const Point<T> &C, const Point<T> &D) {
    /// for all surfaces of the tetrahedron check if the local point has the
    /// same orientation as the remaining vertex of the tetrahedron, to be
    /// inside the tetrahedron that must be fulfilled
    return (same_side_plane(A, B, C, D) && same_side_plane(B, C, D, A) &&
            same_side_plane(C, D, A, B) && same_side_plane(A, D, B, C));
  };

private:
  /// dimension of the point object
  int dimension;
  /// index for the point
  long id;
  // array containg the coordinates
  std::vector<T> coordinates;
  /// weight of the point to be used if points are not to be equally considered
  /// in computations, e.g. if number of interactions are considered
  T weight;
};

/// output operator for a point object
/// @param os output stream the point object should be printed to
/// @param p the point object to be printed
/// @return the modified output stream
template <class T>
std::ostream &operator<<(std::ostream &os, const Point<T> &p) {
  for (int i = 0; i < p.getDimension(); ++i)
    os << p[i] << " ";
  os << p.getWeight();
  return os;
}

/// operator to scale a point by a factor (reversed way of notation T *
/// Point<T>)
/// @param lhs scaling factor
/// @param rhs the point object to be scaled
/// @param scaled point object
template <class T>
Point<T> operator*(const T &lhs, const Point<T> &rhs) {
  return rhs * lhs;
}

// template <class T>
// Point<T> operator/(const T &lhs, const Point<T> &rhs) {
//   return rhs * ((T)1 / lhs);
// }

}//namespace ALL

#endif

#include <mpi.h>
#include <vector>

namespace ALL {

/// @tparam T data for vertices and related data
/// @tparam W data for work and related data
template <class T, class W> class LB {
public:
  /// constructor for the basic load-balancing class, sets up parameters
  /// required by all balancing methods
  /// @param[in] dim dimension of the vertices used
  /// @param[in] g correction factor for the computation of shifts
  LB(const int dim, const T g) : gamma(g), dimension(dim) {
    // set allowed minimum size to zero
    minSize = std::vector<T>(dim, 0.0);
    periodicity.resize(dim);
    local_coords.resize(dim);
    global_dims.resize(dim);
    neighborVertices.resize(0);
  }

  /// destructor
  virtual ~LB() = default;

  /// abstract definition of the setup method
  virtual void setup() = 0;

  /// abstract definition of the balancing method
  virtual void balance(const int step) = 0;

  /// abstract definition of the method to get the neighbors of the local domain
  /// @result std::vector<int> to store the MPI ranks of the neighbors
  /// to
  virtual std::vector<int> &getNeighbors() = 0;

  /// method to update the vertices used for the balancing step, overwrites old
  /// set of vertices
  /// @param[in] vertices_in vector containg the new vertices to be used
  virtual void setVertices(const std::vector<Point<T>> &vertices_in) {
    // as a basic assumption the number of resulting vertices
    // is equal to the number of input vertices:
    // exceptions:
    //      VORONOI
    vertices = vertices_in;
    prevVertices = vertices_in;
  }

  /// method to set the dimension of the vertices
  /// @param[in] d the dimension to be used
  /// @attention most methods currently support 3D vertices only
  virtual void setDimension(const int d) { dimension = d; }

  /// method to get the dimension of the vertices
  /// @return the dimension of the vertices
  virtual int getDimension() { return dimension; }

  /// method to set the correction value gamma
  /// @param[in] g the correction value to use
  virtual void setGamma(const T g) { gamma = g; }

  /// method to get the correction value currently used
  /// @return the current correction value
  virtual const T getGamma() { return gamma; }

  /// method to set a multi-dimensional work for the local domain
  /// @param[in] w vector containing all the dimensions of the work to be used
  /// for the local domain
  virtual void setWork(const std::vector<W> &w) { work = w; }

  /// method to set a scalar work for the local domain
  /// @param[in] w value containing the work to be used for the local domain
  virtual void setWork(const W w) {
    work.resize(1);
    work.at(0) = w;
  }

  /// method to set the minimum domain size in each dimension
  /// @param[in] minSize the minimum size of a domain in all dimensions
  virtual void setMinDomainSize(const std::vector<T> &minSize) {
    this->minSize = minSize;
  }

  /// method to get the minimum domain size the balancing methods have to obey
  /// @return the minimum domain size allowed
  virtual const std::vector<T> &getMinDomainSize() { return minSize; }

  /// method to set the (orthogonal) size of the system
  /// @param[in] sysSize system size in all dimensions
  virtual void setSysSize(const std::vector<T> &newSysSize) {
    sysSize = newSysSize;
  }

  /// method to get the currently stored system size
  /// @return the currently stored system size
  virtual const std::vector<T> &getSysSize() { return sysSize; }

  /// method to get the currently stored work for the local process
  /// @return the currently stored work
  /// @attention always returns a std::vector, for scalar work, it has length 1
  virtual std::vector<W> &getWork() { return work; }

  /// method to get result vertices
  /// @return the resulting vertices after a balancing step
  virtual std::vector<Point<T>> &getVertices() { return vertices; }

  /// method to get the original vertices before the last balancing step
  /// @return the original unmodified vertices before the last balancing step
  /// @attention since the original and resulting vertices are set up in the
  /// balancing method, the result is undefined before calling the balancing
  /// method at least once
  virtual std::vector<Point<T>> &getPrevVertices() { return prevVertices; };

  /// method to set the MPI communicator to be used by the balancing method
  /// @param[in] comm the MPI communicator to be used
  virtual void setCommunicator(const MPI_Comm comm) {
    // store communicator
    globalComm = comm;
    // get local rank within communicator
    MPI_Comm_rank(comm, &localRank);
  }

  /// method the get the number of vertices stored for the local domain
  /// @return number of local vertices
  int getNVertices() { return vertices.size(); }

  /// method to set undefined method specific data, which is not shared between
  /// different methods but needs to be set by a unified interface
  /// @param[in] data the data be passed to the balancing method
  virtual void setAdditionalData(const void *data) = 0;

  /// method to provide a list of vertices describing the neighboring domains
  /// currently only implemented for VORONOI, as a means to get the anchor points
  /// of the surrounding domains
  std::vector<T> &getNeighborVertices() {
    return neighborVertices; }

protected:
  /// correction factor
  T gamma;
  /// dimension of the used vertices
  int dimension;
  /// used MPI communicator
  MPI_Comm globalComm;
  /// local rank in the used MPI communicator
  int localRank;
  /// minimum domain size
  /// @attention not all balancing method support this
  std::vector<T> minSize;
  /// (orthogonal) system size
  std::vector<T> sysSize;
  /// local work
  std::vector<W> work;
  /// local vertices after previous balancing step
  std::vector<Point<T>> vertices;
  /// original vertices before previous balancing step
  std::vector<Point<T>> prevVertices;
  /// dimensions of the global process grid
  std::vector<int> global_dims;
  /// cartesian coordinates of the local domain in the process grid
  std::vector<int> local_coords;
  /// periodicity of the MPI communicator / system
  std::vector<int> periodicity;
  /// vertices describing neighboring domains
  std::vector<T> neighborVertices;
  /// method the resize the vertex list
  /// @param [in] new_size the new size of the vertex list
  void resizeVertices(const int newSize) { vertices.resize(newSize); }

};

}//namespace ALL

#endif // ALL_LB_HEADER_INCLUDED

/*
Copyright 2020-2020 Stephan Schulz, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_DEFINES_HEADER_INCLUDED
#define ALL_DEFINES_HEADER_INCLUDED

#if defined(__clang__)
#define known_unused __attribute__((unused))

#elif defined(__INTEL_COMPILER)
#warning "The Intel compiler is not properly supported."
#define known_unused

#elif defined(__GNUC__) || defined(__GNUG__)
#define known_unused __attribute__((unused))

#elif defined(_MSC_VER)
#warning "The Microsoft compilers are not supported."
#define known_unused

#else
#warning "Unknown compilers are not supported."
#define known_unused

#endif

#endif//ALL_DEFINES_HEADER_INCLUDED

#include <exception>
#include <mpi.h>
#include <vector>

namespace ALL {

/// Load-balancing scheme based on a hierarchical scheme, which is based on a
/// local one-dimensional equilibration between neighboring domains or
/// compositions of domains. In the first step the domains in a collective plane
/// are compared to the composite plane in the chosen direction. Depending on
/// the ratio of work in both planes the border between them is shifted towards
/// the plane with more work. In the following two steps this procedure is
/// repeated for composite columns and then single domains.
/// @tparam T data for vertices and related data
/// @tparam W data for work and related data
template <class T, class W> class Staggered_LB : public LB<T, W> {
public:
  /// default constructor
  Staggered_LB() {}
  /// constructor initializing basic parameters
  /// @param[in] d the dimension of the used vertices
  /// @param[in] w the scalar work assigned to the local domain
  /// @param[in] g the correction factor gamma
  Staggered_LB(int d, W w, T g) : LB<T, W>(d, g) {
    this->setWork(w);

    // array of MPI communicators for each direction (to collect work
    // on each plane)
    communicators.resize(d);
    for (int _d = 0; _d < d; ++_d)
      communicators.at(_d) = MPI_COMM_NULL;

    nNeighbors.resize(2 * d);
  }

  /// default destructor
  ~Staggered_LB();
  ;

  /// method to setup the method specific internal parameters
  void setup() override;

  /// method to execute a load-balancing step, which updates the resulting
  /// vertices based on the stored work assigned
  /// @param[in] step the number of the load-balancing step (used in debugging
  /// output)
  void balance(int step) override;

  /// method to provide a list of the neighbors of the local domain
  /// @param[out] list reference to a std::vector of integers where the list of
  /// neighbors will be assigned to
  virtual std::vector<int> &getNeighbors() override;

  /// method to set specific data structures (unused for staggered grid method)
  /// @param[in] data pointer to the data structure
  virtual void setAdditionalData(known_unused const void *data) override {}

private:
  /// data type for the communication of vertex-related data
  MPI_Datatype MPIDataTypeT;
  /// data type for the communication of work-related data
  MPI_Datatype MPIDataTypeW;

  /// list of internally used MPI communicators
  std::vector<MPI_Comm> communicators;

  /// list of ranks of neighbors of the local domain
  std::vector<int> neighbors;
  /// number of neighbors in each dimension
  std::vector<int> nNeighbors;

  /// method to update the lists of neighbors depending on the current vertices
  void find_neighbors();
};

template <class T, class W> Staggered_LB<T, W>::~Staggered_LB() {
  int dimension = this->getDimension();
  for (int i = 1; i < dimension; ++i) {
    if (communicators.at(i) != MPI_COMM_NULL)
      MPI_Comm_free(&communicators.at(i));
  }
}

// setup routine for the tensor-based load-balancing scheme
// requires:
//              this->globalComm (int): cartesian MPI communicator, from
//                                 which separate sub communicators
//                                 are derived in order to represent
//                                 each plane of domains in the system
template <class T, class W> void Staggered_LB<T, W>::setup() {
  int status;
  int dimension = this->getDimension();

  // check if Communicator is cartesian
  MPI_Topo_test(this->globalComm, &status);
  if (status != MPI_CART) {
    throw InvalidCommTypeException(
        __FILE__, __func__, __LINE__,
        "Cartesian MPI communicator required, passed communicator is not "
        "cartesian");
  }

  // get the local coordinates, periodicity and global size from the MPI
  // communicator
  MPI_Cart_get(this->globalComm, dimension, this->global_dims.data(),
               this->periodicity.data(), this->local_coords.data());

  // get the local rank from the MPI communicator
  MPI_Cart_rank(this->globalComm, this->local_coords.data(), &this->localRank);

  // create sub-communicators

  if (communicators.at(1) != MPI_COMM_NULL)
    MPI_Comm_free(&communicators.at(1));
  if (communicators.at(2) != MPI_COMM_NULL)
    MPI_Comm_free(&communicators.at(2));

  // z-plane
  MPI_Comm_split(this->globalComm, this->local_coords.at(2),
                 this->local_coords.at(0) +
                     this->local_coords.at(1) * this->global_dims.at(0),
                 &communicators.at(2));

  // y-column
  MPI_Comm_split(this->globalComm,
                 this->local_coords.at(2) * this->global_dims.at(1) +
                     this->local_coords.at(1),
                 this->local_coords.at(0), &communicators.at(1));

  // only cell itself
  communicators.at(0) = MPI_COMM_SELF;

  // determine correct MPI data type for template T
  if (std::is_same<T, double>::value)
    MPIDataTypeT = MPI_DOUBLE;
  else if (std::is_same<T, float>::value)
    MPIDataTypeT = MPI_FLOAT;
  else if (std::is_same<T, int>::value)
    MPIDataTypeT = MPI_INT;
  else if (std::is_same<T, long>::value)
    MPIDataTypeT = MPI_LONG;
  else {
    throw InvalidCommTypeException(
        __FILE__, __func__, __LINE__,
        "Invalid data type for boundaries given (T)");
  }

  // determine correct MPI data type for template W
  if (std::is_same<W, double>::value)
    MPIDataTypeW = MPI_DOUBLE;
  else if (std::is_same<W, float>::value)
    MPIDataTypeW = MPI_FLOAT;
  else if (std::is_same<W, int>::value)
    MPIDataTypeW = MPI_INT;
  else if (std::is_same<W, long>::value)
    MPIDataTypeW = MPI_LONG;
  else {
    throw InvalidCommTypeException(__FILE__, __func__, __LINE__,
                                       "Invalid data type for work given (W)");
  }

  // calculate neighbors
  int rank_left, rank_right;

  neighbors.clear();
  for (int i = 0; i < dimension; ++i) {
    MPI_Cart_shift(this->globalComm, i, 1, &rank_left, &rank_right);
    neighbors.push_back(rank_left);
    neighbors.push_back(rank_right);
  }
}

template <class T, class W> void Staggered_LB<T, W>::balance(int) {
  int dimension = this->getDimension();

  // store original vertices
  this->prevVertices = this->vertices;

  // loop over all available dimensions
  for (int i = 0; i < dimension; ++i) {
    W work_local_plane;
#ifdef ALL_DEBUG_ENABLED
    MPI_Barrier(this->globalComm);
    if (this->localRank == 0)
      std::cout << "ALL::Staggered_LB::balance(): before work computation..."
                << std::endl;
#endif
    // collect work from all processes in the same plane
    MPI_Allreduce(this->work.data(), &work_local_plane, 1, MPIDataTypeW,
                  MPI_SUM, communicators[i]);

#ifdef ALL_DEBUG_ENABLED
    MPI_Barrier(this->globalComm);
    if (this->localRank == 0)
      std::cout << "ALL::Staggered_LB::balance(): before work distribution..."
                << std::endl;
#endif
    // correct right border:

    W remote_work;
    T local_size;
    T remote_size;
    // determine neighbors
    int rank_left, rank_right;

    MPI_Cart_shift(this->globalComm, i, 1, &rank_left, &rank_right);

    // collect work from right neighbor plane
    MPI_Request sreq, rreq;
    MPI_Status sstat, rstat;

    MPI_Irecv(&remote_work, 1, MPIDataTypeW, rank_right, 0, this->globalComm,
              &rreq);
    MPI_Isend(&work_local_plane, 1, MPIDataTypeW, rank_left, 0,
              this->globalComm, &sreq);
    MPI_Wait(&sreq, &sstat);
    MPI_Wait(&rreq, &rstat);

    // collect size in dimension from right neighbor plane

    local_size = this->prevVertices.at(1)[i] - this->prevVertices.at(0)[i];

    MPI_Irecv(&remote_size, 1, MPIDataTypeT, rank_right, 0, this->globalComm,
              &rreq);
    MPI_Isend(&local_size, 1, MPIDataTypeT, rank_left, 0, this->globalComm,
              &sreq);
    MPI_Wait(&sreq, &sstat);
    MPI_Wait(&rreq, &rstat);

    // automatic selection of gamma to guarantee stability of method (choice of
    // user gamma ignored)
    this->gamma =
        std::max(4.1, 2.0 * (1.0 + std::max(local_size, remote_size) /
                                       std::min(local_size, remote_size)));

#ifdef ALL_DEBUG_ENABLED
    MPI_Barrier(this->globalComm);
    if (this->localRank == 0)
      std::cout << "ALL::Staggered_LB::balance(): before shift calculation..."
                << std::endl;
#endif

    T shift = Functions::borderShift1d(
        rank_right, this->local_coords.at(i), this->global_dims.at(i),
        work_local_plane, remote_work, local_size, remote_size, this->gamma,
        this->minSize[i]);

#ifdef ALL_DEBUG_ENABLED
    MPI_Barrier(this->globalComm);
    if (this->localRank == 0)
      std::cout << "ALL::Staggered_LB::balance(): before shift distibution..."
                << std::endl;
#endif
    // send shift to right neighbors
    T remote_shift = (T)0;

    MPI_Irecv(&remote_shift, 1, MPIDataTypeT, rank_left, 0, this->globalComm,
              &rreq);
    MPI_Isend(&shift, 1, MPIDataTypeT, rank_right, 0, this->globalComm, &sreq);
    MPI_Wait(&sreq, &sstat);
    MPI_Wait(&rreq, &rstat);

#ifdef ALL_DEBUG_ENABLED
    MPI_Barrier(this->globalComm);
    std::cout << this->localRank << ": shift = " << shift
              << " remoteShift = " << remote_shift
              << " vertices: " << this->vertices.at(0)[i] << ", "
              << this->vertices.at(1)[i] << std::endl;
#endif

    // for now: test case for simple program

    // if a left neighbor exists: shift left border
    // if a left neighbor exists: shift left border
    if (rank_left != MPI_PROC_NULL && this->local_coords[i] != 0)
      this->vertices.at(0)[i] = this->prevVertices.at(0)[i] + remote_shift;
    else
      this->vertices.at(0)[i] = this->prevVertices.at(0)[i];

    // if a right neighbor exists: shift right border
    if (rank_right != MPI_PROC_NULL &&
        this->local_coords[i] != this->global_dims[i] - 1)
      this->vertices.at(1)[i] = this->prevVertices.at(1)[i] + shift;
    else
      this->vertices.at(1)[i] = this->prevVertices.at(1)[i];

    // check if vertices are crossed and throw exception if something went wrong
    if (this->vertices.at(1)[i] < this->vertices.at(0)[i]) {
      std::cout << "ERROR on process: " << this->localRank << std::endl;
      throw InternalErrorException(
          __FILE__, __func__, __LINE__,
          "Lower border of process larger than upper border of process!");
    }

#ifdef ALL_DEBUG_ENABLED
    MPI_Barrier(this->globalComm);
    if (this->localRank == 0)
      std::cout << "ALL::Staggered_LB::balance(): before neighbor search..."
                << std::endl;
#endif
    find_neighbors();
  }
}

template <class T, class W> void Staggered_LB<T, W>::find_neighbors() {
  auto work = this->getWork();
  auto vertices = this->prevVertices;
  auto shifted_vertices = this->vertices;

  neighbors.clear();
  // collect work from right neighbor plane
  MPI_Request sreq, rreq;
  MPI_Status sstat, rstat;
  // array to store neighbor vertices in Y/Z direction (reused)
  T *vertices_loc = new T[4];
  T *vertices_rem = new T[8 * this->global_dims[0] * this->global_dims[1]];

  int rem_rank;
  int rem_coords[3];

  // determine neighbors
  int rank_left, rank_right;

  // offset to get the correct rank
  int rank_offset;
  int offset_coords[3];

  // X-neighbors are static
  nNeighbors.at(0) = nNeighbors.at(1) = 1;

  // find X-neighbors
  MPI_Cart_shift(this->globalComm, 0, 1, &rank_left, &rank_right);

  // store X-neighbors
  neighbors.push_back(rank_left);
  neighbors.push_back(rank_right);

  // find Y-neighbors to get border information from
  MPI_Cart_shift(this->globalComm, 1, 1, &rank_left, &rank_right);

  // collect border information from local column
  vertices_loc[0] = shifted_vertices.at(0)[0];
  vertices_loc[1] = shifted_vertices.at(1)[0];
  MPI_Allgather(vertices_loc, 2, MPIDataTypeT,
                vertices_rem + 2 * this->global_dims[0], 2, MPIDataTypeT,
                communicators[1]);

  // exchange local column information with upper neighbor in Y direction (cart
  // grid)
  MPI_Irecv(vertices_rem, 2 * this->global_dims[0], MPIDataTypeT, rank_left, 0,
            this->globalComm, &rreq);
  MPI_Isend(vertices_rem + 2 * this->global_dims[0], 2 * this->global_dims[0],
            MPIDataTypeT, rank_right, 0, this->globalComm, &sreq);

  // determine the offset in ranks
  offset_coords[0] = 0;
  offset_coords[1] = this->local_coords[1] - 1;
  offset_coords[2] = this->local_coords[2];

  rem_coords[1] = offset_coords[1];
  rem_coords[2] = offset_coords[2];

  MPI_Cart_rank(this->globalComm, offset_coords, &rank_offset);

  // wait for communication
  MPI_Wait(&sreq, &sstat);
  MPI_Wait(&rreq, &rstat);

  // iterate about neighbor borders to determine the neighborship relation
  nNeighbors.at(2) = 0;
  for (int x = 0; x < this->global_dims[0]; ++x) {
    if ((vertices_rem[2 * x] <= vertices_loc[0] &&
         vertices_loc[0] < vertices_rem[2 * x + 1]) ||
        (vertices_rem[2 * x] < vertices_loc[1] &&
         vertices_loc[1] <= vertices_rem[2 * x + 1]) ||
        (vertices_rem[2 * x] >= vertices_loc[0] &&
         vertices_loc[0] < vertices_rem[2 * x + 1] &&
         vertices_loc[1] >= vertices_rem[2 * x + 1])) {
      nNeighbors.at(2)++;
      rem_coords[0] = x;
      MPI_Cart_rank(this->globalComm, rem_coords, &rem_rank);
      neighbors.push_back(rem_rank);
    }
  }

  // barrier to ensure every process concluded the calculations before
  // overwriting remote borders!
  MPI_Barrier(this->globalComm);

  // exchange local column information with lower neighbor in Y direction (cart
  // grid)
  MPI_Irecv(vertices_rem, 2 * this->global_dims[0], MPIDataTypeT, rank_right, 0,
            this->globalComm, &rreq);
  MPI_Isend(vertices_rem + 2 * this->global_dims[0], 2 * this->global_dims[0],
            MPIDataTypeT, rank_left, 0, this->globalComm, &sreq);

  // determine the offset in ranks
  offset_coords[0] = 0;
  offset_coords[1] = this->local_coords[1] + 1;
  offset_coords[2] = this->local_coords[2];

  rem_coords[1] = offset_coords[1];
  rem_coords[2] = offset_coords[2];

  MPI_Cart_rank(this->globalComm, offset_coords, &rank_offset);

  // wait for communication
  MPI_Wait(&sreq, &sstat);
  MPI_Wait(&rreq, &rstat);

  // iterate about neighbor borders to determine the neighborship relation
  nNeighbors.at(3) = 0;
  for (int x = 0; x < this->global_dims[0]; ++x) {
    if ((vertices_rem[2 * x] <= vertices_loc[0] &&
         vertices_loc[0] < vertices_rem[2 * x + 1]) ||
        (vertices_rem[2 * x] < vertices_loc[1] &&
         vertices_loc[1] <= vertices_rem[2 * x + 1]) ||
        (vertices_rem[2 * x] >= vertices_loc[0] &&
         vertices_loc[0] < vertices_rem[2 * x + 1] &&
         vertices_loc[1] >= vertices_rem[2 * x + 1])) {
      nNeighbors.at(3)++;
      rem_coords[0] = x;
      MPI_Cart_rank(this->globalComm, rem_coords, &rem_rank);
      neighbors.push_back(rem_rank);
    }
  }

  // barrier to ensure every process concluded the calculations before
  // overwriting remote borders!
  MPI_Barrier(this->globalComm);

  // find Z-neighbors to get border information from
  MPI_Cart_shift(this->globalComm, 2, 1, &rank_left, &rank_right);

  // collect border information from local column
  vertices_loc[0] = shifted_vertices.at(0)[0];
  vertices_loc[1] = shifted_vertices.at(1)[0];
  vertices_loc[2] = shifted_vertices.at(0)[1];
  vertices_loc[3] = shifted_vertices.at(1)[1];

  MPI_Barrier(this->globalComm);

  MPI_Allgather(vertices_loc, 4, MPIDataTypeT,
                vertices_rem + 4 * this->global_dims[0] * this->global_dims[1],
                4, MPIDataTypeT, communicators[2]);

  // exchange local column information with upper neighbor in Z direction (cart
  // grid)
  MPI_Irecv(vertices_rem, 4 * this->global_dims[0] * this->global_dims[1],
            MPIDataTypeT, rank_left, 0, this->globalComm, &rreq);
  MPI_Isend(vertices_rem + 4 * this->global_dims[0] * this->global_dims[1],
            4 * this->global_dims[0] * this->global_dims[1], MPIDataTypeT,
            rank_right, 0, this->globalComm, &sreq);

  // determine the offset in ranks
  offset_coords[0] = 0;
  offset_coords[1] = 0;
  offset_coords[2] = this->local_coords[2] - 1;

  rem_coords[2] = offset_coords[2];

  MPI_Cart_rank(this->globalComm, offset_coords, &rank_offset);

  // wait for communication
  MPI_Wait(&sreq, &sstat);
  MPI_Wait(&rreq, &rstat);

  // iterate about neighbor borders to determine the neighborship relation
  nNeighbors.at(4) = 0;
  for (int y = 0; y < this->global_dims[1]; ++y) {
    for (int x = 0; x < this->global_dims[0]; ++x) {
      if (((vertices_rem[4 * (x + y * this->global_dims[0]) + 2] <=
                vertices_loc[2] &&
            vertices_loc[2] <
                vertices_rem[4 * (x + y * this->global_dims[0]) + 3]) ||
           (vertices_rem[4 * (x + y * this->global_dims[0]) + 2] <
                vertices_loc[3] &&
            vertices_loc[3] <=
                vertices_rem[4 * (x + y * this->global_dims[0]) + 3]) ||
           (vertices_rem[4 * (x + y * this->global_dims[0]) + 2] >=
                vertices_loc[2] &&
            vertices_loc[2] <
                vertices_rem[4 * (x + y * this->global_dims[0]) + 3] &&
            vertices_loc[3] >=
                vertices_rem[4 * (x + y * this->global_dims[0]) + 3])))
        if (((vertices_rem[4 * (x + y * this->global_dims[0])] <=
                  vertices_loc[0] &&
              vertices_loc[0] <
                  vertices_rem[4 * (x + y * this->global_dims[0]) + 1]) ||
             (vertices_rem[4 * (x + y * this->global_dims[0])] <
                  vertices_loc[1] &&
              vertices_loc[1] <=
                  vertices_rem[4 * (x + y * this->global_dims[0]) + 1]) ||
             (vertices_rem[4 * (x + y * this->global_dims[0])] >=
                  vertices_loc[0] &&
              vertices_loc[0] <
                  vertices_rem[4 * (x + y * this->global_dims[0]) + 1] &&
              vertices_loc[1] >=
                  vertices_rem[4 * (x + y * this->global_dims[0]) + 1]))) {
          nNeighbors.at(4)++;
          rem_coords[1] = y;
          rem_coords[0] = x;
          MPI_Cart_rank(this->globalComm, rem_coords, &rem_rank);
          neighbors.push_back(rem_rank);
        }
    }
  }

  // barrier to ensure every process concluded the calculations before
  // overwriting remote borders!
  MPI_Barrier(this->globalComm);

  // exchange local column information with upper neighbor in Y direction (cart
  // grid)
  MPI_Irecv(vertices_rem, 4 * this->global_dims[0] * this->global_dims[1],
            MPIDataTypeT, rank_right, 0, this->globalComm, &rreq);
  MPI_Isend(vertices_rem + 4 * this->global_dims[0] * this->global_dims[1],
            4 * this->global_dims[0] * this->global_dims[1], MPIDataTypeT,
            rank_left, 0, this->globalComm, &sreq);

  // determine the offset in ranks
  offset_coords[0] = 0;
  offset_coords[1] = 0;
  offset_coords[2] = this->local_coords[2] + 1;

  rem_coords[2] = offset_coords[2];

  MPI_Cart_rank(this->globalComm, offset_coords, &rank_offset);

  // wait for communication
  MPI_Wait(&sreq, &sstat);
  MPI_Wait(&rreq, &rstat);

  // iterate about neighbor borders to determine the neighborship relation
  nNeighbors.at(5) = 0;
  for (int y = 0; y < this->global_dims[1]; ++y) {
    for (int x = 0; x < this->global_dims[0]; ++x) {
      if (((vertices_rem[4 * (x + y * this->global_dims[0]) + 2] <=
                vertices_loc[2] &&
            vertices_loc[2] <
                vertices_rem[4 * (x + y * this->global_dims[0]) + 3]) ||
           (vertices_rem[4 * (x + y * this->global_dims[0]) + 2] <
                vertices_loc[3] &&
            vertices_loc[3] <=
                vertices_rem[4 * (x + y * this->global_dims[0]) + 3]) ||
           (vertices_rem[4 * (x + y * this->global_dims[0]) + 2] >=
                vertices_loc[2] &&
            vertices_loc[2] <
                vertices_rem[4 * (x + y * this->global_dims[0]) + 3] &&
            vertices_loc[3] >=
                vertices_rem[4 * (x + y * this->global_dims[0]) + 3])))
        if (((vertices_rem[4 * (x + y * this->global_dims[0])] <=
                  vertices_loc[0] &&
              vertices_loc[0] <
                  vertices_rem[4 * (x + y * this->global_dims[0]) + 1]) ||
             (vertices_rem[4 * (x + y * this->global_dims[0])] <
                  vertices_loc[1] &&
              vertices_loc[1] <=
                  vertices_rem[4 * (x + y * this->global_dims[0]) + 1]) ||
             (vertices_rem[4 * (x + y * this->global_dims[0])] >=
                  vertices_loc[0] &&
              vertices_loc[0] <
                  vertices_rem[4 * (x + y * this->global_dims[0]) + 1] &&
              vertices_loc[1] >=
                  vertices_rem[4 * (x + y * this->global_dims[0]) + 1]))) {
          nNeighbors.at(5)++;
          rem_coords[1] = y;
          rem_coords[0] = x;
          MPI_Cart_rank(this->globalComm, rem_coords, &rem_rank);
          neighbors.push_back(rem_rank);
        }
    }
  }

  // barrier to ensure every process concluded the calculations before
  // overwriting remote borders!
  MPI_Barrier(this->globalComm);

  // clear up vertices array
  delete[] vertices_loc;
  delete[] vertices_rem;
}

// provide list of neighbors
template <class T, class W>
std::vector<int> &Staggered_LB<T, W>::getNeighbors() {
  return neighbors;
}

}//namespace ALL

#endif
// vim: sw=2 et ts=2

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_FORCEBASED_HEADER_INCLUDED
#define ALL_FORCEBASED_HEADER_INCLUDED

#define ALL_FORCE_OLD

/*

    ForceBased load-balancing scheme:

    Requirements:
        a) cartesian communicator
        b) 2^(dim) vertices describing the domain (in theory could be more,
           we assume a orthogonal grid as start point)
        c) MPI >= 3.0 due to necessary non-blocking collectives


    Method:

        For each of the vertices of a domain a communicator is created, which
   contains the surrounding processes. For one of the vertices, a domain
   collects the centres of gravitiy and the work of the neighboring domains. In
   a next step a force acting on the vertex is computed as: F = 1.0 / ( gamma *
   n * sum(W_i) ) * sum( W_i * x_i ) with:

                n:      number of neighboring domains
                W_i:    work on domain i
                x_i:    vector pointing from the vertex to
                        the center of gravity of domain i
                gamma:  correction factor to control the
                        speed of the vertex shift

        */

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_CUSTOM_EXCEPTIONS_INC
#define ALL_CUSTOM_EXCEPTIONS_INC

#include <exception>
#include <sstream>
#include <string>

namespace ALL {

/// Customized exceptions for ALL, modified for each specific exception type
struct CustomException : public std::exception {
protected:
  /// file the exception occured in
  const char *file;
  /// function the exception occured in
  const char *func;
  /// line the exception occured in
  int line;
  /// information on the exception
  const char *info;
  /// name of the exception
  const char *loc_desc;
  /// error message
  std::string error_msg;
  /// error identificators for Fortran error retrieval, remember to
  /// update the Fortran module as well!
  enum struct ErrorID : int {
	Generic = 1,
	PointDimensionMissmatch,
	InvalidCommType,
	InvalidArgument,
	OutOfBounds,
	InternalError,
	FilesystemError
  };
  /// error identificator retrieved by Fortran
  ErrorID error_id;

public:
  /// constructor for an exception used in ALL
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  CustomException(const char *file_ = "", const char *f_ = "", int l_ = -1,
                      const char *i_ = "",
                      const char *loc_desc_ = "ALLCustomException",
		      const ErrorID error_id_ = ErrorID::Generic)
      : file(file_), func(f_), line(l_), info(i_), loc_desc(loc_desc_), error_id(error_id_) {
    std::stringstream ss;
    ss << loc_desc << ": " << info << "\n"
       << "Function: " << func << "\n"
       << "File: " << file << "\n"
       << "Line: " << line << "\n";
    error_msg = ss.str();
  }
  /// method to get the function name from where the exception was thrown
  /// @return the function name
  const char *get_func() const { return func; }

  /// method to get the line from where the exception was thrown
  /// @return the line
  int get_line() const { return line; }

  /// method to get the additional information about the error leading to the
  /// exception
  /// @return the information given about the error
  const char *get_info() { return info; }

  /// overloaded method from the base Exception class to return an error message
  /// @return the error message of the exception
  virtual const char *what() const throw() { return error_msg.c_str(); }

  /// retrieve error id for Fortran interface
  /// @return error id from ErrorID enum
  int get_error_id() { return static_cast<int>(error_id); }
};

/// Exception to be used for missmatches in dimension for ALL::Point class
struct PointDimensionMissmatchException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  PointDimensionMissmatchException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Dimension missmatch in Point objects.",
      const char *loc_desc_ = "ALLPointDimMissmatchException",
      const ErrorID error_id_ = ErrorID::PointDimensionMissmatch)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid Communicators in a load-balancing method
struct InvalidCommTypeException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidCommTypeException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Type of MPI communicator not valid.",
      const char *loc_desc_ = "ALLCommTypeInvalidException",
      const ErrorID error_id_ = ErrorID::InvalidCommType)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid parameters in any type of classes
struct InvalidArgumentException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidArgumentException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Invalid argument given.",
      const char *loc_desc_ = "ALLInvalidArgumentException",
      const ErrorID error_id_ = ErrorID::InvalidArgument)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an array went out of bounds
struct OutOfBoundsException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  OutOfBoundsException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Access to array out of bounds.",
      const char *loc_desc_ = "ALLOutOfBoundsErrorException",
      const ErrorID error_id_ = ErrorID::OutOfBounds)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an internal error has occured
struct InternalErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InternalErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Internal error occured, see description.",
      const char *loc_desc_ = "ALLInternalErrorException",
      const ErrorID error_id_ = ErrorID::InternalError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if a filesystem error has occured
struct FilesystemErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  FilesystemErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Filesystem error occured, see description.",
      const char *loc_desc_ = "ALLFilesystemErrorException",
      const ErrorID error_id_ = ErrorID::FilesystemError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

}//namespace ALL

#endif

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_LB_HEADER_INCLUDED
#define ALL_LB_HEADER_INCLUDED

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_POINT_HEADER_INC
#define ALL_POINT_HEADER_INC

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_CUSTOM_EXCEPTIONS_INC
#define ALL_CUSTOM_EXCEPTIONS_INC

#include <exception>
#include <sstream>
#include <string>

namespace ALL {

/// Customized exceptions for ALL, modified for each specific exception type
struct CustomException : public std::exception {
protected:
  /// file the exception occured in
  const char *file;
  /// function the exception occured in
  const char *func;
  /// line the exception occured in
  int line;
  /// information on the exception
  const char *info;
  /// name of the exception
  const char *loc_desc;
  /// error message
  std::string error_msg;
  /// error identificators for Fortran error retrieval, remember to
  /// update the Fortran module as well!
  enum struct ErrorID : int {
	Generic = 1,
	PointDimensionMissmatch,
	InvalidCommType,
	InvalidArgument,
	OutOfBounds,
	InternalError,
	FilesystemError
  };
  /// error identificator retrieved by Fortran
  ErrorID error_id;

public:
  /// constructor for an exception used in ALL
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  CustomException(const char *file_ = "", const char *f_ = "", int l_ = -1,
                      const char *i_ = "",
                      const char *loc_desc_ = "ALLCustomException",
		      const ErrorID error_id_ = ErrorID::Generic)
      : file(file_), func(f_), line(l_), info(i_), loc_desc(loc_desc_), error_id(error_id_) {
    std::stringstream ss;
    ss << loc_desc << ": " << info << "\n"
       << "Function: " << func << "\n"
       << "File: " << file << "\n"
       << "Line: " << line << "\n";
    error_msg = ss.str();
  }
  /// method to get the function name from where the exception was thrown
  /// @return the function name
  const char *get_func() const { return func; }

  /// method to get the line from where the exception was thrown
  /// @return the line
  int get_line() const { return line; }

  /// method to get the additional information about the error leading to the
  /// exception
  /// @return the information given about the error
  const char *get_info() { return info; }

  /// overloaded method from the base Exception class to return an error message
  /// @return the error message of the exception
  virtual const char *what() const throw() { return error_msg.c_str(); }

  /// retrieve error id for Fortran interface
  /// @return error id from ErrorID enum
  int get_error_id() { return static_cast<int>(error_id); }
};

/// Exception to be used for missmatches in dimension for ALL::Point class
struct PointDimensionMissmatchException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  PointDimensionMissmatchException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Dimension missmatch in Point objects.",
      const char *loc_desc_ = "ALLPointDimMissmatchException",
      const ErrorID error_id_ = ErrorID::PointDimensionMissmatch)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid Communicators in a load-balancing method
struct InvalidCommTypeException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidCommTypeException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Type of MPI communicator not valid.",
      const char *loc_desc_ = "ALLCommTypeInvalidException",
      const ErrorID error_id_ = ErrorID::InvalidCommType)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid parameters in any type of classes
struct InvalidArgumentException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidArgumentException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Invalid argument given.",
      const char *loc_desc_ = "ALLInvalidArgumentException",
      const ErrorID error_id_ = ErrorID::InvalidArgument)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an array went out of bounds
struct OutOfBoundsException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  OutOfBoundsException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Access to array out of bounds.",
      const char *loc_desc_ = "ALLOutOfBoundsErrorException",
      const ErrorID error_id_ = ErrorID::OutOfBounds)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an internal error has occured
struct InternalErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InternalErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Internal error occured, see description.",
      const char *loc_desc_ = "ALLInternalErrorException",
      const ErrorID error_id_ = ErrorID::InternalError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if a filesystem error has occured
struct FilesystemErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  FilesystemErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Filesystem error occured, see description.",
      const char *loc_desc_ = "ALLFilesystemErrorException",
      const ErrorID error_id_ = ErrorID::FilesystemError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

}//namespace ALL

#endif

#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace ALL {

template <class T> class Point;
template <typename T>
std::ostream &operator<<(std::ostream &, const Point<T> &);

/// @tparam T floating point type used, has to be identical to the type used for
/// the vertices and borders
template <class T> class Point {
public:
  /// default constructor
  Point() : dimension(0) {}
  /// constructor
  /// @param d dimension of the point object
  Point(const int d) : dimension(d) {
    coordinates.resize(d);
    weight = (T)1;
  }
  /// constructor with initialization
  /// @param d dimension of the point object
  /// @param data positions
  Point(const int d, const T *data) : Point<T>(d) {
    // copy each element of the array into the vector (insecure, no boundary
    // checks for data!)
    for (auto i = 0; i < d; ++i)
      coordinates.at(i) = data[i];
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  Point(const std::vector<T> &data) {
    // initialize the coordinates vector with the data vector
    coordinates.insert(coordinates.begin(), data.begin(), data.end());
    // update the dimension with the size of the data vector
    dimension = data.size();
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  Point(const int d, const T *data, const T w) : Point<T>(d, data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  /// @param i index of the point
  Point(const int d, const T *data, const T w, const long i)
      : Point<T>(d, data, w) {
    id = i;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  Point(const std::vector<T> &data, const T w) : Point<T>(data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  /// @param i index of the point
  Point(const std::vector<T> &data, const T w, const long i)
      : Point<T>(data, w) {
    id = i;
  }

  /// destructor
  ~Point<T>(){};

  // TODO: return values to check if operation was successful?
  /// method to change the dimension of the point object
  /// @param d new dimension
  void setDimension(const int d) {
    dimension = d;
    coordinates.resize(d);
  }

  /// method to change the weight of the point object
  /// @param w new weight
  void set_weight(const T w) { weight = w; }

  /// method to change the index of the particle
  /// @param i new index
  void set_id(const long i) { id = i; }

  /// access operator to access an element of the point object
  /// @param idx the index of the element to be accessed
  /// @result reference to the indexed element
  T &operator[](const std::size_t idx) { return coordinates.at(idx); }

  /// access operator to access an element of the constant point object
  /// @param idx the index of the element to be accessed
  /// @result const reference to the indexed element
  const T &operator[](const std::size_t idx) const {
    return coordinates.at(idx);
  }

  /// method to get the weight of the point object
  /// @return the weight of the point object
  T getWeight() const { return weight; }

  /// method to get the index of the point object
  /// @return the index of the point object
  long get_id() const { return id; }

  /// method to get the dimension of the point object
  /// @return the dimension of the point object
  int getDimension() const { return dimension; }

  /// method to compute the norm of the vector described by the
  /// point object
  /// @param nd type of the norm (default: 2, i.e. the Euclidean norm)
  /// @return norm of the vector
  T norm(T nd = 2) {
    T res = 0;
    for (int d = 0; d < dimension; ++d)
      res += std::pow(coordinates.at(d), nd);
    return std::pow(res, 1.0 / nd);
  }

  /// method to compute the Euclidean distance (two-norm) between the local and
  /// the provided point object
  /// @param p the point object for which the distence to the local point object
  /// is computed
  /// @return the distance between the two points
  T d(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p).norm();
  }

  /// method to compute the Manhatten / city-block distance (one-norm) between
  /// the local and the provided point object
  /// @param p the point object for which the distance to the local point object
  /// is computed
  /// @return the distance between the two points
  T d_1(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p, 1).norm();
  }

  /// method to compute the distance vector between the local point object and
  /// the provided point object
  /// @param p the point object for which the distance vector to the local point
  /// object is computed
  /// @return the distance vector between the two points
  Point<T> dist(Point<T> &p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    std::vector<T> d_v;
    for (int d = 0; d < dimension; ++d)
      d_v.push_back(p[d] - coordinates.at(d));

    return Point<T>(d_v);
  }

  /// method to compute the distance of the local point object from a plane
  /// spanned by provided points
  /// @param A anchor point for the plane
  /// @param B anchor point for the plane
  /// @param C anchor point for the plane
  /// @return distance between local point object and plane
  T dist_plane(const Point<T> &A, const Point<T> &B,
               const Point<T> &C) {

    if (A.getDimension() != dimension || B.getDimension() != dimension ||
        C.getDimension() != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);

    // vectors spanning the plane from vertex 'a'
    T vb[3];
    T vc[3];

    for (int i = 0; i < 3; ++i) {
      vb[i] = B[i] - A[i];
      vc[i] = C[i] - A[i];
    }

    // normal vector of plane
    T n[3];

    n[0] = vb[1] * vc[2] - vb[2] * vc[1];
    n[1] = vb[2] * vc[0] - vb[0] * vc[2];
    n[2] = vb[0] * vc[1] - vb[1] * vc[0];

    // length of normal vector
    T dn = n.norm();

    // distance from origin
    T d = n * A;

    // compute distance of test vertex to plane
    return std::abs((n[0] * coordinates.at(0) + n[1] * coordinates.at(1) +
                     n[2] * coordinates.at(2) - d) /
                    dn);
  }

  /// operator for the addition of two point objects
  /// @param rhs point to add the local point object to
  /// @return sum of local point object and provided point object
  Point<T> operator+(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) + rhs[d];
    }
    return result;
  }

  /// operator for the addition of two point objects
  /// @param rhs point to subtract from the local point object
  /// @return difference vector between local point object and provided point
  /// object
  Point<T> operator-(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) - rhs[d];
    }
    return result;
  }

  /// operator to compute the dot product between two point objects
  /// @param rhs point object to compute the dot product with
  /// @return dot product between the two point objects
  T operator*(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    T result = (T)0.0;
    for (int d = 0; d < dimension; ++d) {
      result += coordinates.at(d) * rhs[d];
    }
    return result;
  }

  /// operator to scale the local point object by a provided factor
  /// @param rhs scaling factor
  /// @return scaled point object
  Point<T> operator*(const T &rhs) const {
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) * rhs;
    }
    return result;
  }

  /// operator to compute the cross product between two point objects
  /// @param rhs point object to compute the cross product with
  /// @return cross product between the two point objects
  /// @attention only works for 3D points / vectors
  Point<T> cross(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension && dimension != 3) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at((d + 1) % 3) * rhs[(d + 2) % 3] -
                  coordinates.at((d + 2) % 3) * rhs[(d + 1) % 3];
    }
    return result;
  }

  /// method to determine if the local point object has the same orientation to
  /// a plane spanned by point objects A,B,C as the provided point P
  /// @param A anchor point A
  /// @param B anchor point B
  /// @param C anchor point C
  /// @param P reference point P
  /// @return the local point object has the same orientation to the plane as
  /// @attention if the reference point is located within the plane, it will not
  /// have the same orientation as the local point! the reference point
  bool same_side_plane(const Point<T> &A, const Point<T> &B,
                       const Point<T> &C, const Point<T> &P) {
    // compute difference vectors:
    Point<T> BA = B - A;
    Point<T> CA = C - A;
    Point<T> PA = P - A;
    Point<T> tA = *(this) - A;

    // compute normal vector of plane
    Point<T> n = CA.cross(BA);

    // compute scalar product of distance
    // vectors with normal vector
    T PAn = PA * n;
    T tAn = tA * n;

    return ((PAn * tAn) > 0);
  }

  /// method to check if the local point object is inside a tetrahedron
  /// described by the vertices A,B,C and D
  /// @param A vertex A
  /// @param B vertex B
  /// @param C vertex C
  /// @param D vertex D
  /// @return the point is within the tetrahedron
  /// @attention a point that is on the surface of the tetrahedron is not inside
  /// it
  bool inTetrahedron(const Point<T> &A, const Point<T> &B,
                     const Point<T> &C, const Point<T> &D) {
    /// for all surfaces of the tetrahedron check if the local point has the
    /// same orientation as the remaining vertex of the tetrahedron, to be
    /// inside the tetrahedron that must be fulfilled
    return (same_side_plane(A, B, C, D) && same_side_plane(B, C, D, A) &&
            same_side_plane(C, D, A, B) && same_side_plane(A, D, B, C));
  };

private:
  /// dimension of the point object
  int dimension;
  /// index for the point
  long id;
  // array containg the coordinates
  std::vector<T> coordinates;
  /// weight of the point to be used if points are not to be equally considered
  /// in computations, e.g. if number of interactions are considered
  T weight;
};

/// output operator for a point object
/// @param os output stream the point object should be printed to
/// @param p the point object to be printed
/// @return the modified output stream
template <class T>
std::ostream &operator<<(std::ostream &os, const Point<T> &p) {
  for (int i = 0; i < p.getDimension(); ++i)
    os << p[i] << " ";
  os << p.getWeight();
  return os;
}

/// operator to scale a point by a factor (reversed way of notation T *
/// Point<T>)
/// @param lhs scaling factor
/// @param rhs the point object to be scaled
/// @param scaled point object
template <class T>
Point<T> operator*(const T &lhs, const Point<T> &rhs) {
  return rhs * lhs;
}

// template <class T>
// Point<T> operator/(const T &lhs, const Point<T> &rhs) {
//   return rhs * ((T)1 / lhs);
// }

}//namespace ALL

#endif

#include <mpi.h>
#include <vector>

namespace ALL {

/// @tparam T data for vertices and related data
/// @tparam W data for work and related data
template <class T, class W> class LB {
public:
  /// constructor for the basic load-balancing class, sets up parameters
  /// required by all balancing methods
  /// @param[in] dim dimension of the vertices used
  /// @param[in] g correction factor for the computation of shifts
  LB(const int dim, const T g) : gamma(g), dimension(dim) {
    // set allowed minimum size to zero
    minSize = std::vector<T>(dim, 0.0);
    periodicity.resize(dim);
    local_coords.resize(dim);
    global_dims.resize(dim);
    neighborVertices.resize(0);
  }

  /// destructor
  virtual ~LB() = default;

  /// abstract definition of the setup method
  virtual void setup() = 0;

  /// abstract definition of the balancing method
  virtual void balance(const int step) = 0;

  /// abstract definition of the method to get the neighbors of the local domain
  /// @result std::vector<int> to store the MPI ranks of the neighbors
  /// to
  virtual std::vector<int> &getNeighbors() = 0;

  /// method to update the vertices used for the balancing step, overwrites old
  /// set of vertices
  /// @param[in] vertices_in vector containg the new vertices to be used
  virtual void setVertices(const std::vector<Point<T>> &vertices_in) {
    // as a basic assumption the number of resulting vertices
    // is equal to the number of input vertices:
    // exceptions:
    //      VORONOI
    vertices = vertices_in;
    prevVertices = vertices_in;
  }

  /// method to set the dimension of the vertices
  /// @param[in] d the dimension to be used
  /// @attention most methods currently support 3D vertices only
  virtual void setDimension(const int d) { dimension = d; }

  /// method to get the dimension of the vertices
  /// @return the dimension of the vertices
  virtual int getDimension() { return dimension; }

  /// method to set the correction value gamma
  /// @param[in] g the correction value to use
  virtual void setGamma(const T g) { gamma = g; }

  /// method to get the correction value currently used
  /// @return the current correction value
  virtual const T getGamma() { return gamma; }

  /// method to set a multi-dimensional work for the local domain
  /// @param[in] w vector containing all the dimensions of the work to be used
  /// for the local domain
  virtual void setWork(const std::vector<W> &w) { work = w; }

  /// method to set a scalar work for the local domain
  /// @param[in] w value containing the work to be used for the local domain
  virtual void setWork(const W w) {
    work.resize(1);
    work.at(0) = w;
  }

  /// method to set the minimum domain size in each dimension
  /// @param[in] minSize the minimum size of a domain in all dimensions
  virtual void setMinDomainSize(const std::vector<T> &minSize) {
    this->minSize = minSize;
  }

  /// method to get the minimum domain size the balancing methods have to obey
  /// @return the minimum domain size allowed
  virtual const std::vector<T> &getMinDomainSize() { return minSize; }

  /// method to set the (orthogonal) size of the system
  /// @param[in] sysSize system size in all dimensions
  virtual void setSysSize(const std::vector<T> &newSysSize) {
    sysSize = newSysSize;
  }

  /// method to get the currently stored system size
  /// @return the currently stored system size
  virtual const std::vector<T> &getSysSize() { return sysSize; }

  /// method to get the currently stored work for the local process
  /// @return the currently stored work
  /// @attention always returns a std::vector, for scalar work, it has length 1
  virtual std::vector<W> &getWork() { return work; }

  /// method to get result vertices
  /// @return the resulting vertices after a balancing step
  virtual std::vector<Point<T>> &getVertices() { return vertices; }

  /// method to get the original vertices before the last balancing step
  /// @return the original unmodified vertices before the last balancing step
  /// @attention since the original and resulting vertices are set up in the
  /// balancing method, the result is undefined before calling the balancing
  /// method at least once
  virtual std::vector<Point<T>> &getPrevVertices() { return prevVertices; };

  /// method to set the MPI communicator to be used by the balancing method
  /// @param[in] comm the MPI communicator to be used
  virtual void setCommunicator(const MPI_Comm comm) {
    // store communicator
    globalComm = comm;
    // get local rank within communicator
    MPI_Comm_rank(comm, &localRank);
  }

  /// method the get the number of vertices stored for the local domain
  /// @return number of local vertices
  int getNVertices() { return vertices.size(); }

  /// method to set undefined method specific data, which is not shared between
  /// different methods but needs to be set by a unified interface
  /// @param[in] data the data be passed to the balancing method
  virtual void setAdditionalData(const void *data) = 0;

  /// method to provide a list of vertices describing the neighboring domains
  /// currently only implemented for VORONOI, as a means to get the anchor points
  /// of the surrounding domains
  std::vector<T> &getNeighborVertices() {
    return neighborVertices; }

protected:
  /// correction factor
  T gamma;
  /// dimension of the used vertices
  int dimension;
  /// used MPI communicator
  MPI_Comm globalComm;
  /// local rank in the used MPI communicator
  int localRank;
  /// minimum domain size
  /// @attention not all balancing method support this
  std::vector<T> minSize;
  /// (orthogonal) system size
  std::vector<T> sysSize;
  /// local work
  std::vector<W> work;
  /// local vertices after previous balancing step
  std::vector<Point<T>> vertices;
  /// original vertices before previous balancing step
  std::vector<Point<T>> prevVertices;
  /// dimensions of the global process grid
  std::vector<int> global_dims;
  /// cartesian coordinates of the local domain in the process grid
  std::vector<int> local_coords;
  /// periodicity of the MPI communicator / system
  std::vector<int> periodicity;
  /// vertices describing neighboring domains
  std::vector<T> neighborVertices;
  /// method the resize the vertex list
  /// @param [in] new_size the new size of the vertex list
  void resizeVertices(const int newSize) { vertices.resize(newSize); }

};

}//namespace ALL

#endif // ALL_LB_HEADER_INCLUDED

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_POINT_HEADER_INC
#define ALL_POINT_HEADER_INC

/*
Copyright 2018-2020 Rene Halver, Forschungszentrum Juelich GmbH, Germany
Copyright 2018-2020 Godehard Sutmann, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_CUSTOM_EXCEPTIONS_INC
#define ALL_CUSTOM_EXCEPTIONS_INC

#include <exception>
#include <sstream>
#include <string>

namespace ALL {

/// Customized exceptions for ALL, modified for each specific exception type
struct CustomException : public std::exception {
protected:
  /// file the exception occured in
  const char *file;
  /// function the exception occured in
  const char *func;
  /// line the exception occured in
  int line;
  /// information on the exception
  const char *info;
  /// name of the exception
  const char *loc_desc;
  /// error message
  std::string error_msg;
  /// error identificators for Fortran error retrieval, remember to
  /// update the Fortran module as well!
  enum struct ErrorID : int {
	Generic = 1,
	PointDimensionMissmatch,
	InvalidCommType,
	InvalidArgument,
	OutOfBounds,
	InternalError,
	FilesystemError
  };
  /// error identificator retrieved by Fortran
  ErrorID error_id;

public:
  /// constructor for an exception used in ALL
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  CustomException(const char *file_ = "", const char *f_ = "", int l_ = -1,
                      const char *i_ = "",
                      const char *loc_desc_ = "ALLCustomException",
		      const ErrorID error_id_ = ErrorID::Generic)
      : file(file_), func(f_), line(l_), info(i_), loc_desc(loc_desc_), error_id(error_id_) {
    std::stringstream ss;
    ss << loc_desc << ": " << info << "\n"
       << "Function: " << func << "\n"
       << "File: " << file << "\n"
       << "Line: " << line << "\n";
    error_msg = ss.str();
  }
  /// method to get the function name from where the exception was thrown
  /// @return the function name
  const char *get_func() const { return func; }

  /// method to get the line from where the exception was thrown
  /// @return the line
  int get_line() const { return line; }

  /// method to get the additional information about the error leading to the
  /// exception
  /// @return the information given about the error
  const char *get_info() { return info; }

  /// overloaded method from the base Exception class to return an error message
  /// @return the error message of the exception
  virtual const char *what() const throw() { return error_msg.c_str(); }

  /// retrieve error id for Fortran interface
  /// @return error id from ErrorID enum
  int get_error_id() { return static_cast<int>(error_id); }
};

/// Exception to be used for missmatches in dimension for ALL::Point class
struct PointDimensionMissmatchException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  PointDimensionMissmatchException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Dimension missmatch in Point objects.",
      const char *loc_desc_ = "ALLPointDimMissmatchException",
      const ErrorID error_id_ = ErrorID::PointDimensionMissmatch)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid Communicators in a load-balancing method
struct InvalidCommTypeException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidCommTypeException(
      const char *file_, const char *f_, int l_,
      const char *i_ = "Type of MPI communicator not valid.",
      const char *loc_desc_ = "ALLCommTypeInvalidException",
      const ErrorID error_id_ = ErrorID::InvalidCommType)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used for invalid parameters in any type of classes
struct InvalidArgumentException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InvalidArgumentException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Invalid argument given.",
      const char *loc_desc_ = "ALLInvalidArgumentException",
      const ErrorID error_id_ = ErrorID::InvalidArgument)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an array went out of bounds
struct OutOfBoundsException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  OutOfBoundsException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Access to array out of bounds.",
      const char *loc_desc_ = "ALLOutOfBoundsErrorException",
      const ErrorID error_id_ = ErrorID::OutOfBounds)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if an internal error has occured
struct InternalErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  InternalErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Internal error occured, see description.",
      const char *loc_desc_ = "ALLInternalErrorException",
      const ErrorID error_id_ = ErrorID::InternalError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

// Execption to be used if a filesystem error has occured
struct FilesystemErrorException : public CustomException {
public:
  /// constructor
  /// @param file the source file from where the exception is thrown
  /// @param f_ the function from where the exception is thrown
  /// @param l_ the line from where the exception is thrown
  /// @param i_ additional information about the error
  /// @param loc_desc internal description of the exception type
  FilesystemErrorException(
      const char *file_, const char *f_ = "", int l_ = -1,
      const char *i_ = "Filesystem error occured, see description.",
      const char *loc_desc_ = "ALLFilesystemErrorException",
      const ErrorID error_id_ = ErrorID::FilesystemError)
      : CustomException(file_, f_, l_, i_, loc_desc_, error_id_) {}
};

}//namespace ALL

#endif

#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace ALL {

template <class T> class Point;
template <typename T>
std::ostream &operator<<(std::ostream &, const Point<T> &);

/// @tparam T floating point type used, has to be identical to the type used for
/// the vertices and borders
template <class T> class Point {
public:
  /// default constructor
  Point() : dimension(0) {}
  /// constructor
  /// @param d dimension of the point object
  Point(const int d) : dimension(d) {
    coordinates.resize(d);
    weight = (T)1;
  }
  /// constructor with initialization
  /// @param d dimension of the point object
  /// @param data positions
  Point(const int d, const T *data) : Point<T>(d) {
    // copy each element of the array into the vector (insecure, no boundary
    // checks for data!)
    for (auto i = 0; i < d; ++i)
      coordinates.at(i) = data[i];
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  Point(const std::vector<T> &data) {
    // initialize the coordinates vector with the data vector
    coordinates.insert(coordinates.begin(), data.begin(), data.end());
    // update the dimension with the size of the data vector
    dimension = data.size();
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  Point(const int d, const T *data, const T w) : Point<T>(d, data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param d dimension of the point
  /// @param data positions
  /// @param w weight of the point
  /// @param i index of the point
  Point(const int d, const T *data, const T w, const long i)
      : Point<T>(d, data, w) {
    id = i;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  Point(const std::vector<T> &data, const T w) : Point<T>(data) {
    weight = w;
  }

  /// constructor with initialization
  /// @param data positions, dimension is the size of the
  /// vector
  /// @param w weight of the point
  /// @param i index of the point
  Point(const std::vector<T> &data, const T w, const long i)
      : Point<T>(data, w) {
    id = i;
  }

  /// destructor
  ~Point<T>(){};

  // TODO: return values to check if operation was successful?
  /// method to change the dimension of the point object
  /// @param d new dimension
  void setDimension(const int d) {
    dimension = d;
    coordinates.resize(d);
  }

  /// method to change the weight of the point object
  /// @param w new weight
  void set_weight(const T w) { weight = w; }

  /// method to change the index of the particle
  /// @param i new index
  void set_id(const long i) { id = i; }

  /// access operator to access an element of the point object
  /// @param idx the index of the element to be accessed
  /// @result reference to the indexed element
  T &operator[](const std::size_t idx) { return coordinates.at(idx); }

  /// access operator to access an element of the constant point object
  /// @param idx the index of the element to be accessed
  /// @result const reference to the indexed element
  const T &operator[](const std::size_t idx) const {
    return coordinates.at(idx);
  }

  /// method to get the weight of the point object
  /// @return the weight of the point object
  T getWeight() const { return weight; }

  /// method to get the index of the point object
  /// @return the index of the point object
  long get_id() const { return id; }

  /// method to get the dimension of the point object
  /// @return the dimension of the point object
  int getDimension() const { return dimension; }

  /// method to compute the norm of the vector described by the
  /// point object
  /// @param nd type of the norm (default: 2, i.e. the Euclidean norm)
  /// @return norm of the vector
  T norm(T nd = 2) {
    T res = 0;
    for (int d = 0; d < dimension; ++d)
      res += std::pow(coordinates.at(d), nd);
    return std::pow(res, 1.0 / nd);
  }

  /// method to compute the Euclidean distance (two-norm) between the local and
  /// the provided point object
  /// @param p the point object for which the distence to the local point object
  /// is computed
  /// @return the distance between the two points
  T d(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p).norm();
  }

  /// method to compute the Manhatten / city-block distance (one-norm) between
  /// the local and the provided point object
  /// @param p the point object for which the distance to the local point object
  /// is computed
  /// @return the distance between the two points
  T d_1(Point<T> p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    return dist(p, 1).norm();
  }

  /// method to compute the distance vector between the local point object and
  /// the provided point object
  /// @param p the point object for which the distance vector to the local point
  /// object is computed
  /// @return the distance vector between the two points
  Point<T> dist(Point<T> &p) {
    int d_p = p.getDimension();
    if (d_p != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    std::vector<T> d_v;
    for (int d = 0; d < dimension; ++d)
      d_v.push_back(p[d] - coordinates.at(d));

    return Point<T>(d_v);
  }

  /// method to compute the distance of the local point object from a plane
  /// spanned by provided points
  /// @param A anchor point for the plane
  /// @param B anchor point for the plane
  /// @param C anchor point for the plane
  /// @return distance between local point object and plane
  T dist_plane(const Point<T> &A, const Point<T> &B,
               const Point<T> &C) {

    if (A.getDimension() != dimension || B.getDimension() != dimension ||
        C.getDimension() != dimension)
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);

    // vectors spanning the plane from vertex 'a'
    T vb[3];
    T vc[3];

    for (int i = 0; i < 3; ++i) {
      vb[i] = B[i] - A[i];
      vc[i] = C[i] - A[i];
    }

    // normal vector of plane
    T n[3];

    n[0] = vb[1] * vc[2] - vb[2] * vc[1];
    n[1] = vb[2] * vc[0] - vb[0] * vc[2];
    n[2] = vb[0] * vc[1] - vb[1] * vc[0];

    // length of normal vector
    T dn = n.norm();

    // distance from origin
    T d = n * A;

    // compute distance of test vertex to plane
    return std::abs((n[0] * coordinates.at(0) + n[1] * coordinates.at(1) +
                     n[2] * coordinates.at(2) - d) /
                    dn);
  }

  /// operator for the addition of two point objects
  /// @param rhs point to add the local point object to
  /// @return sum of local point object and provided point object
  Point<T> operator+(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) + rhs[d];
    }
    return result;
  }

  /// operator for the addition of two point objects
  /// @param rhs point to subtract from the local point object
  /// @return difference vector between local point object and provided point
  /// object
  Point<T> operator-(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) - rhs[d];
    }
    return result;
  }

  /// operator to compute the dot product between two point objects
  /// @param rhs point object to compute the dot product with
  /// @return dot product between the two point objects
  T operator*(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    T result = (T)0.0;
    for (int d = 0; d < dimension; ++d) {
      result += coordinates.at(d) * rhs[d];
    }
    return result;
  }

  /// operator to scale the local point object by a provided factor
  /// @param rhs scaling factor
  /// @return scaled point object
  Point<T> operator*(const T &rhs) const {
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at(d) * rhs;
    }
    return result;
  }

  /// operator to compute the cross product between two point objects
  /// @param rhs point object to compute the cross product with
  /// @return cross product between the two point objects
  /// @attention only works for 3D points / vectors
  Point<T> cross(const Point<T> &rhs) const {
    if (rhs.getDimension() != dimension && dimension != 3) {
      throw PointDimensionMissmatchException(__FILE__, __func__, __LINE__);
    }
    Point<T> result(dimension);
    for (int d = 0; d < dimension; ++d) {
      result[d] = coordinates.at((d + 1) % 3) * rhs[(d + 2) % 3] -
                  coordinates.at((d + 2) % 3) * rhs[(d + 1) % 3];
    }
    return result;
  }

  /// method to determine if the local point object has the same orientation to
  /// a plane spanned by point objects A,B,C as the provided point P
  /// @param A anchor point A
  /// @param B anchor point B
  /// @param C anchor point C
  /// @param P reference point P
  /// @return the local point object has the same orientation to the plane as
  /// @attention if the reference point is located within the plane, it will not
  /// have the same orientation as the local point! the reference point
  bool same_side_plane(const Point<T> &A, const Point<T> &B,
                       const Point<T> &C, const Point<T> &P) {
    // compute difference vectors:
    Point<T> BA = B - A;
    Point<T> CA = C - A;
    Point<T> PA = P - A;
    Point<T> tA = *(this) - A;

    // compute normal vector of plane
    Point<T> n = CA.cross(BA);

    // compute scalar product of distance
    // vectors with normal vector
    T PAn = PA * n;
    T tAn = tA * n;

    return ((PAn * tAn) > 0);
  }

  /// method to check if the local point object is inside a tetrahedron
  /// described by the vertices A,B,C and D
  /// @param A vertex A
  /// @param B vertex B
  /// @param C vertex C
  /// @param D vertex D
  /// @return the point is within the tetrahedron
  /// @attention a point that is on the surface of the tetrahedron is not inside
  /// it
  bool inTetrahedron(const Point<T> &A, const Point<T> &B,
                     const Point<T> &C, const Point<T> &D) {
    /// for all surfaces of the tetrahedron check if the local point has the
    /// same orientation as the remaining vertex of the tetrahedron, to be
    /// inside the tetrahedron that must be fulfilled
    return (same_side_plane(A, B, C, D) && same_side_plane(B, C, D, A) &&
            same_side_plane(C, D, A, B) && same_side_plane(A, D, B, C));
  };

private:
  /// dimension of the point object
  int dimension;
  /// index for the point
  long id;
  // array containg the coordinates
  std::vector<T> coordinates;
  /// weight of the point to be used if points are not to be equally considered
  /// in computations, e.g. if number of interactions are considered
  T weight;
};

/// output operator for a point object
/// @param os output stream the point object should be printed to
/// @param p the point object to be printed
/// @return the modified output stream
template <class T>
std::ostream &operator<<(std::ostream &os, const Point<T> &p) {
  for (int i = 0; i < p.getDimension(); ++i)
    os << p[i] << " ";
  os << p.getWeight();
  return os;
}

/// operator to scale a point by a factor (reversed way of notation T *
/// Point<T>)
/// @param lhs scaling factor
/// @param rhs the point object to be scaled
/// @param scaled point object
template <class T>
Point<T> operator*(const T &lhs, const Point<T> &rhs) {
  return rhs * lhs;
}

// template <class T>
// Point<T> operator/(const T &lhs, const Point<T> &rhs) {
//   return rhs * ((T)1 / lhs);
// }

}//namespace ALL

#endif

/*
Copyright 2020-2020 Stephan Schulz, Forschungszentrum Juelich GmbH, Germany

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
   other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ALL_DEFINES_HEADER_INCLUDED
#define ALL_DEFINES_HEADER_INCLUDED

#if defined(__clang__)
#define known_unused __attribute__((unused))

#elif defined(__INTEL_COMPILER)
#warning "The Intel compiler is not properly supported."
#define known_unused

#elif defined(__GNUC__) || defined(__GNUG__)
#define known_unused __attribute__((unused))

#elif defined(_MSC_VER)
#warning "The Microsoft compilers are not supported."
#define known_unused

#else
#warning "Unknown compilers are not supported."
#define known_unused

#endif

#endif//ALL_DEFINES_HEADER_INCLUDED

#include <algorithm>
#include <cmath>
#include <exception>
#include <mpi.h>
#include <vector>

namespace ALL {

/// Load-balancing scheme based on the shift of vertices according to the ratio
/// of work from all the neighboring domains. The vertex is drawn in the
/// direction of the geometric center of the domain with the most work. The
/// direction is influenced by the other domains, their work and location of
/// geometric centers. Some precautions are taken to avoid domains with too
/// small angles at their vertices. The neighboring relation of domains is
/// conserved throughout the load-balancing process.
/// @tparam T data for vertices and related data
/// @tparam W data for work and related data
template <class T, class W> class ForceBased_LB : public LB<T, W> {
public:
  /// default constructor
  ForceBased_LB() {}
  /// constructor initializing basic parameters
  /// @param[in] d the dimension of the used vertices
  /// @param[in] w the scalar work assigned to the local domain
  /// @param[in] g the correction factor gamma
  ForceBased_LB(int d, W w, T g) : LB<T, W>(d, g) {
    this->setWork(w);
  }

  /// default destructor
  ~ForceBased_LB() override;

  /// setup internal data structures and parameters
  void setup() override;

  /// method to execute a load-balancing step
  /// @param[in] step number of the load-balancing step
  virtual void balance(int step) override;

  // getter for variables (passed by reference to avoid
  // direct access to private members of the object)

  /// method to provide a list of the neighbors of the local domain
  /// @param[out] list reference to a std::vector of integers where the list of
  /// neighbors will be assigned to
  virtual std::vector<int> &getNeighbors() override;

  /// method to set specific data structures (unused for tensor grid method)
  /// @param[in] data pointer to the data structure
  virtual void setAdditionalData(known_unused const void *data) override {}

private:
  // type for MPI communication
  MPI_Datatype MPIDataTypeT;
  MPI_Datatype MPIDataTypeW;

  // array of MPI communicators for each vertex
  std::vector<T> vertex_neighbors;

  // MPI communicator to collect the work in the
  // main dimension
  MPI_Comm main_communicator;

  // list of neighbors
  std::vector<int> neighbors;

  // find neighbors (more sophisticated than for tensor-product
  // variant of LB)
  void find_neighbors();

  // number of vertices (since it is not equal for all domains)
  int n_vertices;

  // main dimension (correction in staggered style)
  int main_dim;

  // secondary dimensions (2D force shift)
  int sec_dim[2];
};

template <class T, class W> ForceBased_LB<T, W>::~ForceBased_LB() {}

// provide list of neighbors
template <class T, class W>
std::vector<int> &ForceBased_LB<T, W>::getNeighbors() {
  return neighbors;
}

template <class T, class W> void ForceBased_LB<T, W>::setup() {
  n_vertices = this->vertices.size();
  vertex_neighbors.resize(n_vertices * 8);

  // determine correct MPI data type for template T
  if (std::is_same<T, double>::value)
    MPIDataTypeT = MPI_DOUBLE;
  else if (std::is_same<T, float>::value)
    MPIDataTypeT = MPI_FLOAT;
  else if (std::is_same<T, int>::value)
    MPIDataTypeT = MPI_INT;
  else if (std::is_same<T, long>::value)
    MPIDataTypeT = MPI_LONG;
  else {
    throw InvalidCommTypeException(
        __FILE__, __func__, __LINE__,
        "Invalid data type for boundaries given (T)");
  }

  // determine correct MPI data type for template W
  if (std::is_same<W, double>::value)
    MPIDataTypeW = MPI_DOUBLE;
  else if (std::is_same<W, float>::value)
    MPIDataTypeW = MPI_FLOAT;
  else if (std::is_same<W, int>::value)
    MPIDataTypeW = MPI_INT;
  else if (std::is_same<W, long>::value)
    MPIDataTypeW = MPI_LONG;
  else {
    throw InvalidCommTypeException(__FILE__, __func__, __LINE__,
                                       "Invalid data type for work given (W)");
  }

  MPI_Group all;
  MPI_Comm_group(this->globalComm, &all);

  // check if communicator is cartesian
  int status;
  MPI_Topo_test(this->globalComm, &status);

  if (status != MPI_CART) {
    throw InvalidCommTypeException(
        __FILE__, __func__, __LINE__,
        "Cartesian MPI communicator required, passed communicator is not "
        "cartesian");
  }

  // get the local coordinates, this->periodicity and global size from the MPI
  // communicator
  MPI_Cart_get(this->globalComm, this->dimension, this->global_dims.data(),
               this->periodicity.data(), this->local_coords.data());

  // get the local rank from the MPI communicator
  MPI_Cart_rank(this->globalComm, this->local_coords.data(), &this->localRank);

  // groups required for new communicators
  MPI_Group known_unused  groups[n_vertices];
  // arrays of processes belonging to group
  int known_unused processes[n_vertices][n_vertices];

  // shifted local coordinates to find neighboring processes
  int known_unused shifted_coords[this->dimension];

  // get main and secondary dimensions
  if (this->global_dims.at(2) >= this->global_dims.at(1)) {
    if (this->global_dims.at(2) >= this->global_dims.at(0)) {
      main_dim = 2;
      sec_dim[0] = 0;
      sec_dim[1] = 1;
    } else {
      main_dim = 0;
      sec_dim[0] = 1;
      sec_dim[1] = 2;
    }
  } else {
    if (this->global_dims.at(1) >= this->global_dims.at(0)) {
      main_dim = 1;
      sec_dim[0] = 0;
      sec_dim[1] = 2;
    } else {
      main_dim = 0;
      sec_dim[0] = 1;
      sec_dim[1] = 2;
    }
  }

  if (this->localRank == 0)
    std::cout << "DEBUG: main_dim: " << main_dim << std::endl;

  // create main communicator
  MPI_Comm_split(this->globalComm, this->local_coords.at(main_dim),
                 this->local_coords.at(sec_dim[0]) +
                     this->local_coords.at(sec_dim[1]) *
                         this->global_dims.at(sec_dim[0]),
                 &main_communicator);

  /*

      // sequence of vertices in 1d
      //
      // 0 - - - 1

      // sequence of vertices in 2d
      //
      // 2 - - - 3
      // |       |
      // |       |
      // 0 - - - 1

      // sequence of vertices in 3d
      //
      //    6 - - - 7
      //   /|      /|
      //  / |     / |
      // 4 -2- - 5  3
      // | /     | /
      // |/      |/
      // 0 - - - 1

  */

#ifdef ALL_DEBUG_ENABLED
  MPI_Barrier(this->globalComm);
  if (this->localRank == 0)
    std::cout << "ALL::ForceBased_LB<T,W>::setup() preparing communicators..."
              << std::endl;
#endif
  std::vector<int> dim_vert(this->global_dims);

  MPI_Comm known_unused tmp_comm;
  int known_unused own_vertex;

#ifdef ALL_DEBUG_ENABLED
  MPI_Barrier(this->globalComm);
  if (this->localRank == 0)
    std::cout << "ALL::ForceBased_LB<T,W>::setup() computing communicators..."
              << std::endl;
  std::cout << "DEBUG: "
            << " rank: " << this->localRank << " dim_vert: " << dim_vert.at(0)
            << " " << dim_vert.at(1) << " " << dim_vert.at(2)
            << " size(local_coords): " << this->local_coords.size() << " "
            << " size(global_dims):  " << this->global_dims.size() << std::endl;
#endif
  for (int iz = 0; iz < dim_vert.at(2); ++iz) {
    for (int iy = 0; iy < dim_vert.at(1); ++iy) {
      for (int ix = 0; ix < dim_vert.at(0); ++ix) {
        bool affected[8];
        for (auto &a : affected)
          a = false;
        int v_neighbors[8];
        for (auto &vn : vertex_neighbors)
          vn = -1;
        if (ix == ((this->local_coords.at(0) + 0) % dim_vert.at(0)) &&
            iy == ((this->local_coords.at(1) + 0) % dim_vert.at(1)) &&
            iz == ((this->local_coords.at(2) + 0) % dim_vert.at(2))) {
          affected[0] = true;
          v_neighbors[0] = this->localRank;
        }
        if (ix == ((this->local_coords.at(0) + 1) % dim_vert.at(0)) &&
            iy == ((this->local_coords.at(1) + 0) % dim_vert.at(1)) &&
            iz == ((this->local_coords.at(2) + 0) % dim_vert.at(2))) {
          affected[1] = true;
          v_neighbors[1] = this->localRank;
        }
        if (ix == ((this->local_coords.at(0) + 0) % dim_vert.at(0)) &&
            iy == ((this->local_coords.at(1) + 1) % dim_vert.at(1)) &&
            iz == ((this->local_coords.at(2) + 0) % dim_vert.at(2))) {
          affected[2] = true;
          v_neighbors[2] = this->localRank;
        }
        if (ix == ((this->local_coords.at(0) + 1) % dim_vert.at(0)) &&
            iy == ((this->local_coords.at(1) + 1) % dim_vert.at(1)) &&
            iz == ((this->local_coords.at(2) + 0) % dim_vert.at(2))) {
          affected[3] = true;
          v_neighbors[3] = this->localRank;
        }
        if (ix == ((this->local_coords.at(0) + 0) % dim_vert.at(0)) &&
            iy == ((this->local_coords.at(1) + 0) % dim_vert.at(1)) &&
            iz == ((this->local_coords.at(2) + 1) % dim_vert.at(2))) {
          affected[4] = true;
          v_neighbors[4] = this->localRank;
        }
        if (ix == ((this->local_coords.at(0) + 1) % dim_vert.at(0)) &&
            iy == ((this->local_coords.at(1) + 0) % dim_vert.at(1)) &&
            iz == ((this->local_coords.at(2) + 1) % dim_vert.at(2))) {
          affected[5] = true;
          v_neighbors[5] = this->localRank;
        }
        if (ix == ((this->local_coords.at(0) + 0) % dim_vert.at(0)) &&
            iy == ((this->local_coords.at(1) + 1) % dim_vert.at(1)) &&
            iz == ((this->local_coords.at(2) + 1) % dim_vert.at(2))) {
          affected[6] = true;
          v_neighbors[6] = this->localRank;
        }
        if (ix == ((this->local_coords.at(0) + 1) % dim_vert.at(0)) &&
            iy == ((this->local_coords.at(1) + 1) % dim_vert.at(1)) &&
            iz == ((this->local_coords.at(2) + 1) % dim_vert.at(2))) {
          affected[7] = true;
          v_neighbors[7] = this->localRank;
        }

        MPI_Allreduce(MPI_IN_PLACE, v_neighbors, 8, MPI_INT, MPI_MAX,
                      this->globalComm);

        for (int v = 0; v < n_vertices; ++v) {
          if (affected[v]) {
            for (int n = 0; n < 8; ++n) {
              vertex_neighbors.at(8 * v + n) = v_neighbors[n];
            }
          }
        }
      }
    }
// ToDo: check if vertices correct
#ifdef ALL_DEBUG_ENABLED
    MPI_Barrier(this->globalComm);
    if (this->localRank == 0)
      std::cout << "ALL::ForceBased_LB<T,W>::setup() finished computing "
                   "communicators..."
                << std::endl;
#endif
  }
}

// TODO: periodic boundary conditions (would require size of the system)
//       for now: do not change the vertices along the edge of the system

template <class T, class W>
void ForceBased_LB<T, W>::balance(int /*step*/) {

  this->prevVertices = this->vertices;

  // geometrical center and work of each neighbor for each vertex
  // work is cast to vertex data type, since in the end a shift
  // of the vertex is computed
  T vertex_info[n_vertices * n_vertices * (this->dimension + 2)];
  T center[this->dimension];

  // local geometric center
  T known_unused local_info[(this->dimension + 2) * n_vertices];

  for (int i = 0; i < n_vertices * n_vertices * (this->dimension + 2); ++i)
    vertex_info[i] = -1;

  for (int d = 0; d < (this->dimension + 2) * n_vertices; ++d)
    local_info[d] = (T)0;

  for (int d = 0; d < this->dimension; ++d)
    center[d] = (T)0;

  // compute geometric center
  for (int v = 0; v < n_vertices; ++v) {
    for (int d = 0; d < this->dimension; ++d) {
      center[d] += ((this->prevVertices.at(v))[d] / (T)n_vertices);
    }
    local_info[v * (this->dimension + 2) + this->dimension] =
        (T)this->work.at(0);
  }
  for (int v = 0; v < n_vertices; ++v) {
    for (int d = 0; d < this->dimension; ++d) {
      // vector pointing to center
      local_info[v * (this->dimension + 2) + d] =
          center[d] - (this->prevVertices.at(v))[d];
    }
  }

  // compute for each vertex the maximum movement
  switch (main_dim) {
  case 0:
    local_info[0 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(0).d(this->prevVertices.at(2)),
                       this->prevVertices.at(0).d(this->prevVertices.at(4)));
    local_info[1 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(1).d(this->prevVertices.at(3)),
                       this->prevVertices.at(1).d(this->prevVertices.at(5)));
    local_info[2 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(2).d(this->prevVertices.at(0)),
                       this->prevVertices.at(2).d(this->prevVertices.at(6)));
    local_info[3 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(3).d(this->prevVertices.at(1)),
                       this->prevVertices.at(3).d(this->prevVertices.at(7)));
    local_info[4 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(4).d(this->prevVertices.at(0)),
                       this->prevVertices.at(4).d(this->prevVertices.at(6)));
    local_info[5 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(5).d(this->prevVertices.at(1)),
                       this->prevVertices.at(5).d(this->prevVertices.at(7)));
    local_info[6 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(6).d(this->prevVertices.at(2)),
                       this->prevVertices.at(6).d(this->prevVertices.at(4)));
    local_info[7 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(7).d(this->prevVertices.at(3)),
                       this->prevVertices.at(7).d(this->prevVertices.at(5)));
    break;
  case 1:
    local_info[0 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(0).d(this->prevVertices.at(1)),
                       this->prevVertices.at(0).d(this->prevVertices.at(4)));
    local_info[1 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(1).d(this->prevVertices.at(0)),
                       this->prevVertices.at(1).d(this->prevVertices.at(5)));
    local_info[2 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(2).d(this->prevVertices.at(3)),
                       this->prevVertices.at(2).d(this->prevVertices.at(6)));
    local_info[3 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(3).d(this->prevVertices.at(2)),
                       this->prevVertices.at(3).d(this->prevVertices.at(7)));
    local_info[4 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(4).d(this->prevVertices.at(0)),
                       this->prevVertices.at(4).d(this->prevVertices.at(5)));
    local_info[5 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(5).d(this->prevVertices.at(1)),
                       this->prevVertices.at(5).d(this->prevVertices.at(4)));
    local_info[6 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(6).d(this->prevVertices.at(2)),
                       this->prevVertices.at(6).d(this->prevVertices.at(7)));
    local_info[7 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(7).d(this->prevVertices.at(3)),
                       this->prevVertices.at(7).d(this->prevVertices.at(6)));
    break;
  case 2:
    local_info[0 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(0).d(this->prevVertices.at(1)),
                       this->prevVertices.at(0).d(this->prevVertices.at(2)));
    local_info[1 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(1).d(this->prevVertices.at(0)),
                       this->prevVertices.at(1).d(this->prevVertices.at(3)));
    local_info[2 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(2).d(this->prevVertices.at(0)),
                       this->prevVertices.at(2).d(this->prevVertices.at(3)));
    local_info[3 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(3).d(this->prevVertices.at(1)),
                       this->prevVertices.at(3).d(this->prevVertices.at(2)));
    local_info[4 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(4).d(this->prevVertices.at(5)),
                       this->prevVertices.at(4).d(this->prevVertices.at(6)));
    local_info[5 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(5).d(this->prevVertices.at(4)),
                       this->prevVertices.at(5).d(this->prevVertices.at(7)));
    local_info[6 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(6).d(this->prevVertices.at(4)),
                       this->prevVertices.at(6).d(this->prevVertices.at(7)));
    local_info[7 * (this->dimension + 2) + this->dimension + 1] =
        0.5 * std::min(this->prevVertices.at(7).d(this->prevVertices.at(5)),
                       this->prevVertices.at(7).d(this->prevVertices.at(6)));
    break;
  default:
    throw InternalErrorException(
        __FILE__, __func__, __LINE__,
        "Invalid main dimension provided (numerical value not 0, 1 or 2).");
    break;
  }
  // exchange information with all vertex neighbors
  MPI_Request known_unused request[n_vertices];
  MPI_Status known_unused status[n_vertices];

  // compute new position for vertex 7 (if not periodic)
  T known_unused total_work = (T)0;
  T known_unused shift_vectors[this->dimension * n_vertices];

  for (int v = 0; v < n_vertices; ++v) {
    for (int d = 0; d < this->dimension; ++d) {
      shift_vectors[v * this->dimension + d] = (T)0;
    }
  }

  // TODO:
  // 1.) collect work in main_dim communicators
  // 2.) exchange work and extension in main_dim to neighbors in main_dim
  // 3.) correct extension in main_dim
  // 4.) do force-based correction in secondary dimensions
  // 5.) find new neighbors in main_dim (hardest part, probably cell based)

  int main_up;
  int main_down;

  // as each process computes the correction of the upper layer of vertices
  // the source is 'main_up' and the target 'main_down'
  MPI_Cart_shift(this->globalComm, main_dim, 1, &main_down, &main_up);

  W local_work = this->work.at(0);
  W remote_work;

  // reduce work from local layer
  MPI_Allreduce(MPI_IN_PLACE, &local_work, 1, MPIDataTypeW, MPI_SUM,
                main_communicator);

  // exchange local work with neighbor in main direction
  MPI_Status state;
  MPI_Sendrecv(&local_work, 1, MPIDataTypeW, main_down, 1010, &remote_work, 1,
               MPIDataTypeW, main_up, 1010, this->globalComm, &state);

  // transfer width of domains as well
  T remote_width;
  T local_width;
  switch (main_dim) {
  case 0:
    local_width = this->prevVertices.at(1)[0] - this->prevVertices.at(0)[0];
    break;
  case 1:
    local_width = this->prevVertices.at(2)[1] - this->prevVertices.at(0)[1];
    break;
  case 2:
    local_width = this->prevVertices.at(4)[2] - this->prevVertices.at(0)[2];
    break;
  default:
    throw InternalErrorException(
        __FILE__, __func__, __LINE__,
        "Invalid main dimension provided (numerical value not 0, 1 or 2).");
    break;
  }
  MPI_Sendrecv(&local_width, 1, MPIDataTypeT, main_down, 1010, &remote_width, 1,
               MPIDataTypeT, main_up, 1010, this->globalComm, &state);
  T total_width = local_width + remote_width;
  T max_main_shift = std::min(0.49 * std::min(local_width, remote_width),
                              std::min(local_width, remote_width) - 1.0);

  // compute shift
  T local_shift = (remote_work - local_work) / (remote_work + local_work) /
                  this->gamma / 2.0 * total_width;
  local_shift = (std::abs(local_shift) > max_main_shift)
                    ? std::abs(local_shift) * max_main_shift / local_shift
                    : local_shift;
  T remote_shift = 0;

  // TODO: fix -> send to upper neighbor, receive from lower neighbor!!
  //              sendrecv not correct!

  // transfer shift back
  MPI_Sendrecv(&local_shift, 1, MPIDataTypeT, main_up, 2020, &remote_shift, 1,
               MPIDataTypeT, main_down, 2020, this->globalComm, &state);

  // apply shift in main direction
  switch (main_dim) {
  case 0:
    if (this->local_coords.at(0) > 0) {
      this->vertices.at(0)[0] = this->prevVertices.at(0)[0] + remote_shift;
      this->vertices.at(2)[0] = this->prevVertices.at(2)[0] + remote_shift;
      this->vertices.at(4)[0] = this->prevVertices.at(4)[0] + remote_shift;
      this->vertices.at(6)[0] = this->prevVertices.at(6)[0] + remote_shift;
    }
    if (this->local_coords.at(0) < this->global_dims.at(0) - 1) {
      this->vertices.at(1)[0] = this->prevVertices.at(1)[0] + local_shift;
      this->vertices.at(3)[0] = this->prevVertices.at(3)[0] + local_shift;
      this->vertices.at(5)[0] = this->prevVertices.at(5)[0] + local_shift;
      this->vertices.at(7)[0] = this->prevVertices.at(7)[0] + local_shift;
    }
    break;
  case 1:
    if (this->local_coords.at(1) > 0) {
      this->vertices.at(0)[1] = this->prevVertices.at(0)[1] + remote_shift;
      this->vertices.at(1)[1] = this->prevVertices.at(1)[1] + remote_shift;
      this->vertices.at(4)[1] = this->prevVertices.at(4)[1] + remote_shift;
      this->vertices.at(5)[1] = this->prevVertices.at(5)[1] + remote_shift;
    }
    if (this->local_coords.at(1) < this->global_dims.at(1) - 1) {
      this->vertices.at(2)[1] = this->prevVertices.at(2)[1] + local_shift;
      this->vertices.at(3)[1] = this->prevVertices.at(3)[1] + local_shift;
      this->vertices.at(6)[1] = this->prevVertices.at(6)[1] + local_shift;
      this->vertices.at(7)[1] = this->prevVertices.at(7)[1] + local_shift;
    }
    break;
  case 2:
    if (this->local_coords.at(2) > 0) {
      this->vertices.at(0)[2] = this->prevVertices.at(0)[2] + remote_shift;
      this->vertices.at(1)[2] = this->prevVertices.at(1)[2] + remote_shift;
      this->vertices.at(2)[2] = this->prevVertices.at(2)[2] + remote_shift;
      this->vertices.at(3)[2] = this->prevVertices.at(3)[2] + remote_shift;
    }
    if (this->local_coords.at(2) < this->global_dims.at(2) - 1) {
      this->vertices.at(4)[2] = this->prevVertices.at(4)[2] + local_shift;
      this->vertices.at(5)[2] = this->prevVertices.at(5)[2] + local_shift;
      this->vertices.at(6)[2] = this->prevVertices.at(6)[2] + local_shift;
      this->vertices.at(7)[2] = this->prevVertices.at(7)[2] + local_shift;
    }
    break;
  default:
    throw InternalErrorException(
        __FILE__, __func__, __LINE__,
        "Invalid main dimension provided (numerical value not 0, 1 or 2).");
    break;
  }

  if (this->localRank <= 1) {
    std::cout << "DEBUG (main-dim shift): " << this->localRank << " "
              << remote_work << " " << local_work << " " << total_width << " "
              << local_shift << " " << remote_shift
              << " 0: " << this->prevVertices.at(0)[2]
              << " 0: " << this->vertices.at(0)[2]
              << " 4: " << this->prevVertices.at(4)[2]
              << " 4: " << this->vertices.at(4)[2] << " " << std::endl;
  }

  int last_vertex = (n_vertices - 1) * n_vertices * (this->dimension + 2);
  int vertex_offset = this->dimension + 2;

  // compute max shift
  T max_shift = std::max(
      0.49 * vertex_info[last_vertex + 0 * vertex_offset + this->dimension + 1],
      1e-6);
  for (int v = 1; v < n_vertices; ++v) {
    max_shift = std::min(
        max_shift,
        0.49 *
            vertex_info[last_vertex + v * vertex_offset + this->dimension + 1]);
  }

  // average work of neighboring processes for last vertex
  T avg_work = 0.0;
  for (int v = 0; v < n_vertices; ++v) {
    avg_work += vertex_info[last_vertex + v * vertex_offset + this->dimension];
  }
  avg_work /= (T)n_vertices;

  // compute shift vector
  std::vector<T> vertex_shift(n_vertices * this->dimension, (T)0.0);
  for (auto &sv : vertex_shift)
    sv = (T)0.0;
  int shift_offset = (n_vertices - 1) * this->dimension;

  for (int v = 0; v < n_vertices; ++v) {
    for (int d = 0; d < this->dimension; ++d) {
      if (this->localRank == 0)
        std::cout
            << "DEBUG (shift x): " << v << ", " << d << " "
            << (vertex_info[last_vertex + v * vertex_offset + this->dimension] -
                avg_work) *
                   ((vertex_info[last_vertex + v * vertex_offset +
                                 this->dimension] > avg_work)
                        ? 1.0
                        : -1.0) /
                   this->gamma *
                   (vertex_info[last_vertex + v * vertex_offset + d] -
                    this->prevVertices.at(v)[d])
            << " => " << vertex_shift.at(shift_offset + d) <<

            " max: " << max_shift
            << " "
               " avg_work: "
            << avg_work
            << " "
               " work: "
            << vertex_info[last_vertex + v * vertex_offset + this->dimension]
            << " "
               " 1/0: "
            << ((vertex_info[last_vertex + v * vertex_offset +
                             this->dimension] > avg_work)
                    ? 1.0
                    : -1.0)

            << std::endl;
      vertex_shift.at(shift_offset + d) +=
          (vertex_info[last_vertex + v * vertex_offset + this->dimension] -
           avg_work) *
          ((vertex_info[last_vertex + v * vertex_offset + this->dimension] >
            avg_work)
               ? 1.0
               : -1.0) /
          this->gamma *
          (vertex_info[last_vertex + v * vertex_offset + d] -
           this->prevVertices.at(v)[d]);
    }
  }

  Point<T> shift_vector(3);
  shift_vector[0] = vertex_shift.at(shift_offset);
  shift_vector[1] = vertex_shift.at(shift_offset + 1);
  shift_vector[2] = vertex_shift.at(shift_offset + 2);
  T shift_length = shift_vector.norm();
  if (this->localRank == 0)
    std::cout << "DEBUG (shift length): " << shift_length
              << " shift vector: " << shift_vector[0] << " " << shift_vector[1]
              << " " << shift_vector[2] << " " << std::endl;

  // apply correct length, if the shift vector is too large
  if (shift_length > max_shift) {
    for (int d = 0; d < this->dimension; ++d) {
      vertex_shift.at(shift_offset + d) *= max_shift / shift_length;
    }
  }

  if (this->localRank == 0) {
    for (int v = 0; v < n_vertices; ++v) {
      std::cout << "DEBUG shift vector vertex (before): " << v << ": ";
      for (int d = 0; d < this->dimension; ++d) {
        std::cout << vertex_shift.at(v * this->dimension + d) << " ";
      }
      std::cout << std::endl;
    }
  }

  if (this->localRank == 0 || this->localRank == 1) {
    for (int v = 0; v < n_vertices; ++v) {
      std::cout << "DEBUG shift vector vertex " << v << ": ";
      for (int d = 0; d < this->dimension; ++d) {
        std::cout << vertex_shift.at(v * this->dimension + d) << " ";
      }
      std::cout << std::endl;
    }
  }

  bool shift[3];
  for (int z = 0; z < 2; ++z) {
    if ((z == 0 && this->local_coords.at(2) == 0) ||
        (z == 1 && this->local_coords.at(2) == this->global_dims.at(2) - 1))
      shift[2] = false;
    else
      shift[2] = true;
    for (int y = 0; y < 2; ++y) {
      if ((y == 0 && this->local_coords.at(1) == 0) ||
          (y == 1 && this->local_coords.at(1) == this->global_dims.at(1) - 1))
        shift[1] = false;
      else
        shift[1] = true;
      for (int x = 0; x < 2; ++x) {
        if ((x == 0 && this->local_coords.at(0) == 0) ||
            (x == 1 && this->local_coords.at(0) == this->global_dims.at(0) - 1))
          shift[0] = false;
        else
          shift[0] = true;
        for (int d = 0; d < this->dimension; ++d) {
          if (d == main_dim)
            continue;
          int v = 4 * z + 2 * y + x;
          if (shift[d])
            this->vertices.at(v)[d] = this->prevVertices.at(v)[d] +
                                      vertex_shift.at(v * this->dimension + d);
          else
            this->vertices.at(v)[d] = this->prevVertices.at(v)[d];
        }
      }
    }
  }
}

}//namespace ALL

#endif

#include <algorithm>
#include <iomanip>
#include <memory>
#include <numeric>
#include <sstream>
#include <string>
#include <vector>

#include <sys/stat.h>
#include <cerrno>

#ifdef ALL_VTK_OUTPUT
#include <vtkCellArray.h>
#include <vtkCellData.h>
#include <vtkFloatArray.h>
#include <vtkInformation.h>
#include <vtkIntArray.h>
#include <vtkMPIController.h>
#include <vtkPolyhedron.h>
#include <vtkProgrammableFilter.h>
#include <vtkSmartPointer.h>
#include <vtkUnstructuredGrid.h>
#include <vtkVoxel.h>
#include <vtkXMLPUnstructuredGridWriter.h>
#include <vtkXMLUnstructuredGridWriter.h>
#endif

namespace ALL {

#define ALL_ESTIMATION_LIMIT_DEFAULT 0

/// enum type to describe the different balancing methods
enum LB_t : int {
  /// staggered grid load balancing
  STAGGERED = 0,
  /// tensor based load balancing
  TENSOR = 1,
  /// unstructured-mesh load balancing
  FORCEBASED = 2,
#ifdef ALL_VORONOI_ACTIVE
  /// voronoi cell based load balancing
  VORONOI = 3,
#endif
  /// histogram based load balancing
  HISTOGRAM = 4,
  /// Unimplemented load balancing NEVER SUPPORTED
  UNIMPLEMENTED = 128
};

/// @tparam T data type for vertices and related data
/// @tparam W data type for work and related data

template <class T, class W> class ALL {
public:
  /// default constructor, that sets up internal data structures and initializes
  /// internal values shared between all balancing methods
  ALL()
      :
        loadbalancing_step(0)
#ifdef ALL_VTK_OUTPUT
        , vtk_init(false)
#endif
        {
    // determine correct MPI data type for template T
    if (std::is_same<T, double>::value)
      MPIDataTypeT = MPI_DOUBLE;
    else if (std::is_same<T, float>::value)
      MPIDataTypeT = MPI_FLOAT;
    else if (std::is_same<T, int>::value)
      MPIDataTypeT = MPI_INT;
    else if (std::is_same<T, long>::value)
      MPIDataTypeT = MPI_LONG;

    // determine correct MPI data type for template W
    if (std::is_same<W, double>::value)
      MPIDataTypeW = MPI_DOUBLE;
    else if (std::is_same<W, float>::value)
      MPIDataTypeW = MPI_FLOAT;
    else if (std::is_same<W, int>::value)
      MPIDataTypeW = MPI_INT;
    else if (std::is_same<W, long>::value)
      MPIDataTypeW = MPI_LONG;
  }

  /// constructor providing the balancing method to use, the dimensions of the
  /// vertices and the gamma correction value and setting the chosen balancing
  /// methods up
  /// @param[in] m the balancing method to be used
  /// @param[in] d the dimension of the vertices to be used (most methods
  /// currently only support 3D vertices)
  /// @param[in] g the value used for the correction value, if required by the
  /// chosen balancing method
  ALL(const LB_t m, const int d, const T g) : ALL() {
    method = m;
    switch (method) {
    case LB_t::TENSOR:
      balancer.reset(new Tensor_LB<T, W>(d, (W)0, g));
      break;
    case LB_t::STAGGERED:
      balancer.reset(new Staggered_LB<T, W>(d, (W)0, g));
      break;
    case LB_t::FORCEBASED:
      balancer.reset(new ForceBased_LB<T, W>(d, (W)0, g));
      break;
#ifdef ALL_VORONOI_ACTIVE
    case LB_t::VORONOI:
      balancer.reset(new Voronoi_LB<T, W>(d, (W)0, g));
      break;
#endif
    case LB_t::HISTOGRAM:
      balancer.reset(new Histogram_LB<T, W>(d, std::vector<W>(10), g));
      break;
    default:
      throw InvalidArgumentException(
          __FILE__, __func__, __LINE__,
          "Unknown type of loadbalancing passed.");
    }
    balancer->setDimension(d);
    balancer->setGamma(g);
    estimation_limit = ALL_ESTIMATION_LIMIT_DEFAULT;
  }

  /// constructor to setup the method, the dimension of the used vertices, the
  /// correction value and also providing a first set of vertices to start from
  /// @param[in] m the balancing method to be used
  /// @param[in] d the dimension of the vertices to be used (most methods
  /// currently only support 3D vertices)
  /// @param[in] inp the set of vertices to be used in the
  /// balancing step
  /// @param[in] g the value used for the correction value, if required by the
  /// chosen balancing method
  ALL(const LB_t m, const int d, const std::vector<Point<T>> &inp,
      const T g)
      : ALL(m, d, g) {
    balancer->setVertices(inp);
    calculate_outline();
  }

  /// destructor
  ~ALL() = default;

  /// method to provide a new set of vertices
  /// @param[in] inp reference to a vector of ALL::Point objects describing
  /// the vertices to be used in the balancing step
  void setVertices(const std::vector<Point<T>> &inp) {
    int dim = inp.at(0).getDimension();
    if (dim != balancer->getDimension())
      throw PointDimensionMissmatchException(
          __FILE__, __func__, __LINE__,
          "Dimension of ALL::Points in input vector do not match dimension of "
          "ALL "
          "object.");
    balancer->setVertices(inp);
    calculate_outline();
  }

  /// method to set the communicator to be used in the balancing step, if a non
  /// cartesian communicator is provided, a cartesian communicator is created as
  /// a copy and used internally
  /// @param[in] comm the communicator to be used
  void setCommunicator(const MPI_Comm comm) {
    int comm_type;
    MPI_Topo_test(comm, &comm_type);
    if ( comm_type == MPI_CART) {
      communicator = comm;
      balancer->setCommunicator(communicator);
      // set procGridLoc and procGridDim
      const int dimension = balancer->getDimension();
      int location[dimension];
      int size[dimension];
      int periodicity[dimension];
      MPI_Cart_get(communicator, dimension, size, periodicity, location);
      procGridLoc.assign(location, location+dimension);
      procGridDim.assign(size, size+dimension);
      procGridSet = true;
    } else {
      int rank;
      MPI_Comm_rank(comm, &rank);
      if (procGridSet) {
        // compute 1D index from the location in the process grid (using z-y-x
        // ordering, as MPI_Dims_create)
        int idx;
        switch (balancer->getDimension()) {
        case 3:
          idx = procGridLoc.at(2) + procGridLoc.at(1) * procGridDim.at(2) +
                procGridLoc.at(0) * procGridDim.at(2) * procGridDim.at(1);
          break;
        case 2:
          idx = procGridLoc.at(1) + procGridLoc.at(0) * procGridDim.at(1);
          break;
        case 1:
          idx = procGridLoc.at(0);
          break;
        default:
          throw InternalErrorException(
              __FILE__, __func__, __LINE__,
              "ALL cannot deal with more then three dimensions (or less then "
              "one).");
          break;
        }

        // create new temporary communicator with correct ranks
        MPI_Comm temp_comm;
        MPI_Comm_split(comm, 0, idx, &temp_comm);

        std::vector<int> periods(3, 1);

        // transform temporary communicator to cartesian communicator
        MPI_Cart_create(temp_comm, balancer->getDimension(), procGridDim.data(),
                        periods.data(), 0, &communicator);
        balancer->setCommunicator(communicator);
      } else {
        throw InternalErrorException(
            __FILE__, __func__, __LINE__,
            "When using a non-cartesian communicator process grid parameters "
            "required (not set).");
      }
    }
  }

  /// method the get the correction value used in the balancing method
  ///@result T the correction value for the balancing method
  T getGamma() { return balancer->getGamma(); };

  /// method to set the correction value to be used in the balancing method
  /// @param[in] g the correctin value to be used
  void setGamma(const T g) { balancer->setGamma(g); };

  /// method to set a scalar work for the local domain
  /// @param[in] work the scalar work for the local domain
  void setWork(const W work) {
    // set new value for work (single value for whole domain)
    balancer->setWork(work);
  }

  // method to set a multi-dimensional work for the local domain
  ///@param[in] work std::vector<W> containing the work for the local domain
  void setWork(const std::vector<W> &work) { balancer->setWork(work); }

  /// method to call the setup of the chosen balancing method (not all methods
  /// require a setup)
  void setup() {
    balancer->setup();
  }

  /// method the trigger the balancing step, that updates the vertices according
  /// to the previously provided work and chosen method
  /// @param[in] internal toggles if internal steps are performed, needed
  /// for some recursive calls of the routine by some methods
  /// @result std::vector<ALL::Point<T>> containing the shifted set of vertices
  std::vector<Point<T>> &balance() {
    nVertices = balancer->getNVertices();
    switch (method) {
    case LB_t::TENSOR:
      balancer->balance(loadbalancing_step);
      break;
    case LB_t::STAGGERED:

      /* ToDo: Check if repetition is useful at all and
       *       change it to be included for all methods,
       *       not only STAGGERED */
      /*
      // estimation to improve speed of convergence
      // changing vertices during estimation
      std::vector<Point<T>> tmp_vertices = balancer->getVertices();
      // saved original vertices
      std::vector<Point<T>> old_vertices = balancer->getVertices();
      // old temporary vertices
      std::vector<Point<T>> old_tmp_vertices = balancer->getVertices();
      // result temporary vertices
      std::vector<Point<T>> result_vertices = balancer->getVertices();
      // temporary work
      W tmp_work = balancer->getWork().at(0);
      // old temporary work
      W old_tmp_work = balancer->getWork().at(0);

      W max_work;
      W sum_work;
      double d_max;
      int n_ranks;

      // compute work density on local domain
      double V = 1.0;
      for (int i = 0; i < balancer->getDimension(); ++i)
          V *= ( outline.at(1)[i] - outline.at(0)[i] );
      double rho = workArray.at(0) / V;

      // collect maximum work in system
      MPI_Allreduce(workArray.data(), &max_work, 1, MPIDataTypeW, MPI_MAX,
      communicator); MPI_Allreduce(workArray.data(), &sum_work, 1,
      MPIDataTypeW, MPI_SUM, communicator);
      MPI_Comm_size(communicator,&n_ranks);
      d_max = (double)(max_work) * (double)n_ranks / (double)sum_work - 1.0;


      // internal needs to be readded to argument list const bool internal = false
      for (int i = 0; i < estimation_limit && d_max > 0.1 && !internal; ++i)
      {
          balancer->setWork(tmp_work);
          balancer->setup();
          balancer->balance(true);
          bool sane = true;
          // check if the estimated boundaries are not too deformed
          for (int j = 0; j < balancer->getDimension(); ++j)
              sane = sane && (result_vertices.at(0)[j] <=
      old_vertices.at(1)[j]);
          MPI_Allreduce(MPI_IN_PLACE,&sane,1,MPI_CXX_BOOL,MPI_LAND,communicator);
          if (sane)
          {
              old_tmp_vertices = tmp_vertices;
              tmp_vertices = result_vertices;
              V = 1.0;
              for (int i = 0; i < balancer->getDimension(); ++i)
                  V *= ( tmp_vertices.at(1)[i] - tmp_vertices.at(0)[i] );
              old_tmp_work = tmp_work;
              tmp_work = rho * V;
          }
          else if (!sane || i == estimation_limit - 1)
          {
              balancer->getVertices() = old_tmp_vertices;
              workArray->at(0) = old_tmp_work;
              calculate_outline();
              i = estimation_limit;
          }
      }

      ((Staggered_LB<T,W>*)balancer.get())->setVertices(outline->data());
      */
      balancer->balance(loadbalancing_step);
      break;
    case LB_t::FORCEBASED:
      balancer->balance(loadbalancing_step);
      break;
#ifdef ALL_VORONOI_ACTIVE
    case LB_t::VORONOI:
      balancer->balance(loadbalancing_step);
      break;
#endif
    case LB_t::HISTOGRAM:
      balancer->balance(loadbalancing_step);
      break;
    default:
      throw InvalidArgumentException(
          __FILE__, __func__, __LINE__,
          "Unknown type of loadbalancing passed.");
    }
    loadbalancing_step++;
    return balancer->getVertices();
  }

  /**********************/
  /*  getter functions  */
  /**********************/

  /// get the vertices before performing the load-balancing step
  /// @result std::vector<ALL::Point<T>> containing the vertices before the
  /// balancing step
  std::vector<Point<T>> &getPrevVertices() {
    return balancer->getPrevVertices();
  };

  /// get the resulting vertices after the load-balancing step, if it has been
  /// performed
  /// @result std::vector<ALL::Point<T>> containing the resulting vertices after
  /// the balancing step
  std::vector<Point<T>> &getVertices() {
    return balancer->getVertices();
  };

  /// get the dimension of the ALL::Point<T> objects used to describe the
  /// vertices of the domains
  /// @result int containing the dimension of the vertices
  int getDimension() { return balancer->getDimension(); }

  /// method to get the work provided to the method
  /// @param[out] result reference to std::vector<W> to store the vector of work
  /// if an array of work was provided, e.g. for the histogram method
  void getWork(std::vector<W> &result) { result = balancer->getWork(); }

  /// method to get the work provided to the method
  /// @result scalar work or first value of vector work
  W getWork() { return balancer->getWork().at(0); }

  /// method to provide a list of the ranks of the neighbors the local domain
  /// has in all directions
  /// @result vector if neighboring ranks
  std::vector<int> &getNeighbors() {
    return balancer->getNeighbors();
  }

  /// method to provide a list of neighboring vertices, e.g. required for
  /// VORONOI
  /// @result vector of neighboring vertices
  /// neighboring vertices are stored in
  std::vector<T> &getNeighborVertices() {
      return balancer->getNeighborVertices();
  }

  /// method to set the size of the system, e.g. required for the HISTOGRAM
  /// balancing method
  /// @param[in] sysSize reference to a vector of T containing the size of
  /// the orthogonal system in the following format: (x_min, x_max, y_min,
  /// y_max, z_min, z_max)
  void setSysSize(const std::vector<T> &sysSize) {
    balancer.get()->setSysSize(sysSize);
  }

  /// method to set method specific data, that is not required by all different
  /// balancing methods
  /// @param[in] data pointer to a struct or other data object in the format the
  /// methods requires
  ///
  /// For the histogram method the number of bins per dimensions can be given
  /// as a C array of `int`s. The length of the array must be the number of
  /// dimensions given to the load balancer. BE CAREFUL this is not enforced!
  void setMethodData(const void *data) {
    balancer.get()->setAdditionalData(data);
  }

  /// method to set the parameters of the used cartesian communicator
  /// @param[in] loc the cartesian coordinates of the local domain in the
  /// process grid
  /// @param[in] size the size of the cartesian process grid
  void setProcGridParams(const std::vector<int> &loc,
                         const std::vector<int> &size) {
    // todo(s.schulz): We should probably throw if the dimension does not match
    procGridLoc.insert(procGridLoc.begin(), loc.begin(), loc.end());
    procGridDim.insert(procGridDim.begin(), size.begin(), size.end());
    procGridSet = true;
  }

  /// method to set the process tag output in VTK output
  /// @param[in] tag
  void setProcTag(int tag) { procTag = tag; }

  /// method the set the minimum domain sizes in all directions, can be required
  /// if using linked cell algorithms and wanting to prevent data exchange with
  /// next-near neighbors instead of only with next neighbors
  /// @param[in] minSize the minimum size of a domain in each dimension
  void setMinDomainSize(const std::vector<T> &minSize) {
    (balancer.get())->setMinDomainSize(minSize);
  }

#ifdef ALL_VTK_OUTPUT
  /// method to create VTK based output of the domains used in the
  /// load-balancing process (for now only orthogonal domains are supported)
  /// @param[in] step the number of the loadbalancing step used for numbering
  /// the output files
  void printVTKoutlines(const int step) {
    // define grid points, i.e. vertices of local domain
    auto points = vtkSmartPointer<vtkPoints>::New();
    // allocate space for eight points (describing the cuboid around the domain)
    points->Allocate(8 * balancer->getDimension());

    int n_ranks;
    int local_rank;

    if (!vtk_init) {
      controller = vtkMPIController::New();
      controller->Initialize();
      controller->SetGlobalController(controller);
      vtk_init = true;
    }

    MPI_Comm_rank(communicator, &local_rank);
    MPI_Comm_size(communicator, &n_ranks);

    std::vector<Point<W>> tmp_outline(2);
    std::vector<W> tmp_0(
        {outline.at(0)[0], outline.at(0)[1], outline.at(0)[2]});
    std::vector<W> tmp_1(
        {outline.at(1)[0], outline.at(1)[1], outline.at(1)[2]});
    tmp_outline.at(0) = Point<W>(tmp_0);
    tmp_outline.at(1) = Point<W>(tmp_1);

    for (auto z = 0; z <= 1; ++z)
      for (auto y = 0; y <= 1; ++y)
        for (auto x = 0; x <= 1; ++x) {
          points->InsertPoint(x + 2 * y + 4 * z, tmp_outline.at(x)[0],
                              tmp_outline.at(y)[1], tmp_outline.at(z)[2]);
        }

    auto hexa = vtkSmartPointer<vtkVoxel>::New();
    for (int i = 0; i < 8; ++i)
      hexa->GetPointIds()->SetId(i, i);

    auto cellArray = vtkSmartPointer<vtkCellArray>::New();
    cellArray->InsertNextCell(hexa);

    // define work array (length = 1)
    auto work = vtkSmartPointer<vtkFloatArray>::New();
    work->SetNumberOfComponents(1);
    work->SetNumberOfTuples(1);
    work->SetName("work");
    W total_work = std::accumulate(balancer->getWork().begin(),
                                   balancer->getWork().end(), (W)0);
    work->SetValue(0, total_work);

    // define rank array (length = 4, x,y,z, rank)
    int rank = 0;
    MPI_Comm_rank(communicator, &rank);
    auto rnk = vtkSmartPointer<vtkFloatArray>::New();
    rnk->SetNumberOfComponents(4);
    rnk->SetNumberOfTuples(1);
    rnk->SetName("rank");
    rnk->SetValue(0, procGridLoc.at(0));
    rnk->SetValue(1, procGridLoc.at(1));
    rnk->SetValue(2, procGridLoc.at(2));
    rnk->SetValue(3, rank);

    // define tag array (length = 1)
    auto tag = vtkSmartPointer<vtkIntArray>::New();
    tag->SetNumberOfComponents(1);
    tag->SetNumberOfTuples(1);
    tag->SetName("tag");
    tag->SetValue(0, procTag);

    // determine extent of system
    W known_unused global_extent[6];
    W local_min[3];
    W local_max[3];
    W global_min[3];
    W global_max[3];
    W width[3];
    W volume = (W)1.0;

    for (int i = 0; i < 3; ++i) {
      local_min[i] = outline.at(0)[i];
      local_max[i] = outline.at(1)[i];
      width[i] = local_max[i] - local_min[i];
      volume *= width[i];
    }

    W surface = (W)2.0 * width[0] * width[1] + (W)2.0 * width[1] * width[2] +
                (W)2.0 * width[0] * width[2];

    auto expanse = vtkSmartPointer<vtkFloatArray>::New();
    expanse->SetNumberOfComponents(6);
    expanse->SetNumberOfTuples(1);
    expanse->SetName("expanse");
    expanse->SetValue(0, width[0]);
    expanse->SetValue(1, width[0]);
    expanse->SetValue(2, width[0]);
    expanse->SetValue(3, volume);
    expanse->SetValue(4, surface);
    expanse->SetValue(5, surface / volume);

    MPI_Allreduce(&local_min, &global_min, 3, MPIDataTypeW, MPI_MIN,
                  communicator);
    MPI_Allreduce(&local_max, &global_max, 3, MPIDataTypeW, MPI_MAX,
                  communicator);

    for (int i = 0; i < 3; ++i) {
      global_extent[2 * i] = global_min[i];
      global_extent[2 * i + 1] = global_max[i];
    }

    // create a structured grid and assign data to it
    auto unstructuredGrid = vtkSmartPointer<vtkUnstructuredGrid>::New();
    unstructuredGrid->SetPoints(points);
    unstructuredGrid->SetCells(VTK_VOXEL, cellArray);
    unstructuredGrid->GetCellData()->AddArray(work);
    unstructuredGrid->GetCellData()->AddArray(expanse);
    unstructuredGrid->GetCellData()->AddArray(rnk);
    unstructuredGrid->GetCellData()->AddArray(tag);

    createDirectory("vtk_outline");
    std::ostringstream ss_local;
    ss_local << "vtk_outline/ALL_vtk_outline_" << std::setw(7)
             << std::setfill('0') << step << "_" << local_rank << ".vtu";

    auto writer = vtkSmartPointer<vtkXMLUnstructuredGridWriter>::New();
    writer->SetInputData(unstructuredGrid);
    writer->SetFileName(ss_local.str().c_str());
    writer->SetDataModeToAscii();
    // writer->SetDataModeToBinary();
    writer->Write();

    // if (local_rank == 0)
    //{
    std::ostringstream ss_para;
    ss_para << "vtk_outline/ALL_vtk_outline_" << std::setw(7)
            << std::setfill('0') << step << ".pvtu";
    // create the parallel writer
    auto parallel_writer =
        vtkSmartPointer<vtkXMLPUnstructuredGridWriter>::New();
    parallel_writer->SetFileName(ss_para.str().c_str());
    parallel_writer->SetNumberOfPieces(n_ranks);
    parallel_writer->SetStartPiece(local_rank);
    parallel_writer->SetEndPiece(local_rank);
    parallel_writer->SetInputData(unstructuredGrid);
    parallel_writer->SetDataModeToAscii();
    // parallel_writer->SetDataModeToBinary();
    parallel_writer->Write();
    //}
  }

  /// method to create VTK based output of the vertices used in the
  /// load-balancing process
  /// @param[in] step the number of the loadbalancing step used for numbering
  /// the output files
  void printVTKvertices(const int step) {
    int n_ranks;
    int local_rank;

    MPI_Comm_rank(communicator, &local_rank);
    MPI_Comm_size(communicator, &n_ranks);

    // local vertices
    // (vertices + work)
    T local_vertices[nVertices * balancer->getDimension() + 1];

    for (int v = 0; v < nVertices; ++v) {
      for (int d = 0; d < balancer->getDimension(); ++d) {
        local_vertices[v * balancer->getDimension() + d] =
            balancer->getVertices().at(v)[d];
      }
    }
    local_vertices[nVertices * balancer->getDimension()] =
        (T)balancer->getWork().at(0);

    T *global_vertices;
    if (local_rank == 0) {
      global_vertices =
          new T[n_ranks * (nVertices * balancer->getDimension() + 1)];
    }

    // collect all works and vertices on a single process
    MPI_Gather(local_vertices, nVertices * balancer->getDimension() + 1,
               MPIDataTypeT, global_vertices,
               nVertices * balancer->getDimension() + 1, MPIDataTypeT, 0,
               communicator);

    if (local_rank == 0) {
      auto vtkpoints = vtkSmartPointer<vtkPoints>::New();
      auto unstructuredGrid = vtkSmartPointer<vtkUnstructuredGrid>::New();

      // enter vertices into unstructured grid
      for (int i = 0; i < n_ranks; ++i) {
        for (int v = 0; v < nVertices; ++v) {
          vtkpoints->InsertNextPoint(
              global_vertices[i * (nVertices * balancer->getDimension() + 1) +
                              v * balancer->getDimension() + 0],
              global_vertices[i * (nVertices * balancer->getDimension() + 1) +
                              v * balancer->getDimension() + 1],
              global_vertices[i * (nVertices * balancer->getDimension() + 1) +
                              v * balancer->getDimension() + 2]);
        }
      }
      unstructuredGrid->SetPoints(vtkpoints);

      // data arrays for work and cell id
      auto work = vtkSmartPointer<vtkFloatArray>::New();
      auto cell = vtkSmartPointer<vtkFloatArray>::New();
      work->SetNumberOfComponents(1);
      work->SetNumberOfTuples(n_ranks);
      work->SetName("work");
      cell->SetNumberOfComponents(1);
      cell->SetNumberOfTuples(n_ranks);
      cell->SetName("cell id");

      for (int n = 0; n < n_ranks; ++n) {
        // define grid points, i.e. vertices of local domain
        vtkIdType pointIds[8] = {8 * n + 0, 8 * n + 1, 8 * n + 2, 8 * n + 3,
                                 8 * n + 4, 8 * n + 5, 8 * n + 6, 8 * n + 7};

        auto faces = vtkSmartPointer<vtkCellArray>::New();
        // setup faces of polyhedron
        vtkIdType f0[3] = {8 * n + 0, 8 * n + 2, 8 * n + 1};
        vtkIdType f1[3] = {8 * n + 1, 8 * n + 2, 8 * n + 3};

        vtkIdType f2[3] = {8 * n + 0, 8 * n + 4, 8 * n + 2};
        vtkIdType f3[3] = {8 * n + 2, 8 * n + 4, 8 * n + 6};

        vtkIdType f4[3] = {8 * n + 2, 8 * n + 6, 8 * n + 3};
        vtkIdType f5[3] = {8 * n + 3, 8 * n + 6, 8 * n + 7};

        vtkIdType f6[3] = {8 * n + 1, 8 * n + 5, 8 * n + 3};
        vtkIdType f7[3] = {8 * n + 3, 8 * n + 5, 8 * n + 7};

        vtkIdType f8[3] = {8 * n + 0, 8 * n + 4, 8 * n + 1};
        vtkIdType f9[3] = {8 * n + 1, 8 * n + 4, 8 * n + 5};

        vtkIdType fa[3] = {8 * n + 4, 8 * n + 6, 8 * n + 5};
        vtkIdType fb[3] = {8 * n + 5, 8 * n + 6, 8 * n + 7};

        faces->InsertNextCell(3, f0);
        faces->InsertNextCell(3, f1);
        faces->InsertNextCell(3, f2);
        faces->InsertNextCell(3, f3);
        faces->InsertNextCell(3, f4);
        faces->InsertNextCell(3, f5);
        faces->InsertNextCell(3, f6);
        faces->InsertNextCell(3, f7);
        faces->InsertNextCell(3, f8);
        faces->InsertNextCell(3, f9);
        faces->InsertNextCell(3, fa);
        faces->InsertNextCell(3, fb);

        unstructuredGrid->InsertNextCell(VTK_POLYHEDRON, 8, pointIds, 12,
                                         faces->GetPointer());
        work->SetValue(
            n,
            global_vertices[n * (nVertices * balancer->getDimension() + 1) +
                            8 * balancer->getDimension()]);
        cell->SetValue(n, (T)n);
      }
      unstructuredGrid->GetCellData()->AddArray(work);
      unstructuredGrid->GetCellData()->AddArray(cell);

      createDirectory("vtk_vertices");
      std::ostringstream filename;
      filename << "vtk_vertices/ALL_vtk_vertices_" << std::setw(7)
               << std::setfill('0') << step << ".vtu";
      auto writer = vtkSmartPointer<vtkXMLUnstructuredGridWriter>::New();
      writer->SetInputData(unstructuredGrid);
      writer->SetFileName(filename.str().c_str());
      writer->SetDataModeToAscii();
      // writer->SetDataModeToBinary();
      writer->Write();

      delete[] global_vertices;
    }
  }
#endif

private:
  /// the used balancing method
  LB_t method;

  /// outer cuboid encasing the domain (for cuboid domains identical to domain)
  /// defined by front left lower [0][*] and back upper right points [1][*]
  /// where * is 0,...,dim-1
  std::vector<Point<T>> outline;

  /// the interal balancer object
  std::unique_ptr<LB<T, W>> balancer;

  /// storage of local work (scalar work is stored in the first entry of the
  /// vector)
  std::vector<W> workArray;

  /// internal MPI communicator used in library
  MPI_Comm communicator;

  /// number of vertices (for non-cuboid domains)
  int nVertices;

  /// number of neighbors
  int nNeighbors;

  /// calculate the outline of the domain using the vertices, i.e. the smallest
  /// orthogonal domain containing the vertices used
  void calculate_outline() {
    // calculation only possible if there are vertices defining the domain
    if (balancer->getVertices().size() > 0) {
      outline.resize(2);
      // setup the outline with the first point
      for (int i = 0; i < balancer->getDimension(); ++i) {
        outline.at(0) = balancer->getVertices().at(0);
        outline.at(1) = balancer->getVertices().at(0);
      }
      // compare value of each outline point with all vertices to find the
      // maximum extend of the domain in each dimension
      for (int i = 1; i < (int)balancer->getVertices().size(); ++i) {
        Point<T> p = balancer->getVertices().at(i);
        for (int j = 0; j < balancer->getDimension(); ++j) {
          outline.at(0)[j] = std::min(outline.at(0)[j], p[j]);
          outline.at(1)[j] = std::max(outline.at(1)[j], p[j]);
        }
      }
    }
  }

  /// create directory if it does not already exist
  ///
  /// May throw FilesystemErrorException
  void createDirectory(const char *filename) {
    errno = 0;
    mode_t mode = S_IRWXU | S_IRWXG; // rwx for user and group
    if(mkdir(filename, mode)) {
      if(errno != EEXIST) {
        throw FilesystemErrorException(
            __FILE__, __func__, __LINE__,
            "Could not create output directory.");
      }
    }
    // check permission in case directory already existed, but had wrong
    // permissions
    struct stat attr;
    stat(filename, &attr);
    if( (attr.st_mode & S_IRWXU) != S_IRWXU) {
      throw FilesystemErrorException(
          __FILE__, __func__, __LINE__,
          "Possibly already existing directory does not have correct permissions (rwx) for user");
    }
  }


  /// limit for the estimation procedure, which is an experimental way to use
  /// non-updated work-loads to provide better results for the final vertex
  /// positions
  int estimation_limit;

  /// cartesian coordinates of the local domain in the process grid
  std::vector<int> procGridLoc;
  /// size of the process grid
  std::vector<int> procGridDim;
  /// check if the process grid data is set
  bool procGridSet;
  /// tag of the process
  int procTag;

  /// datatype for MPI to use when communicating vertex related data
  MPI_Datatype MPIDataTypeT;

  /// datatype for MPI to use when communicating work related data
  MPI_Datatype MPIDataTypeW;

  /// counter for the number of loadbalancing steps already performed
  int loadbalancing_step;

#ifdef ALL_VTK_OUTPUT
  /// check if the initialization of parallel VTK is already performed
  bool vtk_init;

  /// the parallel VTK controller for the domain output
  vtkMPIController *controller;

  /// the parallel VTK controller for the vertex output
  vtkMPIController *controller_vertices;
#endif
};

}//namespace ALL

#endif

// VIM modeline for indentation
// vim: sw=2 et

#!/bin/bash

# $1: Programname
# $2: Outputdirectory (should be relative, for symlnks to be relative)

set -x

PROGRAM=${1##*/}
PROGRAMPATH=${1%/*}

for NP in 4 16 21 64 127 128
do
	mpirun --oversubscribe -np $NP $1  > $2/${PROGRAM}_${NP}.dat
	rm -f $2/${PROGRAM}_f_${NP}.dat
	ln -s $2/${PROGRAM}_${NP}.dat $2/${PROGRAM}_f_${NP}.dat
done

#ifndef GAUSS_H
#define GAUSS_H GAUSS_h

extern int gauss_get_sum (int min, int max);

#endif /* GAUSS_H */

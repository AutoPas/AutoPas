#!/usr/bin/bash

#echo "$@_" >> x.log
exit 1

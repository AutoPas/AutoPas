kal_uint32 L1_BANK *p_nb_crit = reinterpret_cast<kal_uint32 L1_BANK *>(l1_to_icm_cast(mrh_nb_crit));

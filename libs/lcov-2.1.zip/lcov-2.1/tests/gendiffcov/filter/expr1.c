nr_ddmrs_trs_fce_ar_fcm_cal_knl(&mc_trs_ar_fcm,
                                hch_trs_srv_addr_rx,
                                &mc_os_vcm_acc_rtl_buf,
                                total_prg_num,
                                log2_alpha,
                                ar_fcm_exp_diff,
                                sr_fcm_trace);

hello_world();

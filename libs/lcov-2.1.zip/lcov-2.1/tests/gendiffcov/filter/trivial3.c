}; // simulate end of class decl

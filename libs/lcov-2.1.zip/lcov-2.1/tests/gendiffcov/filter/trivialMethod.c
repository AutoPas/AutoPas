Data::Data(int a) {
  // nothing here
}

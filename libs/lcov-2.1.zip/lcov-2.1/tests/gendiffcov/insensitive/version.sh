#!/usr/bin/env perl

#just return constant value for the moment

print("1\n");
exit(0);

#ifndef EIGEN_THREADPOOL_MODULE_H
#error \
    "Please include unsupported/Eigen/CXX11/ThreadPool instead of including headers inside the src directory directly."
#endif

This "lib" directory contains library files produced by the build system.

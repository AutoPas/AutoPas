.. PowerSensor 3 documentation master file, created by
   sphinx-quickstart on Thu Jun 15 11:09:51 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to PowerSensor 3's documentation!
=========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   INSTALLATION_DEVICE.md
   INSTALLATION_HOST.md
   USERGUIDE.md
   CONTRIBUTING.md

.. toctree::
   :maxdepth: 2
   :caption: API documentation:

   api/library_root



Index
==================

* :ref:`genindex`

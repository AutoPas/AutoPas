Highway, a C++ library that provides portable SIMD/vector intrinsics
====================================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   README
   quick_reference
   design_philosophy
   faq
   impl_details
   release_testing_process
.. ALL documentation master file, created by
   sphinx-quickstart on Mon Mar  9 11:51:23 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to the documentation of ALL
===================================

.. toctree::
  :maxdepth: 2
  :caption: Contents:
  :includehidden:

  Install.rst
  Usage.rst
  Examples.rst
  Changelog.rst
  api/index.rst
  methods/index.rst
  modules/index.rst


The full (developer) documentation of the source code as provided by
doxygen can be found `here <https://slms.pages.jsc.fz-juelich.de/websites/all-website/>`_.

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

.. * :ref:`modindex`

.. vim: et sw=2 ts=2 tw=74 spell spelllang=en_us:

==================================
Documentation for the C++ codebase
==================================

The core logic of Treelite is written in C++. Visit the link below to find
the documentation for all C++ functions and classes defined in Treelite.

`Documentation for C++ functions and classes <./dev>`_

.. _CustomExceptions:

Custom Exceptions
=================

The library may throw one of these exceptions, which are all based on
``ALL::CustomException``.

``CustomException``
-------------------
.. doxygenstruct:: ALL::CustomException
  :outline:

``FilesystemErrorException``
****************************
.. doxygenstruct:: ALL::FilesystemErrorException
  :outline:

``InternalErrorException``
**************************
.. doxygenstruct:: ALL::InternalErrorException
  :outline:

``InvalidArgumentException``
****************************
.. doxygenstruct:: ALL::InvalidArgumentException
  :outline:

``InvalidCommTypeException``
****************************
.. doxygenstruct:: ALL::InvalidCommTypeException
  :outline:

``OutOfBoundsException``
************************
.. doxygenstruct:: ALL::OutOfBoundsException
  :outline:

``PointDimensionMissmatchException``
************************************
.. doxygenstruct:: ALL::PointDimensionMissmatchException
  :outline:

.. vim: et sw=2 ts=2 tw=74 spell spelllang=en_us:

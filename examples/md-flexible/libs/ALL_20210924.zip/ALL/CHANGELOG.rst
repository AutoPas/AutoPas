=========
Changelog
=========

Version 1.0
-----------

Version 1.0.0
*************
- Bug: Nested namespace definitions were present, which are a C++17 feature.

Version 0.9
-----------

Version 0.9.2
*************

- *CHANGE*: The old CMake policy ``CMP0004``, which was required for some MPI
  installations, is no longer set. If this is still required: Please contact
  us.
- *CHANGE*: Fortran modules are now installed in ``/lib``, instead of
  ``/include/modules``.
- Feature: Integration tests are only generated if ``CM_ALL_TESTS_INTEGRATION``
  is set.
- Feature: Example CMake and Make projects for integrating ALL into the build
  process.
- Bug: CMake dependencies between targets and link and include inheritance
  corrected.

Version 0.9.1
*************

- Bug: Wrong gamma calculation for staggered grid.
- Bug: No optimal gamma calculation for tensor method.

Version 0.9.0
*************
Initial release
